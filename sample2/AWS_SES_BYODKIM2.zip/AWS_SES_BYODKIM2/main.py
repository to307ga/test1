def main():
    print("Hello from aws-ses!")


if __name__ == "__main__":
    main()
