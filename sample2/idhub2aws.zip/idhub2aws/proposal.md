# Fargate上でのhttpd・tomcat・fluent（FireLens）構成提案

## 1. 構成概要

ECS Fargate上でhttpd・tomcatアプリケーションのログ転送、RDS接続、バッチ処理（DB更新・ファイル出力）を実現するための構成例を示します。

### サービス構成イメージ

```mermaid
flowchart TD
    subgraph ECS Task
        direction LR
        httpd["httpdコンテナ"] -- 標準出力/エラー --> firelens["FireLens (Fluent Bit) サイドカー"]
        tomcat["tomcatコンテナ"] -- 標準出力/エラー --> firelens
        batch["バッチ処理コンテナ"] -- DB抽出/ファイル出力 --> sharedvol["共有ボリューム"]
        sharedvol -- ファイル配置 --> httpd
        firelens -- ログ転送 --> cloudwatch["CloudWatch Logs"]
        firelens -- option --> es["Elasticsearch等"]
        batch -- DB接続 --> rds["RDS"]
    end
    httpd -- HTTP --> user["利用者"]
    tomcat -- HTTP --> user
```

- **httpd/tomcat**: それぞれ独立したコンテナで動作。ログは標準出力/標準エラーに出力。
- **FireLens (Fluent Bit)**: サイドカーとして同一タスク内で動作し、ログをCloudWatch LogsやElasticsearch等に転送。
- **バッチ処理**: DBから特定条件で抽出し、結果ファイルを共有ボリューム経由でhttpdサーバの`/etc/www/html/work/`に配置。
- **共有ボリューム**: httpd・バッチ間でファイルを受け渡すためのEFSやFargate Ephemeral Storage等。
- **RDS**: DB接続先。バッチやアプリから直接接続。

## 2. 各コンテナのポイント

### httpd
- ログ出力先を`/dev/stdout`（アクセスログ）、`/dev/stderr`（エラーログ）に設定。
- `/etc/www/html/work/`を共有ボリュームとしてマウントし、バッチ処理結果を公開。
- 例:
  ```apache
  ErrorLog /dev/stderr
  CustomLog /dev/stdout combined
  ```

### tomcat
- `conf/logging.properties`で標準出力/エラーにリダイレクト。
- 例:
  ```properties
  1catalina.org.apache.juli.FileHandler.directory = /dev
  1catalina.org.apache.juli.FileHandler.prefix = stdout
  ```
- または`catalina.sh run`で起動。

### FireLens (Fluent Bit)
- サイドカーとして配置。
- `awslogs`や`elasticsearch`等、任意の出力先に転送可能。

### バッチ処理
- DBから特定条件でデータ抽出し、ファイルを`/work/`（共有ボリューム）に出力。
- RDSへの接続情報は環境変数やSecrets Managerで管理。
- 例: `/work/result.csv` → httpdの`/etc/www/html/work/result.csv`として公開

## 3. サンプルECSタスク定義（JSON）

```json
{
  "family": "sample-fargate-task",
  "networkMode": "awsvpc",
  "containerDefinitions": [
    {
      "name": "firelens-log-router",
      "image": "amazon/aws-for-fluent-bit:latest",
      "essential": true,
      "firelensConfiguration": {
        "type": "fluentbit",
        "options": {
          "enable-ecs-log-metadata": "true"
        }
      },
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/firelens",
          "awslogs-region": "ap-northeast-1",
          "awslogs-stream-prefix": "firelens"
        }
      }
    },
    {
      "name": "httpd",
      "image": "your-httpd-image:latest",
      "essential": true,
      "portMappings": [
        { "containerPort": 80 }
      ],
      "mountPoints": [
        {
          "sourceVolume": "workdir",
          "containerPath": "/etc/www/html/work"
        }
      ],
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "Name": "cloudwatch",
          "region": "ap-northeast-1",
          "log_group_name": "/ecs/httpd",
          "auto_create_group": "true"
        }
      }
    },
    {
      "name": "tomcat",
      "image": "your-tomcat-image:latest",
      "essential": true,
      "portMappings": [
        { "containerPort": 8080 }
      ],
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "Name": "cloudwatch",
          "region": "ap-northeast-1",
          "log_group_name": "/ecs/tomcat",
          "auto_create_group": "true"
        }
      }
    },
    {
      "name": "batch",
      "image": "your-batch-image:latest",
      "essential": false,
      "mountPoints": [
        {
          "sourceVolume": "workdir",
          "containerPath": "/work"
        }
      ],
      "environment": [
        { "name": "DB_HOST", "value": "your-rds-endpoint" },
        { "name": "DB_USER", "value": "your-db-user" },
        { "name": "DB_PASS", "value": "your-db-password" }
      ],
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "Name": "cloudwatch",
          "region": "ap-northeast-1",
          "log_group_name": "/ecs/batch",
          "auto_create_group": "true"
        }
      }
    }
  ],
  "volumes": [
    {
      "name": "workdir",
      "host": {}
      // EFSを利用する場合は以下のようにefsVolumeConfigurationを指定
      // "efsVolumeConfiguration": {
      //   "fileSystemId": "fs-xxxxxxxx",
      //   "rootDirectory": "/workdir"
      // }
    }
  ],
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "executionRoleArn": "arn:aws:iam::123456789012:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456789012:role/ecsTaskRole"
}
```

## 4. 注意点・補足
- RDS接続情報はSecrets ManagerやSSM Parameter Storeで安全に管理してください。
- バッチ処理はスケジュール実行（EventBridge等）や手動実行が可能です。
- Fargateのローカルストレージは永続化されないため、ファイル出力はEFSやS3等の外部ストレージ利用を推奨します。
- FireLensの出力先は要件に応じてCloudWatch LogsやElasticsearch等に変更可能です。
- 共有ボリュームはEFS推奨。Ephemeral Storageの場合はタスク停止で消えるため注意。

## 5. バッチ処理をECSコンテナで行う場合とLambdaで行う場合の比較

| 項目 | ECSコンテナ（Fargate） | AWS Lambda |
|------|------------------------|------------|
| **実行時間** | 長時間・大容量バッチも対応可（最大28日間） | 最大15分（2025年7月時点） |
| **起動方式** | スケジュール/EventBridge/手動/外部API等 | スケジュール/EventBridge/手動/外部API等 |
| **実行環境** | 任意のOS・ミドルウェア・言語利用可 | サポート言語のみ。OSやミドルウェア制約あり |
| **ストレージ** | EFS/Ephemeral Storage等の永続・一時ストレージ利用可 | 一時ストレージ(512MB～10GB)・EFSマウント可 |
| **VPC接続** | 標準でVPC内リソース（RDS等）にアクセス可 | VPC設定でRDS等にアクセス可（コールドスタート遅延あり） |
| **コスト** | 起動中は課金。短時間・低頻度なら割高 | 実行時間・回数課金。短時間・低頻度なら安価 |
| **スケーラビリティ** | タスク数・リソースを柔軟に設定可 | 並列実行数に上限あり（同時実行数制限） |
| **運用** | Dockerイメージ管理・ECS運用が必要 | コードデプロイのみ。運用負荷小 |
| **外部連携** | 任意のバイナリ・ツール利用可 | Lambda Layer等で拡張可能だが制約あり |
| **起動速度** | 数十秒～数分（イメージDL等） | 数秒（コールドスタート時は遅延あり） |

### 【ECSコンテナ（Fargate）でバッチ処理を行う利点・マイナス点】

**利点**
- 長時間・大容量バッチや複雑な処理、独自ミドルウェア利用が可能
- httpd等の他コンテナとボリューム共有しやすい
- 任意のOS/言語/ツールが利用できる
- VPC内リソースへのアクセスが容易

**マイナス点**
- 起動・終了に時間がかかる場合がある
- 短時間・低頻度バッチではコスト高
- Dockerイメージ管理やECS運用が必要

### 【AWS Lambdaでバッチ処理を行う利点・マイナス点】

**利点**
- 短時間・小規模バッチならコスト効率が高い
- 運用負荷が小さく、デプロイも容易
- イベントドリブンで柔軟な起動が可能

**マイナス点**
- 15分以上の長時間処理や大容量データ処理には不向き
- OSやミドルウェア、外部バイナリ利用に制約
- httpd等のECSコンテナと直接ボリューム共有不可（S3/EFS経由で連携）
- VPC接続時のコールドスタート遅延

### 【選定のポイント】
- **長時間・大容量・複雑な処理やECS内の他コンテナと直接ファイル連携が必要な場合はECSコンテナ（Fargate）推奨**
- **短時間・小規模・イベント駆動型で、S3/EFS経由のファイル連携で十分な場合はLambdaも有力**

---

### 追加で必要な情報があればご指示ください
- バッチ処理のSQL例や出力ファイル形式
- 共有ボリュームの種類（EFS or Ephemeral Storage）
- セキュリティ要件（VPC、IAMロール等）
- 想定するトラフィックやリソース要件

ご要望に応じてさらに詳細な設計やサンプルもご用意可能です。
