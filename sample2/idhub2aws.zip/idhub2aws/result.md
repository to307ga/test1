【Fargate移行の要点まとめ】

1. オンプレミスの各サービス（httpd, tomcat, proxysql, mariadb-client, td-agent）は、Fargate移行時に個別コンテナ化が推奨。
2. httpdとtomcatを1つのコンテナにまとめることは可能だが、ベストプラクティスは分離。まとめる場合はsupervisord等で複数プロセス管理。
3. ログ管理は、標準出力リダイレクト＋CloudWatch Logs転送、またはFireLens（Fluent Bit/Fluentd）でElasticsearch等へ転送が推奨。
4. FireLensはECSタスク内でサイドカーとして動作し、他コンテナのログを柔軟に加工・転送できる。
5. /var/log/httpd/等のローカルログはFargate再起動等で消失するため、必ず外部サービスへ転送する設計とする。
6. AWS公式のベストプラクティスやドキュメントを参考に、段階的な移行・運用設計を行うこと。

---

【補足：サイドカー・ボリューム共有について】

- 1つのタスク定義内にFireLens（log router）とapp（アプリケーション）を入れることで、同じネットワーク名前空間（ENI）を共有し、localhostで通信可能。
- ディレクトリやファイルを共有したい場合は、ECSタスク定義の`volumes`と`mountPoints`を使い、両コンテナで同じボリュームをマウントすることで、/var/log/httpd/などのディレクトリを共有できる。
- ただし、Fargateのローカルストレージは永続化されないため、ログは必ず外部サービス（CloudWatch LogsやElasticsearch等）へ転送する設計とする。
