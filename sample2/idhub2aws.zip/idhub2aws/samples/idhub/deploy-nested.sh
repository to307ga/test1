#!/bin/bash

# ネストされたスタック対応のデプロイスクリプト
# 使用方法: ./deploy-nested.sh <environment> <action> [stack-file]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 設定
SCEPTRE_DIR="sceptre"
CONFIG_DIR="$SCEPTRE_DIR/config-nested"
TEMPLATE_DIR="$SCEPTRE_DIR/templates"

# 使用方法の表示
usage() {
    echo "使用方法: $0 <environment> <action> [stack-file]"
    echo ""
    echo "Environment:"
    echo "  dev, stg, prod"
    echo ""
    echo "Actions:"
    echo "  setup     - S3バケットの作成とテンプレートアップロード"
    echo "  deploy    - スタックをデプロイ"
    echo "  delete    - スタックを削除"
    echo "  status    - スタックの状態を確認"
    echo "  outputs   - スタックの出力を表示"
    echo "  validate  - テンプレートを検証"
    echo ""
    echo "Examples:"
    echo "  $0 dev setup                          # S3バケット作成とテンプレートアップロード"
    echo "  $0 dev deploy                         # 全スタックをデプロイ"
    echo "  $0 dev deploy 01-core-infra-nested.yaml # 特定スタックをデプロイ"
    echo "  $0 dev status                         # 全スタックの状態確認"
    exit 1
}

# 引数チェック
if [ $# -lt 2 ]; then
    usage
fi

ENVIRONMENT=$1
ACTION=$2
STACK_FILE=$3

# 環境チェック
if [[ ! "$ENVIRONMENT" =~ ^(dev|stg|prod)$ ]]; then
    echo "エラー: 無効な環境です: $ENVIRONMENT"
    usage
fi

# アクションチェック
if [[ ! "$ACTION" =~ ^(setup|deploy|delete|status|outputs|validate)$ ]]; then
    echo "エラー: 無効なアクションです: $ACTION"
    usage
fi

# S3バケット名の設定
S3_BUCKET="idhub-${ENVIRONMENT}-sceptre-templates"

# S3セットアップ関数
setup_s3() {
    echo "========================================="
    echo "S3バケットの設定を開始します"
    echo "バケット名: $S3_BUCKET"
    echo "========================================="
    
    # S3バケットの作成
    if aws s3 ls "s3://$S3_BUCKET" 2>/dev/null; then
        echo "S3バケット $S3_BUCKET は既に存在します。"
    else
        echo "S3バケット $S3_BUCKET を作成中..."
        aws s3 mb "s3://$S3_BUCKET" --region ap-northeast-1
        echo "S3バケットを作成しました。"
    fi
    
    # テンプレートのアップロード
    echo "テンプレートをS3にアップロード中..."
    aws s3 sync "$TEMPLATE_DIR/" "s3://$S3_BUCKET/templates/" --delete
    echo "テンプレートのアップロードが完了しました。"
    
    # アップロードされたファイルの確認
    echo "アップロードされたテンプレート:"
    aws s3 ls "s3://$S3_BUCKET/templates/" --recursive
}

# 設定ディレクトリの存在確認
if [ "$ACTION" != "setup" ] && [ ! -d "$CONFIG_DIR/$ENVIRONMENT" ]; then
    echo "エラー: 環境設定ディレクトリが見つかりません: $CONFIG_DIR/$ENVIRONMENT"
    exit 1
fi

# Sceptreコマンドの構築
SCEPTRE_CMD="sceptre --config-dir $CONFIG_DIR"

# スタック指定の処理
if [ -n "$STACK_FILE" ] && [ "$ACTION" != "setup" ]; then
    # 特定のスタックを指定
    if [ ! -f "$CONFIG_DIR/$ENVIRONMENT/$STACK_FILE" ]; then
        echo "エラー: スタック設定ファイルが見つかりません: $CONFIG_DIR/$ENVIRONMENT/$STACK_FILE"
        exit 1
    fi
    STACK_PATH="$ENVIRONMENT/$STACK_FILE"
else
    # 全スタックを対象
    STACK_PATH="$ENVIRONMENT"
fi

# アクション実行
case $ACTION in
    setup)
        setup_s3
        ;;
    
    deploy)
        echo "========================================="
        echo "環境: $ENVIRONMENT"
        echo "アクション: $ACTION"
        echo "スタック: ${STACK_FILE:-"全スタック"}"
        echo "========================================="
        echo "デプロイを開始します..."
        
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD launch $STACK_PATH --yes
        else
            # 順序を考慮した全体デプロイ（5層構成）
            echo "1. Core Infrastructure (Nested) をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/01-core-infra-nested.yaml --yes
            
            echo "2. Security (Nested) をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/02-security-nested.yaml --yes
            
            echo "3. Database (Nested) をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/03-database-nested.yaml --yes
            
            echo "4. Application Tier (Nested) をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/04-app-tier-nested.yaml --yes
            
            echo "5. CDN (Nested) をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/05-cdn-nested.yaml --yes
        fi
        echo "デプロイが完了しました。"
        ;;
    
    delete)
        echo "削除を開始します..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD delete $STACK_PATH --yes
        else
            # 逆順で削除（5層構成）
            echo "5. CDN (Nested) を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/05-cdn-nested.yaml --yes || true
            
            echo "4. Application Tier (Nested) を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/04-app-tier-nested.yaml --yes || true
            
            echo "3. Database (Nested) を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/03-database-nested.yaml --yes || true
            
            echo "2. Security (Nested) を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/02-security-nested.yaml --yes || true
            
            echo "1. Core Infrastructure (Nested) を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/01-core-infra-nested.yaml --yes || true
        fi
        echo "削除が完了しました。"
        ;;
    
    status)
        echo "スタックの状態を確認中..."
        $SCEPTRE_CMD list $STACK_PATH
        ;;
    
    outputs)
        echo "スタックの出力を表示中..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD list outputs $STACK_PATH
        else
            echo "全スタックの出力:"
            for stack in 01-core-infra-nested.yaml 02-security-nested.yaml 03-database-nested.yaml 04-app-tier-nested.yaml 05-cdn-nested.yaml; do
                if [ -f "$CONFIG_DIR/$ENVIRONMENT/$stack" ]; then
                    echo "--- $stack ---"
                    $SCEPTRE_CMD list outputs $ENVIRONMENT/$stack || true
                    echo ""
                fi
            done
        fi
        ;;
    
    validate)
        echo "テンプレートを検証中..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD validate $STACK_PATH
        else
            for stack in 01-core-infra-nested.yaml 02-security-nested.yaml 03-database-nested.yaml 04-app-tier-nested.yaml 05-cdn-nested.yaml; do
                if [ -f "$CONFIG_DIR/$ENVIRONMENT/$stack" ]; then
                    echo "検証中: $stack"
                    $SCEPTRE_CMD validate $ENVIRONMENT/$stack
                fi
            done
        fi
        echo "検証が完了しました。"
        ;;
esac

echo "処理が完了しました。"
