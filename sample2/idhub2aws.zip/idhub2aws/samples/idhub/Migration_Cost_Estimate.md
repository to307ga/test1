
# AWSマイグレーション費用見積書
## オンプレミスからAWSへの移行プロジェクト

**作成日**: 2025年7月31日
**対象リージョン**: 東京リージョン（ap-northeast-1）
**見積通貨**: USD（日本円換算: 1USD = 150JPY）

---

## 1. プロジェクト概要

### 移行対象
- 現在オンプレミスで稼働中のサービスをAWSへマイグレーション
- 本番環境と開発環境の2テナント構成
- 3つのAvailability Zone（AZ）を使用した高可用性構成

### プロジェクト要件

#### 1.1 初期要件（基本構成）
**インフラストラクチャ**
- **AZ構成**: 3つのAvailability Zone
- **サブネット構成**: 各AZ内に3つのサブネット（Firewall-subnet、Public-subnet、Private-subnet）
- **セキュリティ**: WAF、CloudFront、Network Firewall、LB（Application Load Balancer）
- **ネットワーク**: NAT Gateway、VPN Gateway（本番・開発各1台）

**コンピューティング**
- **本番環境**: EC2 t3.2xlarge × 3台、t3.medium × 3台、t3.xlarge × 3台（各AZのPrivate-subnetに1台ずつ）
  - t3.2xlarge、t3.medium：Web用途（別サービス担当）
  - t3.xlarge：バッチサーバ用途
- **開発環境**: EC2 t3.medium × 9台（各AZのPrivate-subnetに3台ずつ）
- **OS**: Amazon Linux
- **ストレージ**: 本番150GB、開発100GB（増設ストレージ）

**データベース**
- **Aurora MySQL**: データサイズ100GB
  - WEBからの書き込み: 10MB/時間程度
  - 夜間バッチ処理: 500MB相当の変更
  - 月次処理でデータ削除実行（データ増加はほぼ無し）
- **接続**: ProxySQL を用いた負荷分散と高速フェールオーバー
- **マイグレーション**: オンプレMySQL Galera ClusterからAurora MySQLへDMSでダウンタイム最小化

**コンテナプラットフォーム**
- **ECS Fargate**: Jenkins + Gitea稼働
- **EFS**: データ永続化用共有ストレージ
- **アクセス**: オンプレ環境とEC2からアクセス可能

**その他サービス**
- **監視**: Datadog Fluent（サーバログ・メトリクス）
- **ログ保管**: AWS各リソースのログをS3に保管
- **運用管理**: AWS Systems Manager使用
- **ネットワーク**: オンプレ環境とAWS間をVPN Gatewayで接続
- **トラフィック**: 月間インバウンド・アウトバウンド共に70MB程度

#### 1.2 追加要件（後期追加）
**セキュリティ統一**
- 開発環境のセキュリティレベルを本番環境と同等に統一
- 開発環境にもCloudFront、AWS WAF v2、Network Firewallを適用

**DNS管理**
- オンプレミスDNSからAWS Route 53への切り替え
- 本番・開発環境用のHosted Zone設定

**運用要件**
- 本番・開発環境共に24時間365日稼働

#### 1.3 技術仕様詳細
**ネットワーク構成**
- **リージョン**: 東京リージョン（ap-northeast-1）
- **VPC**: 本番・開発環境それぞれ独立したVPC
- **AZ**: ap-northeast-1a、ap-northeast-1c、ap-northeast-1d（3AZ構成）
- **サブネット**: 各AZに以下3種類のサブネット
  - Firewall Subnet（Network Firewall用）
  - Public Subnet（NAT Gateway、ALB用）
  - Private Subnet（EC2、Aurora用）

**セキュリティ構成**
- **多層防御**: CloudFront → WAF → Network Firewall → ALB → EC2
- **本番・開発統一**: 両環境で同等のセキュリティレベルを適用
- **VPN接続**: オンプレミス - AWS間の安全な通信

**ロードバランサー選定理由（ALB vs NLB）**
- **WAFとの統合**: Layer 7レベルでの攻撃検知にはALBが必要
  - HTTPヘッダー、リクエストボディ、URLパスの詳細情報をWAFに提供
  - NLBではLayer 4（TCP/UDP）レベルのためWAFが十分に機能しない
- **詳細なログとメトリクス**: Webアプリケーション運用に最適
  - HTTPステータスコード別統計
  - レスポンス時間の詳細分析
  - パスベース・ホストベースルーティング（将来拡張性）
- **コスト考慮**: 基本料金同額、LCU差額は軽微（月数ドル程度）
  - ALB: $0.0243/時間 + $0.008/LCU-時間
  - NLB: $0.0243/時間 + $0.006/LCU-時間
  - 現在のトラフィック量（70MB/月×2環境）では差額は僅少

**データベース詳細仕様**
- **マイグレーション元**: MySQL Galera Cluster（オンプレミス）
- **マイグレーション先**: Aurora MySQL
- **データ特性**:
  - 現在のデータサイズ: 100GB
  - 書き込み負荷: 10MB/時間（定常）+ 500MB/日（夜間バッチ）
  - データ削除: 月次で古いデータを削除（容量増加なし）
- **接続方式**: RDS Proxy経由での負荷分散・フェイルオーバー

**運用・監視**
- **外部監視**: Datadog（サーバメトリクス・ログ）
- **ログ管理**: AWSサービスログをS3に長期保管
- **システム管理**: Systems Manager（パッチ管理、設定管理等）
- **CI/CD**: ECS Fargate上のJenkins + Gitea

**パフォーマンス要件**
- **Webトラフィック**: 月間70MB（In/Out）
- **可用性**: 99.9%以上（3AZ構成での高可用性）
- **災害対策**: AZ障害時の自動フェイルオーバー

#### 1.4 要件変更による影響
**セキュリティ統一による追加コスト**
- 開発環境へのCloudFront、WAF、Network Firewall追加: +$407.00/月
- セキュリティレベル統一により、開発環境でも本番同等の保護を実現

**DNS移行による追加コスト**
- Route 53 Hosted Zone（本番・開発）: +$1.00/月
- DNS管理のAWS統合により運用の一元化を実現

**24時間稼働による前提条件**
- 本番・開発環境共に月730時間（24×30.4日）の稼働時間で算出
- 開発環境の夜間停止等によるコスト削減は見込まず

### アーキテクチャ概要
```mermaid
graph TB
    subgraph "External"
        USER[Users/Internet]
    end
    
    subgraph "AWS Cloud - Tokyo Region (ap-northeast-1)"
        subgraph "CloudFront + WAF"
            CF[CloudFront Distribution]
            WAF[AWS WAF v2]
        end
        
        subgraph "Network Firewall"
            NWFW[AWS Network Firewall]
        end
        
        subgraph "Availability Zone 1"
            subgraph "AZ1-Subnets"
                FW1[Firewall Subnet]
                PUB1[Public Subnet]
                PRIV1[Private Subnet]
            end
            EC2_PROD_1A[EC2 t3.2xlarge Web (別サービス担当)]
            EC2_PROD_1B[EC2 t3.medium Web (別サービス担当)]
            EC2_PROD_1C[EC2 t3.xlarge Batch]
            NAT1[NAT Gateway]
        end
        
        subgraph "Availability Zone 2"
            subgraph "AZ2-Subnets"
                FW2[Firewall Subnet]
                PUB2[Public Subnet]
                PRIV2[Private Subnet]
            end
            EC2_PROD_2A[EC2 t3.2xlarge Web (別サービス担当)]
            EC2_PROD_2B[EC2 t3.medium Web (別サービス担当)]
            EC2_PROD_2C[EC2 t3.xlarge Batch]
            NAT2[NAT Gateway]
        end
        
        subgraph "Availability Zone 3"
            subgraph "AZ3-Subnets"
                FW3[Firewall Subnet]
                PUB3[Public Subnet]
                PRIV3[Private Subnet]
            end
            EC2_PROD_3A[EC2 t3.2xlarge Web (別サービス担当)]
            EC2_PROD_3B[EC2 t3.medium Web (別サービス担当)]
            EC2_PROD_3C[EC2 t3.xlarge Batch]
            NAT3[NAT Gateway]
        end
        
        subgraph "Load-Balancing"
            ALB[Application Load Balancer]
        end
        
        subgraph "Database"
            AURORA_W[Aurora MySQL Writer]
            AURORA_R1[Aurora MySQL Reader]
            PROXY[RDS Proxy]
        end
        
        subgraph "Container-Platform"
            JENKINS[Jenkins on Fargate]
            GITEA[Gitea on Fargate]
            EFS_STORAGE[EFS Storage]
        end
        
        subgraph "Migration-Monitoring"
            DMS[AWS DMS]
            SSM[Systems Manager]
            S3_LOGS[S3 Logs Storage]
        end
        
        subgraph "VPN-Connectivity"
            VGW_PROD[VPN Gateway Production]
            VGW_DEV[VPN Gateway Development]
        end
        
        subgraph "DNS-Management"
            ROUTE53[Route 53 DNS Service]
        end
    end
    
    subgraph "On-premises"
        ONPREM_PROD[Production Environment]
        ONPREM_DEV[Development Environment]
        GALERA[MySQL Galera Cluster]
    end
    
    USER --> ROUTE53
    ROUTE53 --> CF
    CF --> WAF
    WAF --> NWFW
    NWFW --> ALB
    ALB --> EC2_PROD_1A
    ALB --> EC2_PROD_2A
    ALB --> EC2_PROD_3A
    ALB --> EC2_PROD_1B
    ALB --> EC2_PROD_2B
    ALB --> EC2_PROD_3B
    
    EC2_PROD_1A --> PROXY
    EC2_PROD_2A --> PROXY
    EC2_PROD_3A --> PROXY
    EC2_PROD_1B --> PROXY
    EC2_PROD_2B --> PROXY
    EC2_PROD_3B --> PROXY
    
    PROXY --> AURORA_W
    PROXY --> AURORA_R1
    
    JENKINS --> EFS_STORAGE
    GITEA --> EFS_STORAGE
    
    DMS --> GALERA
    DMS --> AURORA_W
    
    VGW_PROD --> ONPREM_PROD
    VGW_DEV --> ONPREM_DEV
```

---

## 2. サービス構成詳細

### 2.1 ネットワーク・セキュリティ
- **AWS WAF v2**: Webアプリケーションファイアウォール（本番・開発環境共通）
- **CloudFront**: CDN配信（本番・開発環境共通）
- **Network Firewall**: ネットワークレベルセキュリティ（本番・開発環境共通）
- **Application Load Balancer**: ロードバランサー（本番・開発環境共通）
- **NAT Gateway**: 各AZに1台ずつ（合計3台）（本番・開発環境共通）
- **VPN Gateway**: 本番・開発各1台（合計2台）
- **Route 53**: DNS管理サービス（本番・開発用Hosted Zone）

**セキュリティ統一方針**: 本番環境と開発環境で同じセキュリティレベルを適用し、一貫したセキュリティ体制を構築

### 2.2 コンピューティング（本番環境）
- **EC2インスタンス**: 
  - t3.2xlarge × 3台（各AZに1台ずつ、Web用途・別サービス担当）
  - t3.medium × 3台（各AZに1台ずつ、Web用途・別サービス担当）
  - t3.xlarge × 3台（各AZに1台ずつ、バッチサーバ用途）
- **EBSストレージ**: GP3 150GB × 9台
- **OS**: Amazon Linux

### 2.3 コンピューティング（開発環境）
- **EC2インスタンス**: t3.medium × 9台（各AZに3台ずつ）
- **EBSストレージ**: GP3 100GB × 9台
- **OS**: Amazon Linux

### 2.4 データベース
- **Amazon Aurora MySQL**: 100GBデータサイズ
- **構成**: Writer 1台 + Reader 2台
- **RDS Proxy**: 負荷分散と高速フェールオーバー
- **データアクセスパターン**: 
  - WEBからの書き込み: 10MB/時間
  - 夜間バッチ処理: 500MB相当の変更

### 2.5 コンテナプラットフォーム
- **ECS Fargate**: Jenkins + Gitea
- **EFS**: データ永続化用共有ストレージ

### 2.6 その他サービス
- **AWS DMS**: マイグレーション用
- **AWS Systems Manager**: 運用管理（基本機能）
- **Amazon S3**: ログ保管 + データストレージ（1,500GB）
- **Amazon Route 53**: DNS管理サービス（本番・開発環境用）
- **Datadog**: サーバログ・メトリクス監視（外部サービス）

---

## 3. 月額料金見積

### 3.1 本番環境（Production）

#### 3.1.1 コンピューティング
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| EC2 t3.2xlarge | 8vCPU, 32GB RAM | 3台 | $304.13 | $912.39 | ￥136,859 |
| EC2 t3.medium | 2vCPU, 4GB RAM | 3台 | $38.02 | $114.06 | ￥17,109 |
| EC2 t3.xlarge | 4vCPU, 16GB RAM | 3台 | $152.07 | $456.21 | ￥68,432 |
| EBS GP3 | 150GB | 9台 | $14.40 | $129.60 | ￥19,440 |
| **小計** | | | | **$1,612.26** | **￥241,839** |

#### 3.1.2 ネットワーク・セキュリティ
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| Application Load Balancer | | 1台 | $16.20 | $16.20 | ￥2,430 |
| NAT Gateway | 1GB/月処理 | 3台 | $32.40 | $97.20 | ￥14,580 |
| VPN Gateway | | 1台 | $36.00 | $36.00 | ￥5,400 |
| CloudFront | 10GB転送 | 1サービス | $1.00 | $1.00 | ￥150 |
| AWS WAF v2 | 100万リクエスト | 1サービス | $1.00 | $1.00 | ￥150 |
| Network Firewall | | 1台 | $405.00 | $405.00 | ￥60,750 |
| Route 53 | Hosted Zone | 1個 | $0.50 | $0.50 | ￥75 |
| Route 53 | DNS Queries | 10万クエリ/月 | $0.04 | $0.04 | ￥6 |
| **小計** | | | | **$556.94** | **￥83,541** |

#### 3.1.3 データベース
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| Aurora MySQL Writer | db.r6g.large | 1台 | $105.12 | $105.12 | ￥15,768 |
| Aurora MySQL Reader | db.r6g.large | 2台 | $105.12 | $210.24 | ￥31,536 |
| Aurora Storage | 100GB | 1セット | $12.00 | $12.00 | ￥1,800 |
| Aurora I/O | 240万リクエスト/月 | 1セット | $0.58 | $0.58 | ￥87 |
| RDS Proxy | | 1台 | $10.80 | $10.80 | ￥1,620 |
| **小計** | | | | **$338.74** | **￥50,811** |

### 3.2 開発環境（Development）

#### 3.2.1 コンピューティング
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| EC2 t3.medium | 2vCPU, 4GB RAM | 9台 | $38.02 | $342.18 | ￥51,327 |
| EBS GP3 | 100GB | 9台 | $9.60 | $86.40 | ￥12,960 |
| **小計** | | | | **$428.58** | **￥64,287** |

#### 3.2.2 ネットワーク・セキュリティ
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| Application Load Balancer | | 1台 | $16.20 | $16.20 | ￥2,430 |
| NAT Gateway | 1GB/月処理 | 3台 | $32.40 | $97.20 | ￥14,580 |
| VPN Gateway | | 1台 | $36.00 | $36.00 | ￥5,400 |
| CloudFront | 5GB転送 | 1サービス | $1.00 | $1.00 | ￥150 |
| AWS WAF v2 | 50万リクエスト | 1サービス | $1.00 | $1.00 | ￥150 |
| Network Firewall | | 1台 | $405.00 | $405.00 | ￥60,750 |
| Route 53 | Hosted Zone | 1個 | $0.50 | $0.50 | ￥75 |
| Route 53 | DNS Queries | 5万クエリ/月 | $0.02 | $0.02 | ￥3 |
| **小計** | | | | **$556.92** | **￥83,538** |

#### 3.2.3 データベース
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| Aurora MySQL Writer | db.r6g.medium | 1台 | $52.56 | $52.56 | ￥7,884 |
| Aurora MySQL Reader | db.r6g.medium | 1台 | $52.56 | $52.56 | ￥7,884 |
| Aurora Storage | 50GB | 1セット | $6.00 | $6.00 | ￥900 |
| Aurora I/O | 120万リクエスト/月 | 1セット | $0.29 | $0.29 | ￥44 |
| RDS Proxy | | 1台 | $10.80 | $10.80 | ￥1,620 |
| **小計** | | | | **$122.21** | **￥18,332** |

### 3.3 共通サービス

#### 3.3.1 コンテナプラットフォーム
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| ECS Fargate (Jenkins) | 2vCPU, 4GB RAM | 1台 | $88.13 | $88.13 | ￥13,220 |
| ECS Fargate (Gitea) | 1vCPU, 2GB RAM | 1台 | $36.37 | $36.37 | ￥5,456 |
| EFS Standard | 20GB | 1セット | $7.20 | $7.20 | ￥1,080 |
| **小計** | | | | **$131.70** | **￥19,755** |

#### 3.3.2 その他サービス
| サービス | 仕様 | 数量 | 単価（USD/月） | 月額（USD） | 月額（JPY） |
|---------|------|------|---------------|------------|------------|
| AWS DMS | t3.medium（移行期間のみ） | 1台 | $80.64 | $80.64 | ￥12,096 |
| S3 Standard | ログ保管 50GB | 1セット | $1.25 | $1.25 | ￥188 |
| S3 Standard | データストレージ 1,500GB | 1セット | $37.50 | $37.50 | ￥5,625 |
| Systems Manager | 基本機能 | - | $0.00 | $0.00 | ￥0 |
| **小計** | | | | **$119.39** | **￥17,909** |

---

## 4. 月額費用総計

### 4.1 本番環境
| カテゴリ | 月額（USD） | 月額（JPY） |
|---------|------------|------------|
| コンピューティング | $1,612.26 | ￥241,839 |
| ネットワーク・セキュリティ | $556.94 | ￥83,541 |
| データベース | $338.74 | ￥50,811 |
| **本番環境小計** | **$2,507.94** | **￥376,191** |

### 4.2 開発環境
| カテゴリ | 月額（USD） | 月額（JPY） |
|---------|------------|------------|
| コンピューティング | $428.58 | ￥64,287 |
| ネットワーク・セキュリティ | $556.92 | ￥83,538 |
| データベース | $122.21 | ￥18,332 |
| **開発環境小計** | **$1,107.71** | **￥166,157** |

### 4.3 共通サービス
| カテゴリ | 月額（USD） | 月額（JPY） |
|---------|------------|------------|
| コンテナプラットフォーム | $131.70 | ￥19,755 |
| その他サービス | $119.39 | ￥17,909 |
| **共通サービス小計** | **$251.09** | **￥37,664** |

### 4.4 総計
| 環境 | 月額（USD） | 月額（JPY） |
|------|------------|------------|
| 本番環境 | $2,507.94 | ￥376,191 |
| 開発環境 | $1,107.71 | ￥166,157 |
| 共通サービス | $251.09 | ￥37,664 |
| **月額総計** | **$3,866.74** | **￥580,011** |

---

## 5. 年間費用概算

- **月額総計**: $3,866.74（￥580,011）
- **年額概算**: $46,400.88（￥6,960,132）

---

## 6. 前提条件・注意事項

### 6.1 料金計算の前提条件
- **稼働時間**: 24時間365日稼働を前提（本番・開発環境共通）
- **セキュリティレベル**: 本番環境と開発環境で同じセキュリティレベルを適用
- **データ転送量**: 月間70MBのインバウンド・アウトバウンドトラフィック
- **リージョン**: 東京リージョン（ap-northeast-1）
- **料金体系**: オンデマンド料金（リザーブドインスタンス未適用）
- **為替レート**: 2025年7月時点の料金（1USD = 150JPY）

### 6.2 含まれていない費用
- **Datadog**: 外部監視サービス（別途契約）
- **ProxySQL**: オープンソースソフトウェア（無料）
- **データ転送費用**: リージョン間転送やインターネット向け転送の超過分
- **サポート費用**: AWSプレミアムサポート等
- **運用・保守費用**: 人件費等

### 6.3 コスト最適化の提案
1. **リザーブドインスタンス**: 1-3年契約で最大75%削減可能
2. **Savings Plans**: コンピューティング使用量に応じた割引
3. **スポットインスタンス**: バッチ処理等で最大90%削減可能
4. **AWS Cost Explorer**: 継続的なコスト分析と最適化

### 6.4 移行期間中の追加費用
- **AWS DMS**: マイグレーション期間中のみ（1-3ヶ月想定）
- **並行稼働**: オンプレミスとAWSの並行稼働期間の費用
- **データ転送**: 初回データ移行時の大容量転送費用

---

## 7. AWS価格見積ツールとの比較

この見積書は、AWS Price List APIから取得した最新の価格情報を基に作成しています。
より詳細な見積もりや比較は、以下のAWS公式ツールをご利用ください：

- **AWS Pricing Calculator**: https://calculator.aws/
- **AWS Cost Explorer**: 実際の使用量ベースでのコスト分析
- **AWS Trusted Advisor**: コスト最適化の推奨事項

---

## 8. 次のステップ

1. **詳細設計**: 要件に応じた詳細なアーキテクチャ設計
2. **PoC実施**: 小規模環境での概念実証
3. **移行計画**: 段階的な移行スケジュールの策定
4. **コスト最適化**: リザーブドインスタンス等の検討
5. **運用体制**: 24/7運用体制の構築

---

**免責事項**: 
この見積書は2025年7月時点のAWS価格情報に基づいて作成されています。実際の料金は使用量や設定により変動する可能性があります。正確な料金については、AWS公式の料金計算ツールや営業担当者にご相談ください。
