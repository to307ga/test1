# CloudFormation テンプレート - ローカルファイル参照版

このディレクトリには、**ローカルファイル参照方式**でCloudFormationテンプレートを管理するためのSceptre設定が含まれています。

## 概要

ローカルファイル参照方式は、**ネストスタックのS3依存を回避**し、開発・テスト環境で柔軟にCloudFormationテンプレートを運用するためのアプローチです。

### 特徴

- ✅ **S3バケット不要**: テンプレートはローカルファイルシステムから直接参照
- ✅ **開発効率向上**: テンプレート変更後即座にデプロイ可能
- ✅ **テンプレート再利用**: 個別テンプレートを活用しつつ依存関係を管理
- ✅ **依存関係制御**: Sceptreの依存管理で適切なデプロイ順序を保証
- ✅ **コスト削減**: S3ストレージコスト不要

## アーキテクチャ

### スタック構成

```
01. EIP        - Elastic IP Address
02. VPC        - Virtual Private Cloud + Subnets
03. Security   - Security Groups + SSM VPC Endpoints  
04. Aurora     - Aurora MySQL Cluster
05. S3         - S3 Bucket + CloudFront OAC
06. ALB        - Application Load Balancer
07. EC2        - Web/App Servers with SSM Session Manager
08. CloudFront - CDN Distribution
```

### 依存関係

```
EIP → VPC → Security → Aurora
          ↓         ↓
          S3 → ALB → EC2 → CloudFront
```

## ディレクトリ構成

```
idhub/
├── sceptre/
│   ├── config-local/           # ローカル参照版設定
│   │   └── dev/               # 開発環境設定
│   │       ├── 01-eip-local.yaml
│   │       ├── 02-vpc-local.yaml
│   │       ├── 03-security-local.yaml
│   │       ├── 04-aurora-local.yaml
│   │       ├── 05-s3-local.yaml
│   │       ├── 06-alb-local.yaml
│   │       ├── 07-ec2-local.yaml
│   │       └── 08-cloudfront-local.yaml
│   └── templates/             # 共通テンプレート
│       ├── eip.yaml
│       ├── vpc.yaml
│       ├── security-ssm.yaml
│       ├── aurora.yaml
│       ├── s3.yaml
│       ├── alb.yaml
│       ├── ec2-web-ssm.yaml
│       └── cloudfront.yaml
├── deploy-local.sh           # デプロイスクリプト
└── README-local.md          # このファイル
```

## 前提条件

### 必要ツール

```bash
# AWS CLI v2
aws --version

# Sceptre
pip install sceptre

# 権限確認
aws sts get-caller-identity
```

### AWS権限

以下のサービスに対する管理権限が必要です：
- VPC, EC2, ELB
- RDS (Aurora)
- S3, CloudFront
- IAM, SSM

## セットアップ

### 1. 設定ファイルの確認

各環境の設定ファイルで以下を調整：

```yaml
# dev/01-eip-local.yaml 例
template_path: ../templates/eip.yaml
parameters:
  Environment: dev
  ProjectName: idhub
```

### 2. パラメータのカスタマイズ

環境に応じて以下のパラメータを調整：

- **ProjectName**: プロジェクト名
- **Environment**: 環境名 (dev/stg/prod)
- **InstanceType**: EC2インスタンスタイプ
- **DBInstanceClass**: Auroraインスタンスクラス
- **AllowedCIDR**: アクセス許可するCIDR

## デプロイ方法

### 全スタックのデプロイ

```bash
# 開発環境に全スタックをデプロイ
./deploy-local.sh dev deploy

# ステージング環境にデプロイ  
./deploy-local.sh stg deploy

# 本番環境にデプロイ
./deploy-local.sh prod deploy
```

### 個別スタックのデプロイ

```bash
# VPCのみデプロイ
./deploy-local.sh dev deploy 02-vpc-local.yaml

# EC2のみデプロイ
./deploy-local.sh dev deploy 07-ec2-local.yaml
```

### 状態確認

```bash
# 全スタックの状態確認
./deploy-local.sh dev status

# 出力値の確認
./deploy-local.sh dev outputs

# 特定スタックの出力確認
./deploy-local.sh dev outputs 02-vpc-local.yaml
```

### 差分確認

```bash
# 全スタックの差分確認
./deploy-local.sh dev diff

# 特定スタックの差分確認
./deploy-local.sh dev diff 07-ec2-local.yaml
```

### テンプレート検証

```bash
# 全テンプレートの検証
./deploy-local.sh dev validate

# 特定テンプレートの検証
./deploy-local.sh dev validate 03-security-local.yaml
```

## 削除方法

### 全スタックの削除

```bash
# 開発環境の全スタックを削除（逆順）
./deploy-local.sh dev delete
```

### 個別スタックの削除

```bash
# 特定スタックのみ削除
./deploy-local.sh dev delete 08-cloudfront-local.yaml
```

## SSM Session Manager

このテンプレートではSSH鍵の代わりにAWS Systems Manager Session Managerを使用します。

### EC2インスタンスへの接続

```bash
# インスタンス一覧の確認
aws ec2 describe-instances --filters "Name=tag:Environment,Values=dev" \
  --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value|[0],State.Name]' \
  --output table

# Session Managerで接続
aws ssm start-session --target i-xxxxxxxxxxxxxxxxx

# ポートフォワーディング（例：8080番ポート）
aws ssm start-session --target i-xxxxxxxxxxxxxxxxx \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["8080"],"localPortNumber":["8080"]}'
```

### 必要なVPCエンドポイント

以下のVPCエンドポイントが自動作成されます：
- com.amazonaws.region.ssm
- com.amazonaws.region.ssmmessages  
- com.amazonaws.region.ec2messages

## トラブルシューティング

### 一般的な問題

1. **依存関係エラー**
   ```bash
   # 依存するスタックが先にデプロイされているか確認
   ./deploy-local.sh dev status
   ```

2. **テンプレートパスエラー**
   ```bash
   # テンプレートファイルの存在確認
   ls -la sceptre/templates/
   ```

3. **権限不足エラー**
   ```bash
   # AWS権限の確認
   aws sts get-caller-identity
   aws iam get-user
   ```

### Session Manager接続の問題

1. **インスタンス一覧に表示されない**
   - IAMロールが正しく設定されているか確認
   - VPCエンドポイントが作成されているか確認

2. **接続エラー**
   ```bash
   # SSM Agentの状態確認
   aws ssm describe-instance-information
   ```

## 高度な使用方法

### カスタム環境の追加

```bash
# 新しい環境設定を作成
mkdir -p sceptre/config-local/staging
cp -r sceptre/config-local/dev/* sceptre/config-local/staging/

# 設定ファイルを編集
vim sceptre/config-local/staging/02-vpc-local.yaml
```

### パラメータの外部化

```yaml
# config-local/dev/02-vpc-local.yaml
template_path: ../templates/vpc.yaml
parameters:
  ProjectName: !file_contents ../../../config/project-name.txt
  VpcCidr: !file_contents ../../../config/vpc-cidr.txt
```

### 条件付きデプロイ

```bash
# 条件チェック付きデプロイ
if aws cloudformation describe-stacks --stack-name idhub-dev-vpc >/dev/null 2>&1; then
  echo "VPCスタックは既に存在します"
else
  ./deploy-local.sh dev deploy 02-vpc-local.yaml
fi
```

## 他のアプローチとの比較

| 特徴 | 従来版 | 統合版 | ネスト版 | **ローカル版** |
|------|--------|--------|----------|----------------|
| テンプレート数 | 8個 | 5個 | 5個 | 8個 |
| S3依存 | なし | なし | **あり** | **なし** |
| デプロイ時間 | 長い | 短い | 中程度 | 長い |
| メンテナンス | 複雑 | 簡単 | 中程度 | 中程度 |
| 柔軟性 | 高い | 低い | 中程度 | **高い** |
| 開発効率 | 中程度 | 高い | 中程度 | **最高** |

## 参考資料

- [AWS CloudFormation](https://aws.amazon.com/cloudformation/)
- [Sceptre Documentation](https://sceptre.cloudreach.com/)
- [AWS Systems Manager Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html)
- [CloudFormation Best Practices](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html)

## ライセンス

このテンプレートはサンプル用途で提供されています。本番環境での使用前に十分な検証を行ってください。
