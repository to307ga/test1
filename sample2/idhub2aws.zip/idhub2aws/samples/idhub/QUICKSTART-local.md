# CloudFormation ローカルテンプレート版 - クイックスタート

## 概要

**ネストスタックのS3依存を回避**し、ローカルファイルから直接CloudFormationテンプレートを参照する方式です。

## 特徴

✅ **S3バケット不要** - ローカルファイルシステムから直接参照  
✅ **開発効率向上** - テンプレート変更後即座にデプロイ可能  
✅ **テンプレート再利用** - 既存の個別テンプレートを活用  
✅ **依存関係制御** - Sceptreで適切なデプロイ順序を保証  

## セットアップ

### 1. 必要ツールのインストール

```bash
# AWS CLI v2
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Sceptre
pip install sceptre

# 権限確認
aws sts get-caller-identity
```

### 2. デプロイ実行

```bash
# 開発環境に全スタックをデプロイ
cd /home/t-tomonaga/idhub2aws/samples/idhub
./deploy-local.sh dev deploy

# 状態確認
./deploy-local.sh dev status

# 出力値確認
./deploy-local.sh dev outputs
```

### 3. EC2インスタンスへの接続

```bash
# インスタンス一覧確認
aws ec2 describe-instances --filters "Name=tag:Environment,Values=dev" \
  --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value|[0],State.Name]' \
  --output table

# Session Managerで接続（SSH鍵不要）
aws ssm start-session --target i-xxxxxxxxxxxxxxxxx
```

## スタック構成

```
01. EIP        → 02. VPC        → 03. Security   → 04. Aurora
                      ↓              ↓
                 05. S3        → 06. ALB       → 07. EC2      → 08. CloudFront
```

## 主要コマンド

| アクション | コマンド |
|------------|----------|
| 全デプロイ | `./deploy-local.sh dev deploy` |
| 個別デプロイ | `./deploy-local.sh dev deploy 02-vpc-local.yaml` |
| 状態確認 | `./deploy-local.sh dev status` |
| 差分確認 | `./deploy-local.sh dev diff` |
| 削除 | `./deploy-local.sh dev delete` |

## ディレクトリ構成

```
idhub/
├── sceptre/
│   ├── config-local/          # ローカル参照設定
│   │   ├── dev/              # 開発環境
│   │   ├── stg/              # ステージング環境  
│   │   └── prod/             # 本番環境
│   └── templates/            # 共通テンプレート
├── deploy-local.sh           # デプロイスクリプト
└── README-local.md          # 詳細ドキュメント
```

## 他の方式との比較

| 項目 | 従来版 | 統合版 | ネスト版 | **ローカル版** |
|------|--------|--------|----------|----------------|
| S3依存 | なし | なし | **あり** | **なし** |
| 開発効率 | 中 | 高 | 中 | **最高** |
| 柔軟性 | 高 | 低 | 中 | **高** |

詳細は [README-local.md](README-local.md) を参照してください。
