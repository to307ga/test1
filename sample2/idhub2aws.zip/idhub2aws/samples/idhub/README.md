# idhub AWS CloudFormationプロジェクト

## 概要

idhub（Identity Hub）プロジェクトのAWSインフラストラクチャをCloudFormation + Sceptreで管理するためのプロジェクトです。

### アーキテクチャ

Web三層構造: **CloudFront → ALB → EC2 → Aurora**

```
CloudFront (CDN)
    ↓
Application Load Balancer (ALB)
    ↓
EC2 Auto Scaling Group (Web Servers)
    ↓
Aurora MySQL (Database)
```

## ディレクトリ構造

```
idhub/
├── deploy.sh                          # デプロイメントスクリプト
├── README.md                           # このファイル
└── sceptre/
    ├── config/
    │   ├── config.yaml                 # 全環境共通設定
    │   ├── dev/                        # 開発環境設定（完全版）
    │   │   ├── config.yaml
    │   │   ├── fixed-natgw-eip.yaml
    │   │   ├── s3.yaml
    │   │   ├── vpc.yaml
    │   │   ├── securitygroup.yaml
    │   │   ├── elb.yaml
    │   │   ├── ec2-web.yaml
    │   │   ├── aurora.yaml
    │   │   └── cloudfront.yaml
    │   ├── stg/                        # ステージング環境設定（基本設定のみ）
    │   │   └── config.yaml
    │   └── prod/                       # 本番環境設定（基本設定のみ）
    │       └── config.yaml
    └── templates/
        ├── vpc.yaml                    # VPCテンプレート
        ├── securitygroup.yaml          # セキュリティグループテンプレート
        ├── elb.yaml                    # ALBテンプレート
        ├── ec2-web.yaml               # EC2 Webサーバーテンプレート
        ├── aurora.yaml                 # Auroraテンプレート
        ├── cloudfront.yaml             # CloudFrontテンプレート
        ├── s3.yaml                     # S3テンプレート
        └── fixed-natgw-eip.yaml       # NAT Gateway EIPテンプレート
```

## 段階的開発アプローチ

### 開発戦略

新規プロジェクトでは以下の**段階的アプローチ**を推奨します：

#### Phase 1: 開発環境（dev）での設計・テスト
1. **完全な設定ファイル作成**: dev環境で全リソースの設定ファイルを作成
2. **動作確認**: dev環境でデプロイ・動作確認・調整
3. **テンプレート最適化**: 必要に応じてCloudFormationテンプレートを調整

#### Phase 2: ステージング環境（stg）への展開
1. **dev環境設定をコピー**: 動作確認済みのdev設定をベースに作成
2. **環境固有パラメータ調整**: ネットワーク、スケール、セキュリティ設定の調整
3. **統合テスト**: 本番に近い環境での動作確認

#### Phase 3: 本番環境（prod）への展開  
1. **stg環境設定をベース**: 検証済みのstg設定から作成
2. **本番要件対応**: 高可用性、セキュリティ、監視の強化
3. **本番デプロイ**: 慎重なデプロイとモニタリング

### 現在の状態

このプロジェクトは**Phase 1（dev環境）の状態**です。
- `sceptre/config/dev/` に完全な設定ファイル一式を配置
- `sceptre/config/stg/` と `sceptre/config/prod/` には基本設定のみ

### 環境別設定の違い（参考）

将来的に各環境を展開する際の設定例：

| 項目 | dev | stg | prod |
|------|-----|-----|------|
| **VPC CIDR** | 10.100.0.0/22 | 10.110.0.0/22 | 10.120.0.0/22 |
| **EC2インスタンス** | t3.medium | t3.large | m5.large |
| **Auto Scaling** | 2-6台 | 2-8台 | 4-12台 |
| **DB削除保護** | false | true | true |
| **DB Multi-AZ** | false | false | true |
| **DBインスタンス** | db.t4g.medium | db.t4g.large | db.r6g.large |
| **バックアップ保持** | 7日 | 14日 | 30日 |
| **ドメイン** | dev.idhub.docomo.ne.jp | stg.idhub.docomo.ne.jp | idhub.docomo.ne.jp |
| **CloudFrontキャッシュ** | 短時間 | 中時間 | 長時間 |
| **監視レベル** | 基本 | 標準 | 高度 |
| **ログ保持期間** | 30日 | 90日 | 365日 |

### 次のPhaseへの進め方

#### stg環境展開時
```bash
# dev環境の設定ファイルをstg用にコピー
cp -r sceptre/config/dev/* sceptre/config/stg/
# 環境固有パラメータを調整（VPC CIDR、ドメイン名など）
```

#### prod環境展開時  
```bash
# stg環境の設定ファイルをprod用にコピー
cp -r sceptre/config/stg/* sceptre/config/prod/
# 本番環境固有パラメータを調整（高可用性設定など）
```

## セットアップと前提条件

### 1. AWSアカウント・権限設定

- ドコモCCoE Standard組織のAWSアカウント
- CloudFormation、EC2、VPC、RDS、CloudFront等の作成権限
- S3バケットへの読み書き権限

### 2. 事前準備が必要な項目

#### A. EC2キーペア
```bash
# AWS CLIでキーペアを作成
aws ec2 create-key-pair --key-name idhub-dev-key --query 'KeyMaterial' --output text > idhub-dev-key.pem
chmod 400 idhub-dev-key.pem

# ステージング・本番環境用も作成
aws ec2 create-key-pair --key-name idhub-stg-key --query 'KeyMaterial' --output text > idhub-stg-key.pem
aws ec2 create-key-pair --key-name idhub-prod-key --query 'KeyMaterial' --output text > idhub-prod-key.pem
```

#### B. ACM証明書（CloudFront用）
CloudFrontで使用するSSL証明書は**us-east-1リージョン**で作成する必要があります。

```bash
# バージニア北部リージョンで証明書を作成
aws acm request-certificate \
    --domain-name "*.idhub.docomo.ne.jp" \
    --subject-alternative-names "idhub.docomo.ne.jp" \
    --validation-method DNS \
    --region us-east-1
```

#### C. ドメイン設定
以下のドメインをRoute 53またはDNSプロバイダーで設定：
- `dev.idhub.docomo.ne.jp` (開発環境)
- `stg.idhub.docomo.ne.jp` (ステージング環境)  
- `idhub.docomo.ne.jp` (本番環境)

## パラメータ変更が必要な設定

### 1. 全環境共通設定 (`config/config.yaml`)

```yaml
# プロジェクト名（スタック名に使用）
project_code: idhub  # 変更不要

# タグ設定（必須変更項目）
stack_tags:
  system_name: idhub
  service: identity-hub
  project: idhub-migration
  # 以下は組織・プロジェクトに応じて設定
  map-migrated: "MAP123456"  # AWS MAP2.0契約番号
  PJCD: "4224396UB00000300000001"  # プロジェクトコード
  Owner: "idhub-team@docomo.ne.jp"  # 責任者
  Group: "identity-management"  # グループ名
  Cost: "idhub-cost-center"  # コスト管理
```

### 2. ネットワーク設定 (`config/dev/vpc.yaml`)

```yaml
parameters:
  # idhub用のCIDRブロック（他システムと重複しないよう設定）
  VPCCIDR: 10.100.0.0/22          # 要変更: 組織のIPアドレス体系に合わせる
  
  # サブネット設定（VPC CIDRに合わせて調整）
  FirewallSubnetACIDR: 10.100.0.240/28
  PublicSubnetACIDR: 10.100.0.128/26
  PrivateSubnetACIDR: 10.100.0.0/25
  FirewallSubnetCCIDR: 10.100.1.240/28
  PublicSubnetCCIDR: 10.100.1.128/26
  PrivateSubnetCCIDR: 10.100.1.0/25
  FirewallSubnetDCIDR: 10.100.2.240/28
  PublicSubnetDCIDR: 10.100.2.128/26
  PrivateSubnetDCIDR: 10.100.2.0/25
```

### 3. S3バケット設定 (`config/dev/s3.yaml`)

```yaml
parameters:
  # バケット名は一意である必要があります
  LogBucketName: idhub-dev-logs-YYYYMMDD          # 要変更: 日付等で一意に
  VPCFlowLogBucketName: idhub-dev-vpc-flowlogs-YYYYMMDD
  CloudFrontLogBucketName: idhub-dev-cloudfront-logs-YYYYMMDD
  ALBLogBucketName: idhub-dev-alb-logs-YYYYMMDD
  AccessLogsBucketName: idhub-dev-access-logs-YYYYMMDD
  StaticWebBucketName: idhub-dev-static-web-YYYYMMDD
```

### 4. EC2設定 (`config/dev/ec2-web.yaml`)

```yaml
parameters:
  # インスタンスタイプ（要件に応じて変更）
  InstanceType: t3.medium  # 本番環境では t3.large 以上を推奨
  
  # AMI ID（定期的な更新が必要）
  ImageId: ami-0d52744d6551d851e  # 要確認: 最新のAmazon Linux 2023
  
  # キーペア名
  KeyName: idhub-dev-key  # 事前作成が必要
  
  # Auto Scaling設定
  MinSize: 2              # 最小インスタンス数
  MaxSize: 6              # 最大インスタンス数  
  DesiredCapacity: 2      # 希望インスタンス数
```

### 5. Aurora設定 (`config/dev/aurora.yaml`)

```yaml
parameters:
  # データベース設定
  DatabaseName: idhub_dev
  MasterUsername: idhub_admin
  MasterUserPassword: ChangeMe123!  # 要変更: 強固なパスワードに変更
  
  # インスタンスクラス
  DBInstanceClass: db.t4g.medium  # 本番環境では db.r6g.large 以上を推奨
  
  # バックアップ設定
  BackupRetentionPeriod: 7        # 本番環境では 30 を推奨
  
  # 削除保護
  DeletionProtection: false       # 本番環境では true を設定
```

### 6. CloudFront設定 (`config/dev/cloudfront.yaml`)

```yaml
parameters:
  # カスタムドメイン（要変更）
  DomainName: dev.idhub.docomo.ne.jp
  
  # SSL証明書ARN（要変更: us-east-1リージョンで作成）
  CertificateArn: arn:aws:acm:us-east-1:123456789012:certificate/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  
  # 初期構築時は無効化を推奨
  CloudFrontEnabled: false  # 構築完了後に true に変更
```

## デプロイメント手順

### Phase 1: 開発環境（dev）でのデプロイ

#### 1. 環境の確認
```bash
# AWS認証情報の確認
aws sts get-caller-identity

# リージョンの確認
aws configure get region
```

#### 2. 段階的デプロイ

##### Step 1: 基盤リソースの作成
```bash
# EIP作成
./deploy.sh dev deploy fixed-natgw-eip.yaml

# S3バケット作成
./deploy.sh dev deploy s3.yaml

# VPC作成
./deploy.sh dev deploy vpc.yaml

# セキュリティグループ作成
./deploy.sh dev deploy securitygroup.yaml
```

##### Step 2: アプリケーションリソースの作成
```bash
# ALB作成
./deploy.sh dev deploy elb.yaml

# Aurora作成
./deploy.sh dev deploy aurora.yaml

# EC2 Web サーバー作成
./deploy.sh dev deploy ec2-web.yaml
```

##### Step 3: CloudFront作成（最後）
```bash
# CloudFront作成
./deploy.sh dev deploy cloudfront.yaml
```

#### 3. 全体デプロイ（依存関係自動解決）
```bash
# 全てのリソースを一括デプロイ
./deploy.sh dev deploy
```

#### 4. 状態確認
```bash
# 全スタックの状態確認
./deploy.sh dev status

# 特定スタックの状態確認
./deploy.sh dev status vpc.yaml
```

### Phase 2: ステージング環境（stg）への展開

dev環境での動作確認が完了したら：

```bash
# dev環境の設定をstg用にコピー
cp -r sceptre/config/dev/* sceptre/config/stg/

# stg環境固有のパラメータ調整
# - VPC CIDR: 10.110.0.0/22
# - ドメイン名: stg.idhub.docomo.ne.jp
# - インスタンスサイズの調整など

# stg環境デプロイ
./deploy.sh stg deploy
```

### Phase 3: 本番環境（prod）への展開

stg環境での検証が完了したら：

```bash
# stg環境の設定をprod用にコピー
cp -r sceptre/config/stg/* sceptre/config/prod/

# prod環境固有のパラメータ調整
# - VPC CIDR: 10.120.0.0/22
# - ドメイン名: idhub.docomo.ne.jp
# - 高可用性設定（Multi-AZ、削除保護など）
# - 本番用インスタンスサイズなど

# prod環境デプロイ
./deploy.sh prod deploy
```

## 運用コマンド

### スタック出力値の確認
```bash
cd sceptre
sceptre list outputs dev/vpc.yaml
sceptre list outputs dev/elb.yaml
sceptre list outputs dev/aurora.yaml
```

### ログの確認
```bash
# CloudFormationイベントの確認
aws cloudformation describe-stack-events --stack-name idhub-dev-vpc

# ALBアクセスログの確認
aws s3 ls s3://idhub-dev-alb-logs-YYYYMMDD/
```

### アプリケーションデプロイ（EC2へのアプリ配置）

EC2インスタンスが作成された後、アプリケーションコードをデプロイします：

```bash
# SSH接続（踏み台サーバー経由）
ssh -i idhub-dev-key.pem ec2-user@<private-ip>

# アプリケーションのインストール・設定
sudo yum update -y
sudo yum install -y httpd php mysql
# アプリケーション固有の設定...
```

## セキュリティ設定

### 1. パスワード管理
本番環境では以下を実装：
- AWS Secrets Managerでのパスワード管理
- IAMロールベースの認証
- 定期的なパスワードローテーション

### 2. ネットワークセキュリティ
- WAF (Web Application Firewall) の設定
- VPC Flow Logsの有効化
- Network Firewallルールの設定

### 3. 監視・ログ
- CloudWatchでの監視設定
- ALB、CloudFrontアクセスログの分析
- セキュリティグループルールの定期見直し

## 環境別設定の違い

| 項目 | dev | stg | prod |
|------|-----|-----|------|
| VPC CIDR | 10.100.0.0/22 | 10.110.0.0/22 | 10.120.0.0/22 |
| EC2インスタンス数 | 2-6 | 2-8 | 4-12 |
| DB削除保護 | false | true | true |
| CloudFrontキャッシュ | 短時間 | 中時間 | 長時間 |
| バックアップ保持期間 | 7日 | 14日 | 30日 |

## トラブルシューティング

### よくあるエラー

1. **AMI IDが見つからない**
   ```bash
   # 最新のAmazon Linux 2023 AMI IDを取得
   aws ec2 describe-images --owners amazon --filters "Name=name,Values=al2023-ami-*" --query 'Images[*].[ImageId,Name]' --output table
   ```

2. **S3バケット名の重複**
   - バケット名に日付やランダム文字列を追加

3. **VPC CIDR重複**
   - 既存VPCとのCIDR重複を避ける

4. **証明書エラー**
   - CloudFront用証明書はus-east-1リージョンで作成

### ロールバック手順
```bash
# 特定スタックの削除
./deploy.sh dev delete ec2-web.yaml

# 全スタックの削除（逆順で実行）
./deploy.sh dev delete
```

## 参考資料

- [AWS CloudFormation ユーザーガイド](https://docs.aws.amazon.com/ja_jp/AWSCloudFormation/latest/UserGuide/)
- [Sceptre ドキュメント](https://sceptre.cloudreach.com/)
- [ドコモCCoE AWSガイド](https://ccoe.zendesk.com/)

## 問い合わせ先

- **技術的な質問**: idhub-infra-team@docomo.ne.jp
- **AWS関連**: ドコモCCoE Standard組織サポート
- **緊急時**: idhub-oncall@docomo.ne.jp
