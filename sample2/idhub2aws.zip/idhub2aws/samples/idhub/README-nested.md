# idhub プロジェクト - ネストされたスタック版

## 概要

このディレクトリには、**ネストされたスタック**（Nested Stacks）を使用して、既存の個別テンプレートを再利用しながらベストプラクティスに基づいた構成を実現するテンプレートが含まれています。

## 🏗️ ネストされたスタック構成

### アーキテクチャ
```
Parent Stack (core-infra-nested.yaml)
├── Child Stack 1: fixed-natgw-eip.yaml
└── Child Stack 2: vpc.yaml
    └── 依存関係: EIP → VPC

Parent Stack (security-nested.yaml)
├── Child Stack 1: securitygroup.yaml
└── Child Stack 2: iam-roles.yaml

Parent Stack (database-nested.yaml)
└── Child Stack: aurora.yaml

Parent Stack (app-tier-nested.yaml)
├── Child Stack 1: s3.yaml
├── Child Stack 2: elb.yaml
└── Child Stack 3: ec2-web.yaml
    └── 依存関係: S3 → ALB → EC2

Parent Stack (cdn-nested.yaml)
└── Child Stack: cloudfront.yaml
```

### 📁 ディレクトリ構造

```
sceptre/
├── templates/                        # 個別テンプレート（既存）
│   ├── vpc.yaml
│   ├── fixed-natgw-eip.yaml
│   ├── securitygroup.yaml
│   ├── iam-roles.yaml               # 新規追加
│   ├── s3.yaml
│   ├── elb.yaml
│   ├── ec2-web.yaml
│   ├── aurora.yaml
│   └── cloudfront.yaml
├── templates-nested/                 # ネストされたスタックテンプレート
│   ├── core-infra-nested.yaml
│   ├── security-nested.yaml
│   ├── database-nested.yaml
│   ├── app-tier-nested.yaml
│   └── cdn-nested.yaml
├── config-nested/                    # ネストされたスタック設定
│   ├── config.yaml
│   └── dev/
│       ├── config.yaml
│       ├── 01-core-infra-nested.yaml
│       ├── 02-security-nested.yaml
│       ├── 03-database-nested.yaml
│       ├── 04-app-tier-nested.yaml
│       └── 05-cdn-nested.yaml
└── config/                          # 従来の設定（並行利用可能）
```

## 🎯 ネストされたスタックの利点

### ✅ **既存テンプレートの再利用**
- `templates/` ディレクトリの既存テンプレートをそのまま使用
- 個別テンプレートの変更が自動的にネストされたスタックに反映
- 開発投資の無駄なし

### ✅ **ベストプラクティスの適用**
- ライフサイクル重視のグルーピング
- 変更影響範囲の最小化
- 運用効率の向上

### ✅ **段階的な移行**
- 従来の個別スタック構成と並行運用可能
- 段階的にネストされたスタックへ移行
- リスクの最小化

## 🚀 デプロイメント手順

### 1. 事前準備

```bash
# AWS認証情報の確認
aws sts get-caller-identity

# AWS CLI Session Manager Plugin のインストール（必要に応じて）
curl "https://s3.amazonaws.com/session-manager-downloads/plugin/latest/linux_64bit/session-manager-plugin.rpm" -o "session-manager-plugin.rpm"
sudo yum install -y session-manager-plugin.rpm

# EC2 Key Pair は不要（SSM Session Manager使用）
# 従来のSSH接続は廃止し、SSM Session Managerを使用
```

### 2. S3バケットの設定とテンプレートアップロード

```bash
# S3バケット作成と個別テンプレートのアップロード
./deploy-nested.sh dev setup
```

このコマンドで以下が実行されます：
- S3バケット `idhub-dev-sceptre-templates` の作成
- `templates/` ディレクトリの全ファイルをS3にアップロード
- CloudFormationがネストされたスタックでテンプレートを参照可能に

### 3. ネストされたスタックのデプロイ

```bash
# Core Infrastructure をデプロイ
./deploy-nested.sh dev deploy 01-core-infra-nested.yaml

# Security をデプロイ
./deploy-nested.sh dev deploy 02-security-nested.yaml

# Database をデプロイ
./deploy-nested.sh dev deploy 03-database-nested.yaml

# Application Tier をデプロイ
./deploy-nested.sh dev deploy 04-app-tier-nested.yaml

# CDN をデプロイ
./deploy-nested.sh dev deploy 05-cdn-nested.yaml

# 全スタック一括デプロイ
./deploy-nested.sh dev deploy

# 状態確認
./deploy-nested.sh dev status

# 出力確認
./deploy-nested.sh dev outputs 04-app-tier-nested.yaml
```

### 4. テンプレート検証

```bash
# 全テンプレートの検証
./deploy-nested.sh dev validate

# 特定テンプレートの検証
./deploy-nested.sh dev validate 01-core-infra-nested.yaml
```

## � SSM Session Manager による鍵管理フリー運用

### EC2インスタンスへの接続

```bash
# インスタンスの一覧取得
aws ec2 describe-instances \
  --filters "Name=tag:Environment,Values=dev" "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].[InstanceId,Tags[?Key==`Name`].Value[0]]' \
  --output table

# SSM Session Managerでインスタンスに接続
aws ssm start-session --target i-1234567890abcdef0

# 特定のユーザーでセッション開始
aws ssm start-session --target i-1234567890abcdef0 \
  --document-name AWS-StartInteractiveCommand \
  --parameters command="sudo su - ec2-user"
```

### データベースへの接続

```bash
# ポートフォワーディングでDBに接続
aws ssm start-session --target i-1234567890abcdef0 \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["3306"],"localPortNumber":["3306"]}'

# 別ターミナルでMySQLクライアントから接続
mysql -h 127.0.0.1 -P 3306 -u admin -p
```

### 秘密情報の管理

```bash
# SSM Parameter Storeから値を取得（EC2インスタンス内で）
aws ssm get-parameter --name "/idhub/dev/db/password" --with-decryption \
  --query 'Parameter.Value' --output text

# 複数パラメータの一括取得
aws ssm get-parameters-by-path --path "/idhub/dev/" --recursive --with-decryption
```

### ファイル転送

```bash
# ローカルからEC2へファイル転送
aws ssm start-session --target i-1234567890abcdef0 \
  --document-name AWS-StartPortForwardingSession \
  --parameters '{"portNumber":["22"],"localPortNumber":["2222"]}'

# SCPでファイル転送（SSMトンネル経由）
scp -P 2222 local-file.txt ec2-user@127.0.0.1:/home/ec2-user/

# または、S3経由でファイル共有
aws s3 cp local-file.txt s3://idhub-dev-app-assets-<account-id>/
# EC2インスタンス内で
aws s3 cp s3://idhub-dev-app-assets-<account-id>/local-file.txt ./
```

## 📊 ネストされたスタックのメカニズム

### Parent-Child 関係

```yaml
# Parent Stack (core-infra-nested.yaml)
Resources:
  EIPStack:
    Type: AWS::CloudFormation::Stack
    Properties:
      TemplateURL: 'https://s3-bucket/templates/fixed-natgw-eip.yaml'
      Parameters:
        ProjectName: !Ref ProjectName
        Environment: !Ref Environment

  VPCStack:
    Type: AWS::CloudFormation::Stack
    Properties:
      TemplateURL: 'https://s3-bucket/templates/vpc.yaml'
      Parameters:
        FixedNatGwEipAllocationId: !GetAtt EIPStack.Outputs.EIPAllocationId
```

### 依存関係管理
- **自動的な順序制御**: Child Stackの依存関係を自動解決
- **出力の連携**: `!GetAtt ChildStack.Outputs.OutputName` で値を取得
- **エラーハンドリング**: Child Stackのエラーが Parent Stack に伝播

## 🔧 カスタマイズとメンテナンス

### 個別テンプレートの更新
```bash
# 1. 個別テンプレートを編集
vim sceptre/templates/vpc.yaml

# 2. S3に再アップロード
./deploy-nested.sh dev setup

# 3. ネストされたスタックを再デプロイ
./deploy-nested.sh dev deploy 01-core-infra-nested.yaml
```

### 新しい Child Stack の追加
```yaml
# Parent Stack に新しいリソースを追加
NewChildStack:
  Type: AWS::CloudFormation::Stack
  Properties:
    TemplateURL: !Sub 'https://${TemplateS3Bucket}.s3.amazonaws.com/${TemplateS3KeyPrefix}/new-template.yaml'
    Parameters:
      Parameter1: !Ref SomeParameter
      Parameter2: !GetAtt ExistingStack.Outputs.SomeOutput
```

## 📈 運用上の考慮事項

### S3テンプレート管理
- **バージョニング**: S3バケットのバージョニング有効化推奨
- **バックアップ**: 定期的なテンプレートバックアップ
- **アクセス制御**: 適切なIAMポリシーの設定

### スタック制限
- **ネスト深度**: 最大5階層まで
- **リソース数**: Parent + Child で合計500リソースまで
- **テンプレートサイズ**: S3経由で最大51,200バイト

### 監視とログ
- **CloudTrail**: スタック操作の監査ログ
- **CloudWatch**: スタック作成/更新のメトリクス
- **通知**: SNSを使用したデプロイ状況の通知

## 🔄 移行戦略

### 段階的移行アプローチ

#### Phase 1: ネストされたスタック環境の並行構築
```bash
# 既存環境を維持しながら新環境を構築
./deploy-nested.sh dev-nested setup
./deploy-nested.sh dev-nested deploy
```

#### Phase 2: 動作検証とテスト
```bash
# 機能テストとパフォーマンステスト
# 既存環境との比較検証
```

#### Phase 3: 本格移行
```bash
# 既存環境の停止
./deploy.sh dev delete

# ネストされたスタック環境への切り替え
# DNS設定の変更など
```

## 🔒 セキュリティ考慮事項

### S3バケットセキュリティ
```yaml
# バケットポリシーでアクセス制御
BucketPolicy:
  Type: AWS::S3::BucketPolicy
  Properties:
    Bucket: !Ref TemplateS3Bucket
    PolicyDocument:
      Statement:
        - Effect: Allow
          Principal:
            Service: cloudformation.amazonaws.com
          Action: s3:GetObject
          Resource: !Sub "${TemplateS3Bucket}/templates/*"
```

### IAMロール権限
- CloudFormationサービスロールの最小権限設定
- Cross-account access の制御
- リソース固有の権限管理

### SSM関連のセキュリティ
- **VPC Endpoints**: プライベートサブネット内でのSSM接続
- **IAM権限**: SSM Session Manager の最小権限設定
- **ログ記録**: Session Manager のセッションログをCloudWatchに記録
- **鍵管理**: SSH秘密鍵が不要、Parameter Store/Secrets Managerで秘密情報管理

## 📚 参考情報

- [AWS CloudFormation Nested Stacks](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-nested-stacks.html)
- [CloudFormation Best Practices](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html)
- [Sceptre Documentation](https://sceptre.cloudreach.com/)

## 🤝 従来構成との比較

| 観点 | ネストされたスタック（SSM） | 従来の個別スタック | 統合スタック |
|------|---------------------|-------------------|--------------|
| **既存資産活用** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ |
| **ベストプラクティス** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **移行コスト** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ |
| **運用複雑性** | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ |
| **変更影響範囲** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **セキュリティ** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| **鍵管理** | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ |

ネストされたスタック構成は、**既存投資を最大限活用しながら段階的にベストプラクティスを適用**する最適なアプローチです。

## 🎉 SSM Session Manager の利点

### ✅ **鍵管理からの解放**
- SSH秘密鍵の生成・配布・ローテーション不要
- 鍵の紛失・漏洩リスク完全排除
- セキュリティコンプライアンス要件の簡素化

### ✅ **運用効率の向上**
- インターネット経由でのSSH接続不要
- VPN接続なしでプライベートサブネットのインスタンスにアクセス
- 一元的なアクセス制御とログ記録

### ✅ **コスト削減**
- バスチョンホスト不要
- VPN Gateway 不要
- SSH鍵管理システム不要

### ✅ **セキュリティ強化**
- IAMベースのアクセス制御
- 全セッションのCloudTrail/CloudWatchログ
- MFA（多要素認証）対応
- セッション記録・監査機能
