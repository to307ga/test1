#!/bin/bash

# ローカルテンプレート対応のデプロイスクリプト
# 使用方法: ./deploy-local.sh <environment> <action> [stack-file]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 設定
SCEPTRE_DIR="sceptre"
CONFIG_DIR="$SCEPTRE_DIR/config-local"

# 使用方法の表示
usage() {
    echo "使用方法: $0 <environment> <action> [stack-file]"
    echo ""
    echo "Environment:"
    echo "  dev, stg, prod"
    echo ""
    echo "Actions:"
    echo "  deploy    - スタックをデプロイ"
    echo "  delete    - スタックを削除"
    echo "  status    - スタックの状態を確認"
    echo "  outputs   - スタックの出力を表示"
    echo "  validate  - テンプレートを検証"
    echo "  diff      - スタックの差分を確認"
    echo ""
    echo "Examples:"
    echo "  $0 dev deploy                    # 全スタックをデプロイ"
    echo "  $0 dev deploy 02-vpc-local.yaml  # 特定スタックをデプロイ"
    echo "  $0 dev status                    # 全スタックの状態確認"
    echo "  $0 dev diff 02-vpc-local.yaml    # 特定スタックの差分確認"
    exit 1
}

# 引数チェック
if [ $# -lt 2 ]; then
    usage
fi

ENVIRONMENT=$1
ACTION=$2
STACK_FILE=$3

# 環境チェック
if [[ ! "$ENVIRONMENT" =~ ^(dev|stg|prod)$ ]]; then
    echo "エラー: 無効な環境です: $ENVIRONMENT"
    usage
fi

# アクションチェック
if [[ ! "$ACTION" =~ ^(deploy|delete|status|outputs|validate|diff)$ ]]; then
    echo "エラー: 無効なアクションです: $ACTION"
    usage
fi

# 設定ディレクトリの存在確認
if [ ! -d "$CONFIG_DIR/$ENVIRONMENT" ]; then
    echo "エラー: 環境設定ディレクトリが見つかりません: $CONFIG_DIR/$ENVIRONMENT"
    exit 1
fi

# Sceptreコマンドの構築
SCEPTRE_CMD="sceptre --config-dir $CONFIG_DIR"

# スタック指定の処理
if [ -n "$STACK_FILE" ]; then
    # 特定のスタックを指定
    if [ ! -f "$CONFIG_DIR/$ENVIRONMENT/$STACK_FILE" ]; then
        echo "エラー: スタック設定ファイルが見つかりません: $CONFIG_DIR/$ENVIRONMENT/$STACK_FILE"
        exit 1
    fi
    STACK_PATH="$ENVIRONMENT/$STACK_FILE"
else
    # 全スタックを対象
    STACK_PATH="$ENVIRONMENT"
fi

# アクション実行
echo "========================================="
echo "環境: $ENVIRONMENT"
echo "アクション: $ACTION"
echo "スタック: ${STACK_FILE:-"全スタック"}"
echo "テンプレート: ローカルファイル使用"
echo "========================================="

case $ACTION in
    deploy)
        echo "デプロイを開始します..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD launch $STACK_PATH --yes
        else
            # 順序を考慮した全体デプロイ（ローカルテンプレート版）
            echo "1. EIP をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/01-eip-local.yaml --yes
            
            echo "2. VPC をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/02-vpc-local.yaml --yes
            
            echo "3. Security をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/03-security-local.yaml --yes
            
            echo "4. Aurora をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/04-aurora-local.yaml --yes
            
            echo "5. S3 をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/05-s3-local.yaml --yes
            
            echo "6. ALB をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/06-alb-local.yaml --yes
            
            echo "7. EC2 をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/07-ec2-local.yaml --yes
            
            echo "8. CloudFront をデプロイ中..."
            $SCEPTRE_CMD launch $ENVIRONMENT/08-cloudfront-local.yaml --yes
        fi
        echo "デプロイが完了しました。"
        ;;
    
    delete)
        echo "削除を開始します..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD delete $STACK_PATH --yes
        else
            # 逆順で削除
            echo "8. CloudFront を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/08-cloudfront-local.yaml --yes || true
            
            echo "7. EC2 を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/07-ec2-local.yaml --yes || true
            
            echo "6. ALB を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/06-alb-local.yaml --yes || true
            
            echo "5. S3 を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/05-s3-local.yaml --yes || true
            
            echo "4. Aurora を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/04-aurora-local.yaml --yes || true
            
            echo "3. Security を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/03-security-local.yaml --yes || true
            
            echo "2. VPC を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/02-vpc-local.yaml --yes || true
            
            echo "1. EIP を削除中..."
            $SCEPTRE_CMD delete $ENVIRONMENT/01-eip-local.yaml --yes || true
        fi
        echo "削除が完了しました。"
        ;;
    
    status)
        echo "スタックの状態を確認中..."
        $SCEPTRE_CMD list $STACK_PATH
        ;;
    
    outputs)
        echo "スタックの出力を表示中..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD list outputs $STACK_PATH
        else
            echo "全スタックの出力:"
            for stack in 01-eip-local.yaml 02-vpc-local.yaml 03-security-local.yaml 04-aurora-local.yaml 05-s3-local.yaml 06-alb-local.yaml 07-ec2-local.yaml 08-cloudfront-local.yaml; do
                if [ -f "$CONFIG_DIR/$ENVIRONMENT/$stack" ]; then
                    echo "--- $stack ---"
                    $SCEPTRE_CMD list outputs $ENVIRONMENT/$stack || true
                    echo ""
                fi
            done
        fi
        ;;
    
    validate)
        echo "テンプレートを検証中..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD validate $STACK_PATH
        else
            for stack in 01-eip-local.yaml 02-vpc-local.yaml 03-security-local.yaml 04-aurora-local.yaml 05-s3-local.yaml 06-alb-local.yaml 07-ec2-local.yaml 08-cloudfront-local.yaml; do
                if [ -f "$CONFIG_DIR/$ENVIRONMENT/$stack" ]; then
                    echo "検証中: $stack"
                    $SCEPTRE_CMD validate $ENVIRONMENT/$stack
                fi
            done
        fi
        echo "検証が完了しました。"
        ;;
    
    diff)
        echo "スタックの差分を確認中..."
        if [ -n "$STACK_FILE" ]; then
            $SCEPTRE_CMD diff $STACK_PATH
        else
            for stack in 01-eip-local.yaml 02-vpc-local.yaml 03-security-local.yaml 04-aurora-local.yaml 05-s3-local.yaml 06-alb-local.yaml 07-ec2-local.yaml 08-cloudfront-local.yaml; do
                if [ -f "$CONFIG_DIR/$ENVIRONMENT/$stack" ]; then
                    echo "--- $stack の差分 ---"
                    $SCEPTRE_CMD diff $ENVIRONMENT/$stack || true
                    echo ""
                fi
            done
        fi
        ;;
esac

echo "処理が完了しました。"
