# idhub プロジェクト - リストラクチャリング版

## 概要

このディレクトリには、CloudFormationベストプラクティスに基づいてリストラクチャリングされた、5層構成のAWSインフラストラクチャテンプレートが含まれています。

## アーキテクチャ構成

### 🏗️ 5層スタック構成（提案3: 運用重視）

```
1. Core Infrastructure (01-core-infra.yaml)
   ├── VPC, Subnets
   ├── Internet Gateway
   ├── NAT Gateway
   ├── Elastic IP
   └── Route Tables

2. Security & Access (02-security.yaml)
   ├── Security Groups (ALB, EC2, Aurora, Bastion)
   ├── IAM Roles (EC2, Aurora Monitoring)
   └── IAM Policies

3. Database (03-database.yaml)
   ├── Aurora MySQL Cluster
   ├── DB Parameter Groups
   ├── DB Subnet Group
   └── Enhanced Monitoring

4. Application Tier (04-app-tier.yaml)
   ├── Application Load Balancer
   ├── Auto Scaling Group
   ├── EC2 Instances
   ├── S3 Bucket
   └── CloudWatch Alarms

5. Content Delivery Network (05-cdn.yaml)
   ├── CloudFront Distribution
   ├── Origin Access Control
   └── Custom Error Pages
```

## ディレクトリ構造

```
sceptre/
├── templates-restructured/          # 5層構成テンプレート
│   ├── core-infra.yaml
│   ├── security.yaml
│   ├── database.yaml
│   ├── app-tier.yaml
│   └── cdn.yaml
├── config-restructured/             # 5層構成設定
│   ├── config.yaml
│   └── dev/
│       ├── config.yaml
│       ├── 01-core-infra.yaml
│       ├── 02-security.yaml
│       ├── 03-database.yaml
│       ├── 04-app-tier.yaml
│       └── 05-cdn.yaml
├── templates/                       # 従来の8層構成テンプレート
└── config/                          # 従来の8層構成設定
```

## 🎯 ベストプラクティスの適用

### ライフサイクル管理
- **Core Infrastructure**: 長期間（数年単位）- 基盤ネットワーク
- **Security**: 中長期（月〜年単位）- セキュリティポリシー
- **Database**: 中長期（月〜年単位）- データ永続化層
- **Application Tier**: 短〜中期（日〜月単位）- アプリケーション要件
- **CDN**: 中期（週〜月単位）- コンテンツ配信設定

### 変更影響の最小化
- 各層が明確な責任を持つため、変更時の影響範囲を限定
- アプリケーション変更時にインフラ基盤への影響なし
- データベース設定変更時にネットワーク設定への影響なし

## デプロイメント手順

### 1. 事前準備

```bash
# EC2 Key Pair の作成（事前に実施）
aws ec2 create-key-pair --key-name idhub-dev-keypair --query 'KeyMaterial' --output text > idhub-dev-keypair.pem
chmod 400 idhub-dev-keypair.pem
```

### 2. 全スタックデプロイ

```bash
# 依存関係を考慮した順次デプロイ
./deploy-restructured.sh dev deploy

# または個別デプロイ
./deploy-restructured.sh dev deploy 01-core-infra.yaml
./deploy-restructured.sh dev deploy 02-security.yaml
./deploy-restructured.sh dev deploy 03-database.yaml
./deploy-restructured.sh dev deploy 04-app-tier.yaml
./deploy-restructured.sh dev deploy 05-cdn.yaml
```

### 3. 状態確認

```bash
# 全スタックの状態確認
./deploy-restructured.sh dev status

# 特定スタックの出力確認
./deploy-restructured.sh dev outputs 04-app-tier.yaml
```

### 4. テンプレート検証

```bash
# 全テンプレートの検証
./deploy-restructured.sh dev validate

# 特定テンプレートの検証
./deploy-restructured.sh dev validate 01-core-infra.yaml
```

## 📊 従来構成との比較

| 観点 | 5層構成（提案3） | 従来の8層構成 |
|------|----------------|---------------|
| **管理の簡素性** | ⭐⭐⭐ | ⭐⭐ |
| **変更の影響範囲** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **デプロイ時間** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **運用の柔軟性** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **ライフサイクル管理** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |

## 🔧 各スタックの詳細

### 1. Core Infrastructure Stack
- **目的**: ネットワーク基盤の構築
- **変更頻度**: 非常に低い（年単位）
- **含まれるリソース**: VPC、サブネット、ゲートウェイ、ルートテーブル

### 2. Security Stack
- **目的**: セキュリティポリシーの一元管理
- **変更頻度**: 低〜中程度（月単位）
- **含まれるリソース**: セキュリティグループ、IAMロール、ポリシー

### 3. Database Stack
- **目的**: データ永続化層の専用管理
- **変更頻度**: 低〜中程度（月単位）
- **含まれるリソース**: Aurora クラスター、パラメータグループ

### 4. Application Tier Stack
- **目的**: アプリケーション実行環境
- **変更頻度**: 高い（日〜週単位）
- **含まれるリソース**: ALB、EC2、Auto Scaling、S3

### 5. CDN Stack
- **目的**: コンテンツ配信とパフォーマンス最適化
- **変更頻度**: 中程度（週〜月単位）
- **含まれるリソース**: CloudFront、Origin Access Control

## 🚀 運用上の利点

### スケーラブルな運用
- 各層独立したデプロイが可能
- 段階的なリリース戦略に適合
- ロールバック時の影響範囲限定

### 効率的なトラブルシューティング
- 問題の切り分けが容易
- ログやメトリクスの分離
- 専門チームによる責任分担

### コスト最適化
- 各層での個別最適化
- 不要なリソースの特定が容易
- 環境別のコスト管理

## 📝 カスタマイズ

### 環境別設定
```yaml
# dev環境の例
DBInstanceClass: db.t3.medium
DesiredCapacity: 1
EnableDeletionProtection: false

# prod環境の例
DBInstanceClass: db.r5.large
DesiredCapacity: 2
EnableDeletionProtection: true
```

### セキュリティ設定
- セキュリティグループルールの調整
- IAMポリシーの細分化
- VPCエンドポイントの追加

## 🔒 セキュリティ考慮事項

### データベースセキュリティ
- パスワードはAWS Secrets Managerの使用を推奨
- 暗号化の有効化（保存時・転送時）
- Enhanced Monitoring の有効化

### ネットワークセキュリティ
- プライベートサブネットでのリソース配置
- セキュリティグループの最小権限原則
- VPC Flow Logs の有効化（本番環境）

## 📚 参考情報

- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)
- [CloudFormation Best Practices](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html)
- [Sceptre Documentation](https://sceptre.cloudreach.com/)
