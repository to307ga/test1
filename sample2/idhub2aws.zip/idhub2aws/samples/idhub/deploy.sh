#!/bin/bash

# idhub Sceptreデプロイメントスクリプト
# 使用方法: ./deploy.sh [環境] [アクション] [スタック名（オプション）]
# 例: ./deploy.sh dev deploy
# 例: ./deploy.sh dev status vpc.yaml

set -e

ENVIRONMENT=${1:-dev}
ACTION=${2:-status}
STACK=${3:-""}

if [ -z "$ENVIRONMENT" ] || [ -z "$ACTION" ]; then
    echo "使用方法: $0 [環境] [アクション] [スタック名（オプション）]"
    echo "環境: dev, stg, prod"
    echo "アクション: deploy, delete, status, validate"
    exit 1
fi

echo "=== idhub $ENVIRONMENT 環境 $ACTION ==="

# Pythonの仮想環境を作成・有効化（初回のみ）
if [ ! -d "venv" ]; then
    python3 -m venv venv
    source venv/bin/activate
    pip install sceptre
else
    source venv/bin/activate
fi

# 作業ディレクトリをsceptreディレクトリに変更
cd sceptre

if [ -n "$STACK" ]; then
    # 特定のスタックに対してアクションを実行
    sceptre $ACTION $ENVIRONMENT/$STACK
else
    # 環境全体に対してアクションを実行
    sceptre $ACTION $ENVIRONMENT/
fi

echo "=== 完了 ==="
