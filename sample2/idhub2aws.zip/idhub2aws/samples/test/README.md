# Test Jenkins Infrastructure with ECS Fargate

このプロジェクトは、AWS ECS Fargateを使用してJenkinsを運用するためのCloudFormationテンプレート集です。Sceptreを使用してローカルファイル参照方式で管理します。

## 構成オプション

このプロジェクトには2つの構成オプションが用意されています：

| 構成 | ディレクトリ | スタック数 | 特徴 |
|------|-------------|-----------|------|
| **フラット構成** | `sceptre/` | 8個 | シンプルな番号順管理 |
| **3層構成** | `sceptre-3tier/` | 8個 | 論理的な層別管理 |

どちらも同じ8つのCloudFormationスタックを作成しますが、管理方法が異なります。

## 要件

### 元の要件
ユーザーから要求された基本要件：

1. **VPC**: 仮想プライベートクラウド
2. **3つのAvailability Zone**: ap-northeast-1a, ap-northeast-1c, ap-northeast-1d
3. **AWS Network Firewall**: セキュリティ制御とログ監視
4. **NAT Gateway**: プライベートサブネットからのインターネットアクセス
5. **EC2インスタンス**: プライベートサブネット内の管理用サーバー
6. **ECS Fargate**: Jenkins実行環境

### 追加実装したコンポーネント
要件実現のために必要な追加コンポーネント：

1. **Elastic IP (EIP)**: NAT Gateway用の固定IP
2. **Security Groups**: リソース間の通信制御
   - ALB用セキュリティグループ
   - ECS用セキュリティグループ  
   - EC2用セキュリティグループ
   - EFS用セキュリティグループ
3. **IAM Roles**: AWS サービス間の権限管理
   - ECSタスク実行ロール
   - ECSタスクロール
   - EC2用ロール（SSM接続用）
4. **EFS (Elastic File System)**: Jenkinsデータの永続化
5. **Application Load Balancer (ALB)**: 負荷分散とHTTPS終端
6. **CloudWatch Logs**: ログ管理とモニタリング

## アーキテクチャ

### 🏗️ **スタック構成（重要）**

**📊 実際のCloudFormationスタック数: 8個**

```
01. EIP        - NAT Gateway用のElastic IP（追加要件）
02. VPC        - 3つのAZ（A,C,D）とNetwork Firewall（基本要件）
03. Security   - Security Groups for ALB, ECS, EC2, EFS（追加要件）
04. IAM        - ECS Task用のIAMロール（追加要件）
05. EFS        - Jenkinsデータ永続化用（追加要件）
06. ALB        - Application Load Balancer（追加要件）
07. EC2        - プライベートサブネット内の管理用インスタンス（基本要件）
08. ECS        - Fargate Jenkins with EFS mount（基本要件）
```

### 🎯 **なぜ8つのスタックに分けているのか？**

#### **メリット**
- ✅ **部分デプロイ**: セキュリティグループだけ更新したい場合、`security.yaml`のみ更新
- ✅ **並行開発**: チームが同時に異なるコンポーネントを開発可能
- ✅ **高速デプロイ**: 変更した部分のみデプロイ（全体再デプロイ不要）
- ✅ **問題の局所化**: 問題発生時、影響範囲を特定のスタックに限定
- ✅ **段階的ロールバック**: 問題があるスタックのみロールバック

#### **代替案との比較**
```
【3つの大きなスタック案】foundation, application, container
- デメリット: 1つのスタックで問題が起きると、そのスタック全体に影響
- 例: ALBの設定変更でEFSまで影響を受ける可能性

【現在の8つのスタック案】各コンポーネント独立
- メリット: ALBの設定変更がEFSに影響しない
- メリット: 開発チームが独立して作業可能
```

### 🚫 **なぜネスト構成（Nested Stack）を採用しなかったのか？**

ネスト構成を検討しましたが、以下の理由で採用を見送りました：

#### **技術的制約**
- 🔴 **S3依存**: ネストスタックのテンプレートはS3にHTTPS URLで配置する必要がある
- 🔴 **二重管理**: GitとS3での二重管理が必要（同期の複雑化）
- 🔴 **ローカル開発制約**: `file://`や相対パスが使用不可

#### **運用上の課題**
- 🔴 **エラー特定の複雑化**: 
  ```
  親スタック → 子スタック → 実際のリソース
  3層構造でのエラー追跡が困難
  ```
- 🔴 **デバッグ効率の低下**: 
  - エラー発生時に複数のスタックを確認する必要
  - CloudFormationコンソールでの問題箇所特定が複雑
- 🔴 **設定の複雑化**: 
  - スタック数は減るが、パラメータ受け渡しが複雑
  - 親子関係の依存関係管理が必要

#### **開発効率への影響**
- 🔴 **直接編集不可**: S3経由のため、ローカルでの直接編集・確認ができない
- 🔴 **デプロイフロー複雑化**: 
  ```bash
  # ネスト構成の場合
  1. テンプレート編集
  2. S3へアップロード
  3. CloudFormationでデプロイ
  4. エラー時はS3とCloudFormationの両方を確認
  
  # 現在の構成
  1. テンプレート編集
  2. 直接デプロイ
  3. エラー時は該当スタックのみ確認
  ```

#### **現在の構成を選択した理由**
- ✅ **ローカル完結**: Gitリポジトリ内で全て管理可能
- ✅ **シンプルなエラー追跡**: 1スタック = 1テンプレートで問題特定が容易
- ✅ **直接編集可能**: IDEでの編集、Git差分管理が直感的
- ✅ **CI/CD親和性**: S3アップロード工程が不要で、パイプラインがシンプル

#### **比較結果**

| 項目 | ネスト構成 | 現在の8スタック構成 |
|------|-----------|-------------------|
| **スタック数** | 3個 | 8個 |
| **管理場所** | Git + S3 | Git のみ |
| **エラー追跡** | 複雑（3層構造） | 単純（1対1対応） |
| **ローカル開発** | 制約あり | 制約なし |
| **デプロイ手順** | 複雑 | シンプル |
| **学習コスト** | 高い | 低い |

### 構成要素

```
01. EIP        - NAT Gateway用のElastic IP（追加要件）
02. VPC        - 3つのAZ（A,C,D）とNetwork Firewall（基本要件）
03. Security   - Security Groups for ALB, ECS, EC2, EFS（追加要件）
04. IAM        - ECS Task用のIAMロール（追加要件）
05. EFS        - Jenkinsデータ永続化用（追加要件）
06. ALB        - Application Load Balancer（追加要件）
07. EC2        - プライベートサブネット内の管理用インスタンス（基本要件）
08. ECS        - Fargate Jenkins with EFS mount（基本要件）
```

### 3層アーキテクチャ構成（sceptre-3tier/）

3層構成では、同じ8スタックを論理的にグループ化して管理します：

```
01-foundation/      - ネットワークインフラとセキュリティ（3スタック）
├── eip.yaml        → test-jenkins-dev-01-foundation-eip
├── vpc.yaml        → test-jenkins-dev-01-foundation-vpc  
└── security.yaml   → test-jenkins-dev-01-foundation-security

02-application/     - 共有インフラストラクチャコンポーネント（4スタック）
├── iam.yaml        → test-jenkins-dev-02-application-iam
├── efs.yaml        → test-jenkins-dev-02-application-efs
├── alb.yaml        → test-jenkins-dev-02-application-alb
└── ec2.yaml        → test-jenkins-dev-02-application-ec2

03-container/       - Jenkins アプリケーション（1スタック）
└── ecs.yaml        → test-jenkins-dev-03-container-ecs
```

**注意:** ディレクトリ名（foundation/application/container）は**管理上の分類**であり、CloudFormationスタックの境界ではありません。各YAMLファイルが1つの独立したスタックになります。

```
01. EIP        - NAT Gateway用のElastic IP（追加要件）
02. VPC        - 3つのAZ（A,C,D）とNetwork Firewall（基本要件）
03. Security   - Security Groups for ALB, ECS, EC2, EFS（追加要件）
04. IAM        - ECS Task用のIAMロール（追加要件）
05. EFS        - Jenkinsデータ永続化用（追加要件）
06. ALB        - Application Load Balancer（追加要件）
07. EC2        - プライベートサブネット内の管理用インスタンス（基本要件）
08. ECS        - Fargate Jenkins with EFS mount（基本要件）
```

### 技術的な設計判断

#### 必須追加コンポーネントの理由

1. **EIP（Elastic IP）**
   - NAT Gatewayには固定IPが必要
   - インターネットアクセスの安定性確保

2. **Security Groups**
   - AWS標準のネットワークセキュリティ
   - ゼロトラストネットワーク原則に基づく通信制御

3. **IAM Roles**
   - AWS サービス間の安全な権限管理
   - ECSタスクがAWSリソースにアクセスするために必須

4. **EFS**
   - Fargateは一時的なストレージのみ
   - Jenkinsデータ（設定、ジョブ、ビルド履歴）の永続化が必要

5. **ALB**
   - インターネットからJenkinsへの安全なアクセス
   - 現在は1台のJenkinsコンテナへのプロキシとして機能
   - 将来的なHTTPS対応と複数Jenkinsインスタンス対応
   - **セキュリティ効果**: プライベートサブネット内のJenkinsを直接公開せず、ALBが外部からの脅威をフィルタリング
   - **ヘルスチェック**: Jenkinsコンテナの死活監視と異常時の自動復旧
   - **AWS Well-Architected**: セキュリティの柱とオペレーショナルエクセレンスの原則に準拠

6. **CloudWatch Logs**
   - Fargateの標準ログ出力先
   - デバッグと運用監視に必須

### ネットワーク構成

```
Internet Gateway
       ↓
[Firewallサブネット] ← AWS Network Firewall
       ↓
[Publicサブネット]  ← ALB, NAT Gateway
       ↓
[Privateサブネット] ← EC2, ECS Fargate, EFS
```

### 使用AZ
- **AZ-A**: ap-northeast-1a
- **AZ-C**: ap-northeast-1c
- **AZ-D**: ap-northeast-1d

## 前提条件

### 必要ツール

```bash
# AWS CLI v2
aws --version

# Sceptre
pip install sceptre

# 権限確認
aws sts get-caller-identity
```

### AWS権限
- VPC, EC2, ELB
- ECS, Fargate
- EFS
- IAM
- CloudWatch Logs

## スクリプト使用ガイド

プロジェクトには2つの構成に対応したスクリプトが用意されています：

### フラット構成（sceptre/）

#### Linux/macOS/Git Bash
```bash
# 全スタックのデプロイ
./deploy.sh dev deploy

# 個別スタックのデプロイ例
./deploy.sh dev deploy 02-vpc.yaml
./deploy.sh dev deploy 08-ecs.yaml
```

#### Windows (Command Prompt/PowerShell)
```cmd
REM 全スタックのデプロイ
deploy.bat dev deploy

REM 個別スタックのデプロイ例
deploy.bat dev deploy 02-vpc.yaml
deploy.bat dev deploy 08-ecs.yaml
```

### 3層構成（sceptre-3tier/）

#### 検証専用スクリプト - validate-3tier.sh

**🎯 用途**
- **デプロイ前の最終確認** - 人間が読みやすい形式での検証
- **チームレビュー** - 視覚的なレポートをチームで共有
- **トラブルシューティング** - 問題のあるテンプレートの特定

```bash
# 全層検証（デフォルト）
./validate-3tier.sh

# 個別層検証
./validate-3tier.sh foundation    # Foundation層のみ
./validate-3tier.sh application   # Application層のみ
./validate-3tier.sh container     # Container層のみ
```

**📊 出力例**
```
======================================
  3層構造Sceptre検証スクリプト
======================================

[INFO] Sceptre環境チェック中...
[INFO] Sceptre バージョン: 4.5.3

[INFO] 第1層: Foundation（基盤インフラ）検証中...
  EIP: ✅ VALID
  VPC: ✅ VALID
  Security: ✅ VALID
[SUCCESS] Foundation層: 全て正常

[INFO] 第2層: Application（共通インフラ）検証中...
  IAM: ✅ VALID
  EFS: ✅ VALID
  ALB: ✅ VALID
[SUCCESS] Application層: 全て正常

[INFO] 第3層: Container（アプリケーション）検証中...
  EC2: ✅ VALID
  ECS: ✅ VALID
[SUCCESS] Container層: 全て正常

[INFO] 生成されるスタック名一覧:
  dev/01-foundation/eip.yaml → test-jenkins-dev-01-foundation-eip
  dev/01-foundation/vpc.yaml → test-jenkins-dev-01-foundation-vpc
  ...

======================================
[SUCCESS] 全ての検証が完了しました！
デプロイメント準備完了 ✅
======================================
```

#### 統合運用スクリプト - deploy-3tier.sh

**🎯 用途**
- **本格デプロイメント** - 実際のAWSリソース作成・管理
- **CI/CD パイプライン** - 自動化スクリプトでの利用
- **包括的な運用管理** - デプロイ、削除、監視、比較

**🖥️ 基本構文**
```bash
./deploy-3tier.sh <environment> <action> [stack]
```

**📋 利用可能なアクション**

```bash
# 全テンプレート検証
./deploy-3tier.sh dev validate

# 差分確認（Dry Run）
./deploy-3tier.sh dev diff

# デプロイ
./deploy-3tier.sh dev deploy

# 層別デプロイ
./deploy-3tier.sh dev deploy 01-foundation
./deploy-3tier.sh dev deploy 02-application
./deploy-3tier.sh dev deploy 03-container

# 個別スタックデプロイ
./deploy-3tier.sh dev deploy 01-foundation/eip.yaml

# 状態確認
./deploy-3tier.sh dev status

# 出力値確認
./deploy-3tier.sh dev outputs

# 削除
./deploy-3tier.sh dev delete
```

### 🔄 **使い分けのベストプラクティス**

| フェーズ | フラット構成 | 3層構成 |
|---------|-------------|---------|
| **学習・実験** | ✅ 推奨（シンプル） | - |
| **チーム開発** | - | ✅ 推奨（構造化） |
| **本番運用** | ✅ 可能 | ✅ 推奨（管理性） |
## セットアップ

### 1. 構成の選択

使用する構成を選択してください：

#### フラット構成（sceptre/）- 初心者向け
- シンプルな番号順管理（01-eip.yaml ～ 08-ecs.yaml）
- 学習やテスト用途に最適

#### 3層構成（sceptre-3tier/）- チーム開発向け
- 論理的な層別管理（foundation/application/container）
- 本格的な開発・運用に最適

### 2. 設定の確認

選択した構成の設定ファイルでパラメータを確認：

#### フラット構成
```yaml
# 例: sceptre/config-local/dev/02-vpc.yaml
parameters:
  ProjectName: test-jenkins
  Environment: dev
  VpcCidr: 10.0.0.0/16
```

#### 3層構成
```yaml
# 例: sceptre-3tier/config/dev/01-foundation/vpc.yaml
parameters:
  ProjectName: test-jenkins
  Environment: dev
  VpcCidr: 10.0.0.0/16
```

### 3. デプロイ

### 4. Jenkins初期設定

デプロイ完了後、以下の手順でJenkinsにアクセス：

#### フラット構成
```bash
# ALBのDNS名を取得
./deploy.sh dev outputs 06-alb.yaml

# ブラウザでアクセス
# http://<ALB-DNS-NAME>/
```

#### 3層構成
```bash
# ALBのDNS名を取得
./deploy-3tier.sh dev outputs 02-application/alb.yaml

# ブラウザでアクセス
# http://<ALB-DNS-NAME>/
```

初回アクセス時は初期パスワードが必要です：

```bash
# ECSタスクのログを確認
aws logs get-log-events \
  --log-group-name "/ecs/test-jenkins-dev-jenkins" \
  --log-stream-name "jenkins/jenkins/<task-id>" \
  --query 'events[?message != null].message' \
  --output text | grep "Jenkins initial setup"
```

## 管理コマンド

### フラット構成（sceptre/）

#### 状態確認

##### Linux/macOS/Git Bash
```bash
# 全スタックの状態
./deploy.sh dev status

# 特定スタックの状態
./deploy.sh dev status 08-ecs.yaml
```

##### Windows (Command Prompt/PowerShell)
```cmd
REM 全スタックの状態
deploy.bat dev status

REM 特定スタックの状態
deploy.bat dev status 08-ecs.yaml
```

#### 出力値の確認

##### Linux/macOS/Git Bash
```bash
# 全スタックの出力
./deploy.sh dev outputs

# ALBのDNS名確認
./deploy.sh dev outputs 06-alb.yaml
```

##### Windows (Command Prompt/PowerShell)
```cmd
REM 全スタックの出力
deploy.bat dev outputs

REM ALBのDNS名確認
deploy.bat dev outputs 06-alb.yaml
```

#### 差分確認・検証

##### Linux/macOS/Git Bash
```bash
# 変更予定の差分確認
./deploy.sh dev diff
./deploy.sh dev diff 08-ecs.yaml

# テンプレートの構文検証
./deploy.sh dev validate
```

##### Windows (Command Prompt/PowerShell)
```cmd
REM 変更予定の差分確認
deploy.bat dev diff
deploy.bat dev diff 08-ecs.yaml

REM テンプレートの構文検証
deploy.bat dev validate
```

### 3層構成（sceptre-3tier/）

#### 検証
```bash
# 視覚的検証レポート（推奨）
./validate-3tier.sh

# 標準出力での検証
./deploy-3tier.sh dev validate
```

#### 状態確認・出力値
```bash
# 全スタック状態確認
./deploy-3tier.sh dev status

# 個別スタック状態
./deploy-3tier.sh dev status 01-foundation/vpc.yaml

# 全出力値確認
./deploy-3tier.sh dev outputs

# ALBのDNS名確認
./deploy-3tier.sh dev outputs 02-application/alb.yaml
```

#### 差分確認
```bash
# 全体差分確認
./deploy-3tier.sh dev diff

# 層別差分確認
./deploy-3tier.sh dev diff 01-foundation
./deploy-3tier.sh dev diff 02-application
./deploy-3tier.sh dev diff 03-container
```

## EC2インスタンスへの接続

プライベートサブネット内のEC2インスタンスには、AWS Systems Manager Session Managerで接続：

```bash
# インスタンス一覧
aws ec2 describe-instances \
  --filters "Name=tag:Environment,Values=dev" \
  --query 'Reservations[*].Instances[*].[InstanceId,Tags[?Key==`Name`].Value|[0],State.Name]' \
  --output table

# Session Manager接続
aws ssm start-session --target i-xxxxxxxxxxxxxxxxx
```

## ECS Fargateの特徴

### データ永続化
- **EFS (Elastic File System)** でJenkinsデータを永続化
- コンテナ再起動時もデータが保持される
- マルチAZ対応で高可用性

### コンテナ仕様
```yaml
Image: docker.io/jenkins/jenkins:2.462.3-almalinux
CPU: 1024 (1 vCPU)
Memory: 2048 MB (2 GB)
Ports:
  - 8080: Jenkins Web UI
  - 50000: Jenkins Agent Port
```

### ログ管理
- CloudWatch Logsに自動転送
- ログ保持期間: 14日

## ALBの必要性（単一Jenkinsでも）

### セキュリティ面での効果

1. **DMZ（非武装地帯）の実現**
   - Jenkins本体はプライベートサブネット内で完全に保護
   - ALBがパブリックサブネットで外部からの攻撃を受ける
   - Direct to Instance攻撃の防止

2. **アクセス制御の集約**
   - ALBレベルでIP制限やWAF連携が可能
   - 単一のエントリーポイントでセキュリティポリシーを管理

3. **SSL/TLS終端**
   - HTTPS通信の暗号化・復号化をALBで処理
   - Jenkins本体は平文通信で軽量化

### 運用面での効果

1. **ヘルスチェックによる自動復旧**
   ```yaml
   # ALBレベル（Target Group）
   HealthCheckPath: /login
   HealthCheckIntervalSeconds: 30
   HealthCheckTimeoutSeconds: 5
   HealthyThresholdCount: 2
   UnhealthyThresholdCount: 5
   
   # ECSコンテナレベル（Task Definition）
   HealthCheck:
     Command: "curl -f http://localhost:8080/login || exit 1"
     Interval: 30
     Timeout: 5
     Retries: 3
     StartPeriod: 60
   ```

   **自動回復の流れ:**
   1. **ECSタスクレベル**: コンテナ内でヘルスチェック失敗 → ECSが自動的にタスク再起動
   2. **ALBレベル**: Unhealthyなターゲットを検出 → 該当ターゲットへの振り分けを停止
   3. **ECSサービス**: Desired Count維持のため新しいタスクを起動
   4. **ALB**: 新しいタスクがHealthyになったら振り分け再開
   5. **データ復旧**: EFSにより設定・ジョブが自動的に引き継がれる

   **役割分担:**
   - **ECSタスク**: 自動復旧の実行主体（コンテナ再起動・新タスク起動）
   - **ALB**: 振り分け制御（死んだターゲットには送らない）

2. **Zero Downtime デプロイメント**
   - ECSサービス更新時のローリングアップデート
   - ALBが新旧コンテナ間でトラフィック制御
   ```yaml
   # ECS Service設定
   DesiredCount: 1
   DeploymentConfiguration:
     MaximumPercent: 200      # 更新時は最大2台まで起動
     MinimumHealthyPercent: 50 # 最低50%は稼働維持
   HealthCheckGracePeriodSeconds: 300  # 起動猶予時間
   ```

3. **マルチレベル監視システム**
   - **ECSタスクレベル**: コンテナ内ヘルスチェック
   - **ALBレベル**: HTTP応答性監視
   - **CloudWatch**: メトリクス・アラーム監視
   ```bash
   # 実際の監視コマンド例
   aws ecs describe-services \
     --cluster test-jenkins-dev-cluster \
     --services test-jenkins-dev-jenkins-service \
     --query 'services[0].{Status:status,Running:runningCount,Desired:desiredCount}'
   ```

### AWS Well-Architected準拠

1. **セキュリティの柱**
   - Defense in Depth（多層防御）の実装
   - インターネット↔ALB↔Jenkins の段階的セキュリティ

2. **信頼性の柱**
   - ヘルスチェックによる自動回復
   - マルチAZ配置でのALB冗長化

3. **オペレーショナルエクセレンス**
   - 統一されたログ・メトリクス収集
   - Infrastructure as Code（CloudFormation）による管理

### 代替案との比較

| 方式 | セキュリティ | 運用性 | 拡張性 | コスト |
|------|-------------|--------|--------|--------|
| **ALB使用（推奨）** | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | 中 |
| Direct Jenkins公開 | ⭐ | ⭐ | ⭐ | 低 |
| NLB使用 | ⭐⭐ | ⭐⭐ | ⭐⭐ | 中 |
| CloudFront+ALB | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | 高 |

**結論**: 単一Jenkinsでも、セキュリティ・運用・将来拡張性を考慮すると、ALBの使用がAWSベストプラクティスに準拠した最適解

## 自動回復機能の詳細

### テンプレート実行後に有効になる自動回復

✅ **即座に有効**: このテンプレートをデプロイした時点で以下が自動的に設定されます

1. **ALB Target Group ヘルスチェック**
   - 監視対象: `http://jenkins:8080/login`
   - チェック間隔: 30秒
   - **役割**: 異常判定時にトラフィック振り分けを停止（復旧はしない）

2. **ECS Task ヘルスチェック**
   - 監視対象: コンテナ内部の Jenkins プロセス
   - チェック間隔: 30秒
   - **役割**: 異常判定時にコンテナ/タスクを自動再起動（実際の復旧を実行）

3. **ECS Service 自動復旧**
   - Desired Count: 1台を常時維持
   - **役割**: タスク異常時に新しいタスクを起動して台数を維持

### 実際の障害シナリオと回復動作

| 障害パターン | 検出主体 | 回復動作 | 回復時間 |
|-------------|---------|---------|---------|
| **Jenkinsプロセス停止** | ECSタスク | コンテナ再起動 | 2-3分 |
| **コンテナクラッシュ** | ECSタスク | 新タスク起動 | 3-5分 |
| **ネットワーク異常** | ALB | 振り分け停止※ | 即座 |
| **AZ障害** | ECSサービス | 他AZで起動 | 3-5分 |

※ALBは振り分けを停止するのみ。実際の復旧はECSが実行

### 重要な補足: 単一Jenkinsでの ALB の意味

現在のアーキテクチャ（Jenkins 1台）では：

- **ALBの主な役割**: トラフィック制御ではなく**セキュリティゲートウェイ**
- **復旧の実行**: ECSタスク・サービスが担当
- **ALBの効果**: 
  - 異常なJenkinsへのアクセスをブロック（502 Bad Gateway応答）
  - ECSが復旧中でも適切なエラーレスポンスを返す
  - 復旧完了後に自動的にトラフィック再開

### 回復状況の確認方法

```bash
# ECSサービスの状態確認
aws ecs describe-services \
  --cluster test-jenkins-dev-cluster \
  --services test-jenkins-dev-jenkins-service \
  --query 'services[0].events[0:5]'

# Target Groupの健全性確認
aws elbv2 describe-target-health \
  --target-group-arn arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/test-jenkins-dev-jenkins-tg/1234567890123456

# CloudWatch メトリクス確認
aws cloudwatch get-metric-statistics \
  --namespace AWS/ApplicationELB \
  --metric-name HealthyHostCount \
  --dimensions Name=TargetGroup,Value=targetgroup/test-jenkins-dev-jenkins-tg/1234567890123456 \
  --statistics Average \
  --start-time 2025-01-01T00:00:00Z \
  --end-time 2025-01-01T01:00:00Z \
  --period 300
```

## Network Firewall設定

### 許可ドメイン

アウトバウンド通信で以下のドメインが許可されています：

```yaml
- ".amazonaws.com"    # AWS API
- ".docker.com"       # Docker Hub
- ".docker.io"        # Docker Registry
- ".github.com"       # GitHub
- ".almalinux.org"    # AlmaLinux packages
- ".jenkins.io"       # Jenkins plugins
```

## セキュリティ設定

### Security Groups

| リソース | ポート | 送信元 | 説明 |
|---------|--------|--------|------|
| **ALB** | 80, 443 | 0.0.0.0/0 | インターネットからのHTTP/HTTPS |
| **ECS** | 8080, 50000 | ALB SG | ALBからのJenkins通信 |
| **EC2** | 22 | VPC CIDR | VPC内からのSSH |
| **EFS** | 2049 | ECS SG | ECSからのNFS |

### IAM Roles

- **ECS Task Execution Role**: コンテナ起動・ログ出力用
- **ECS Task Role**: EFS access, CloudWatch Logs用
- **EC2 Role**: SSM Session Manager用

## 削除方法

### フラット構成（sceptre/）

#### Linux/macOS/Git Bash
```bash
# 全スタック削除（逆順で実行）
./deploy.sh dev delete

# 個別スタック削除
./deploy.sh dev delete 08-ecs.yaml
```

#### Windows (Command Prompt/PowerShell)
```cmd
REM 全スタック削除（逆順で実行）
deploy.bat dev delete

REM 個別スタック削除
deploy.bat dev delete 08-ecs.yaml
```

### 3層構成（sceptre-3tier/）

```bash
# 全スタック削除（逆順自動実行）
./deploy-3tier.sh dev delete

# 層別削除（手動制御）
./deploy-3tier.sh dev delete 03-container
./deploy-3tier.sh dev delete 02-application
./deploy-3tier.sh dev delete 01-foundation

# 個別スタック削除
./deploy-3tier.sh dev delete 03-container/ecs.yaml
```

## トラブルシューティング

### 一般的な問題

1. **依存関係エラー**
   ```bash
   ./deploy.sh dev status
   ```

2. **ECSタスクが起動しない**
   ```bash
   # ECSサービスのイベント確認
   aws ecs describe-services \
     --cluster test-jenkins-dev-cluster \
     --services test-jenkins-dev-jenkins-service
   ```

3. **EFS接続エラー**
   ```bash
   # EFSマウントターゲット確認
   aws efs describe-mount-targets --file-system-id fs-xxxxxxxxx
   ```

## カスタマイズ

### Jenkinsイメージの変更

`templates/ecs.yaml`の以下の行を修正：

```yaml
Image: docker.io/jenkins/jenkins:2.462.3-almalinux
```

### リソースサイズの調整

#### フラット構成
`config-local/dev/08-ecs.yaml`でCPU/メモリを調整：

```yaml
# Task Definition内
Cpu: "2048"     # 2 vCPU
Memory: "4096"  # 4 GB
```

#### 3層構成
`config/dev/03-container/ecs.yaml`でCPU/メモリを調整：

```yaml
# Task Definition内
Cpu: "2048"     # 2 vCPU
Memory: "4096"  # 4 GB
```

### 環境の追加

#### フラット構成
```bash
# 新環境用ディレクトリ作成
mkdir -p sceptre/config-local/staging
cp -r sceptre/config-local/dev/* sceptre/config-local/staging/

# パラメータ調整
vim sceptre/config-local/staging/*.yaml
```

#### 3層構成
```bash
# 新環境用ディレクトリ作成
mkdir -p sceptre-3tier/config/staging
cp -r sceptre-3tier/config/dev/* sceptre-3tier/config/staging/

# パラメータ調整
vim sceptre-3tier/config/staging/*/*.yaml
```

### 新規コンポーネント追加

#### フラット構成
1. 新しいテンプレート作成: `templates/new-component.yaml`
2. 設定ファイル作成: `config-local/dev/09-new-component.yaml`
3. 依存関係設定（必要に応じて）

#### 3層構成
1. 新しいテンプレート作成: `templates/new-component.yaml`
2. 設定ファイル作成: `config/dev/[適切な層]/new-component.yaml`
3. 依存関係設定（必要に応じて）

## まとめ

### 🏗️ **アーキテクチャの特徴**
- ✅ **メンテナンス性**: 各テンプレートを独立して管理
- ✅ **柔軟性**: 個別デプロイまたは層単位デプロイが可能
- ✅ **段階的運用**: 開発→本番への移行が容易
- ✅ **選択肢**: フラット構成と3層構成から選択可能

### 🛠️ **スクリプトツールの特徴**
- ✅ **多様な運用**: デプロイ、削除、監視、差分確認を統一スクリプトで実現
- ✅ **クロスプラットフォーム**: Bashスクリプトでどの環境でも統一実行
- ✅ **CI/CD統合**: 自動化パイプラインでの利用を想定した設計
- ✅ **視覚的検証**: 3層構成では人間向けの検証レポート機能

### 🔄 **構成選択の指針**

| 用途 | フラット構成 | 3層構成 |
|------|-------------|---------|
| **学習・実験** | ✅ 推奨 | - |
| **小規模開発** | ✅ 推奨 | ✅ 可能 |
| **チーム開発** | ✅ 可能 | ✅ 推奨 |
| **本番運用** | ✅ 可能 | ✅ 推奨 |
| **複雑な依存関係** | ⚠️ 管理困難 | ✅ 推奨 |

### 🎯 **従来手法との比較**

| 構成 | メンテナンス性 | デプロイ柔軟性 | 運用の簡素性 | 学習コスト |
|------|---------------|---------------|-------------|-----------|
| **フラット構成** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ |
| **3層構成** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **統合テンプレート** | ⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **ネスト構成** | ⭐ | ⭐⭐ | ⭐ | ⭐ |

フラット構成の細かい制御と、統合テンプレートの簡単な管理の両方の利点を兼ね備えた、**バランスの取れたアプローチ**を実現しています。

## 参考資料

- [AWS ECS with Fargate](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/AWS_Fargate.html)
- [AWS EFS](https://docs.aws.amazon.com/efs/latest/ug/whatisefs.html)
- [Jenkins on Docker](https://www.jenkins.io/doc/book/installing/docker/)
- [Sceptre Documentation](https://sceptre.cloudreach.com/)
- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)
- [AWS CloudFormation Best Practices](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html)

## ライセンス

このテンプレートはサンプル用途で提供されています。本番環境での使用前に十分な検証を行ってください。
