#!/bin/bash

# Test Jenkins Infrastructure Deployment Script for Sceptre (3-Tier Architecture)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCEPTRE_DIR="${SCRIPT_DIR}/sceptre-3tier"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
usage() {
    echo "Usage: $0 <environment> <action> [stack]"
    echo ""
    echo "Environments:"
    echo "  dev          Development environment"
    echo ""
    echo "Actions:"
    echo "  deploy       Deploy stacks (3-tier architecture)"
    echo "  delete       Delete stacks (reverse order)"
    echo "  status       Show stack status"
    echo "  outputs      Show stack outputs"
    echo "  diff         Show stack differences"
    echo "  validate     Validate templates"
    echo ""
    echo "Stacks (3-Tier Architecture):"
    echo "  01-foundation/    - Network infrastructure and security"
    echo "    ├── eip.yaml         - Elastic IP addresses for NAT Gateways"
    echo "    ├── vpc.yaml         - VPC with 3 AZs and Network Firewall"
    echo "    └── security.yaml    - Security Groups"
    echo "  02-application/   - Shared infrastructure components"
    echo "    ├── iam.yaml         - IAM Roles for ECS and EC2"
    echo "    ├── efs.yaml         - Elastic File System for data persistence"
    echo "    ├── alb.yaml         - Application Load Balancer"
    echo "    └── ec2.yaml         - Management EC2 instance"
    echo "  03-container/     - Jenkins application"
    echo "    └── ecs.yaml         - ECS Fargate Jenkins service"
    echo ""
    echo "Examples:"
    echo "  $0 dev deploy                            # Deploy all stacks (3-tier)"
    echo "  $0 dev deploy 01-foundation              # Deploy foundation layer"
    echo "  $0 dev deploy 02-application/iam.yaml   # Deploy specific component"
    echo "  $0 dev status                            # Show all stack status"
    echo "  $0 dev outputs 02-application/alb.yaml  # Show ALB outputs"
    echo "  $0 dev delete                            # Delete all stacks (reverse order)"
    echo ""
}

# Check if sceptre is installed
check_sceptre() {
    if ! command -v sceptre &> /dev/null; then
        print_error "Sceptre is not installed. Please install it with: pip install sceptre"
        exit 1
    fi
}

# Check AWS credentials
check_aws_credentials() {
    if ! aws sts get-caller-identity &> /dev/null; then
        print_error "AWS credentials not configured. Please run 'aws configure' or set environment variables."
        exit 1
    fi
}

# Display 3-tier architecture information
show_architecture() {
    print_status "3-Tier Architecture Overview:"
    echo ""
    echo "  01. Foundation Layer    - Network infrastructure and security"
    echo "      ├── EIP             - NAT Gateway fixed IPs"
    echo "      ├── VPC             - Virtual Private Cloud with 3 AZs"
    echo "      └── Security Groups - ALB, ECS, EC2, EFS security rules"
    echo ""
    echo "  02. Application Layer   - Shared infrastructure components"
    echo "      ├── IAM Roles       - ECS Task, EC2 service permissions"
    echo "      ├── EFS             - Jenkins data persistence"
    echo "      ├── ALB             - Application Load Balancer"
    echo "      └── EC2             - Management instance"
    echo ""
    echo "  03. Container Layer     - Jenkins application"
    echo "      └── ECS Fargate     - Jenkins container service"
    echo ""
}

# Main script
main() {
    if [ $# -lt 2 ]; then
        usage
        exit 1
    fi

    local environment=$1
    local action=$2
    local stack=$3

    # Validate environment
    if [[ ! "$environment" =~ ^(dev)$ ]]; then
        print_error "Invalid environment: $environment"
        usage
        exit 1
    fi

    # Show architecture info for certain actions
    if [[ "$action" == "deploy" || "$action" == "status" ]] && [ -z "$stack" ]; then
        show_architecture
    fi

    # Check prerequisites
    check_sceptre
    check_aws_credentials

    # Change to sceptre directory
    cd "$SCEPTRE_DIR"

    case $action in
        deploy)
            if [ -n "$stack" ]; then
                print_status "Deploying stack: $stack in $environment environment"
                sceptre launch config-local/$environment/$stack
            else
                print_status "Deploying all stacks in $environment environment (3-tier)"
                print_status "Order: Foundation → Application → Container"
                sceptre launch config-local/$environment
            fi
            print_success "Deployment completed"
            ;;
        delete)
            if [ -n "$stack" ]; then
                print_warning "Deleting stack: $stack in $environment environment"
                read -p "Are you sure you want to delete this stack? (y/N): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    sceptre delete config-local/$environment/$stack
                    print_success "Stack deleted"
                else
                    print_status "Deletion cancelled"
                fi
            else
                print_warning "Deleting ALL stacks in $environment environment"
                print_warning "Order: Container → Application → Foundation"
                read -p "Are you sure you want to delete ALL stacks? (y/N): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    sceptre delete config-local/$environment
                    print_success "All stacks deleted"
                else
                    print_status "Deletion cancelled"
                fi
            fi
            ;;
        status)
            if [ -n "$stack" ]; then
                print_status "Status for stack: $stack"
                sceptre list config-local/$environment/$stack
            else
                print_status "Status for all stacks in $environment environment (3-tier)"
                sceptre list config-local/$environment
            fi
            ;;
        outputs)
            if [ -n "$stack" ]; then
                print_status "Outputs for stack: $stack"
                sceptre list outputs config-local/$environment/$stack
            else
                print_status "Outputs for all stacks in $environment environment (3-tier)"
                sceptre list outputs config-local/$environment
            fi
            ;;
        diff)
            if [ -n "$stack" ]; then
                print_status "Showing differences for stack: $stack"
                sceptre diff config-local/$environment/$stack
            else
                print_status "Showing differences for all stacks in $environment environment (3-tier)"
                sceptre diff config-local/$environment
            fi
            ;;
        validate)
            if [ -n "$stack" ]; then
                print_status "Validating template for stack: $stack"
                sceptre validate config-local/$environment/$stack
            else
                print_status "Validating all templates in $environment environment (3-tier)"
                sceptre validate config-local/$environment
            fi
            print_success "Validation completed"
            ;;
        *)
            print_error "Invalid action: $action"
            usage
            exit 1
            ;;
    esac
}

main "$@"
