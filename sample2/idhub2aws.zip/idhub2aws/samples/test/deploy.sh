#!/bin/bash

# Test Jenkins Infrastructure Deployment Script for Sceptre

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCEPTRE_DIR="${SCRIPT_DIR}/sceptre"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
usage() {
    echo "Usage: $0 <environment> <action> [stack]"
    echo ""
    echo "Environments:"
    echo "  dev          Development environment"
    echo ""
    echo "Actions:"
    echo "  deploy       Deploy stacks"
    echo "  delete       Delete stacks"
    echo "  status       Show stack status"
    echo "  outputs      Show stack outputs"
    echo "  diff         Show stack differences"
    echo "  validate     Validate templates"
    echo ""
    echo "Examples:"
    echo "  $0 dev deploy                    # Deploy all stacks"
    echo "  $0 dev deploy 02-vpc.yaml        # Deploy specific stack"
    echo "  $0 dev status                    # Show all stack status"
    echo "  $0 dev outputs 06-alb.yaml       # Show ALB outputs"
    echo "  $0 dev delete                    # Delete all stacks"
    echo ""
}

# Check if sceptre is installed
check_sceptre() {
    if ! command -v sceptre &> /dev/null; then
        print_error "Sceptre is not installed. Please install it with: pip install sceptre"
        exit 1
    fi
}

# Check AWS credentials
check_aws_credentials() {
    if ! aws sts get-caller-identity &> /dev/null; then
        print_error "AWS credentials not configured. Please run 'aws configure' or set environment variables."
        exit 1
    fi
}

# Main script
main() {
    if [ $# -lt 2 ]; then
        usage
        exit 1
    fi

    local environment=$1
    local action=$2
    local stack=$3

    # Validate environment
    if [[ ! "$environment" =~ ^(dev)$ ]]; then
        print_error "Invalid environment: $environment"
        usage
        exit 1
    fi

    # Check prerequisites
    check_sceptre
    check_aws_credentials

    # Change to sceptre directory
    cd "$SCEPTRE_DIR"

    case $action in
        deploy)
            if [ -n "$stack" ]; then
                print_status "Deploying stack: $stack in $environment environment"
                sceptre launch config-local/$environment/$stack
            else
                print_status "Deploying all stacks in $environment environment"
                sceptre launch config-local/$environment
            fi
            print_success "Deployment completed"
            ;;
        delete)
            if [ -n "$stack" ]; then
                print_warning "Deleting stack: $stack in $environment environment"
                read -p "Are you sure you want to delete this stack? (y/N): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    sceptre delete config-local/$environment/$stack
                    print_success "Stack deleted"
                else
                    print_status "Deletion cancelled"
                fi
            else
                print_warning "Deleting ALL stacks in $environment environment"
                read -p "Are you sure you want to delete ALL stacks? (y/N): " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    sceptre delete config-local/$environment
                    print_success "All stacks deleted"
                else
                    print_status "Deletion cancelled"
                fi
            fi
            ;;
        status)
            if [ -n "$stack" ]; then
                print_status "Status for stack: $stack"
                sceptre list config-local/$environment/$stack
            else
                print_status "Status for all stacks in $environment environment"
                sceptre list config-local/$environment
            fi
            ;;
        outputs)
            if [ -n "$stack" ]; then
                print_status "Outputs for stack: $stack"
                sceptre list outputs config-local/$environment/$stack
            else
                print_status "Outputs for all stacks in $environment environment"
                sceptre list outputs config-local/$environment
            fi
            ;;
        diff)
            if [ -n "$stack" ]; then
                print_status "Showing differences for stack: $stack"
                sceptre diff config-local/$environment/$stack
            else
                print_status "Showing differences for all stacks in $environment environment"
                sceptre diff config-local/$environment
            fi
            ;;
        validate)
            if [ -n "$stack" ]; then
                print_status "Validating template for stack: $stack"
                sceptre validate config-local/$environment/$stack
            else
                print_status "Validating all templates in $environment environment"
                sceptre validate config-local/$environment
            fi
            print_success "Validation completed"
            ;;
        *)
            print_error "Invalid action: $action"
            usage
            exit 1
            ;;
    esac
}

main "$@"
