# 明日以降の確認事項・問題点

## 📅 作業日時
- **作成日**: 2025年7月30日
- **作業継続日**: 2025年7月31日以降

## 🎯 今日の到達点

### ✅ 完成したもの
1. **sceptre-3tier**: 8スタック構成（sceptre実行時にS3不要、動作確認済み）
   - 設定ファイル: 8個
   - deploy-3tier.sh, validate-3tier.sh 動作OK
   - バリデーション通過済み

2. **sceptre-nested-3tier**: Nested Stack構成（未完成）
   - 設定ファイル: 3個（目標達成）
   - 基本構造は作成済み
   - **問題**: S3依存とローカル参照の技術的制約

## ❌ 未解決の問題

### 1. **Nested Stackのローカルファイル参照問題**

**問題の核心**:
```yaml
# CloudFormation Nested Stackの制約
Resources:
  EIPStack:
    Type: AWS::CloudFormation::Stack
    Properties:
      TemplateURL: ../templates/eip.yaml  # ← これが動作しない
      # 実際にはHTTPS URLが必要: https://s3.amazonaws.com/bucket/eip.yaml
```

**技術的制約**:
- AWS CloudFormationの仕様: Nested StackのTemplateURLは**HTTP/HTTPS URL必須**
- ローカルファイルパス不可
- Sceptreも基本的にはCloudFormationの制約に従う

### 2. **Sceptre 4.5.3の新しい設定形式**

**発見した問題**:
```yaml
# 古い形式（非推奨警告が出る）
template_path: ../templates-nested/foundation-nested.yaml

# 新しい形式（修正済み）
template: ../templates-nested/foundation-nested.yaml
```

## 🔍 明日以降の確認事項

### **優先度 HIGH**

#### 1. **Nested Stackの実現可能性調査**
```bash
# 確認すべきコマンド
cd sceptre-nested-3tier

# S3バケット作成してテスト
aws s3 mb s3://test-jenkins-dev-sceptre-templates

# S3設定を戻してテスト
# config/config.yaml に以下を追加:
# template_handler_data:
#   auto_upload: true
#   bucket_name: test-jenkins-dev-sceptre-templates
#   bucket_region: ap-northeast-1

# バリデーション実行
./validate-nested-3tier.sh

# デプロイテスト
./deploy-nested-3tier.sh validate
```

#### 2. **Sceptreの高度な機能調査**
- **調査項目**: Sceptreでローカル参照Nested Stackが可能か
- **確認方法**: 
  - Sceptre公式ドキュメント
  - GitHub Issues/Discussions
  - バージョン4.5.3の新機能

#### 3. **代替アプローチの検討**

**Option A: S3を使うNested Stack**
```
メリット: 設定ファイル3個、構造がシンプル
デメリット: S3バケット依存、管理コスト増
```

**Option B: 従来の8スタック構成**
```
メリット: S3不要、確実に動作、高速デプロイ
デメリット: 設定ファイル8個
```

**Option C: Sceptre以外のツール**
```
候補: AWS CDK, Terraform, Pulumi
検討: IaCツールの移行コスト vs 設定ファイル削減メリット
```

### **優先度 MEDIUM**

#### 4. **既存構成の改良**
```bash
# sceptre-3tierの改良アイデア
- デプロイスクリプトの機能追加
- エラーハンドリング強化
- ドキュメント整備
```

#### 5. **本番運用向けの拡張**
```yaml
# 環境追加
config/
├── dev/     # 開発環境（作成済み）
├── stg/     # ステージング環境
└── prod/    # 本番環境
```

#### 6. **CI/CD統合**
```yaml
# GitHub Actions等との連携
- 自動バリデーション
- 環境別デプロイ
- ドリフト検出
```

## 🔄 明日の作業フロー

### **Step 1: 現状確認（15分）**
```bash
cd samples/test/sceptre-3tier
./validate-3tier.sh
./deploy-3tier.sh status
```

### **Step 2: Nested Stack再挑戦（30分）**
```bash
cd ../sceptre-nested-3tier

# S3バケット作成
aws s3 mb s3://test-jenkins-dev-sceptre-templates

# S3設定復活
# config/config.yaml編集

# バリデーション
./validate-nested-3tier.sh
```

### **Step 3: 判断（15分）**
- Nested Stackが動作 → 継続開発
- Nested Stackが不可 → 代替案検討
- 時間制約がある → 従来構成で進行

## 📋 ファイル構成状況

### **完成済み: sceptre-3tier/**
```
sceptre-3tier/
├── ✅ deploy-3tier.sh          # 動作確認済み
├── ✅ validate-3tier.sh        # 動作確認済み
├── ✅ README-3tier.md          # ドキュメント完成
├── ✅ config/dev/*.yaml        # 8個の設定ファイル
└── ✅ templates/*.yaml         # 8個のテンプレート
```

### **未完成: sceptre-nested-3tier/**
```
sceptre-nested-3tier/
├── ❓ deploy-nested-3tier.sh    # 未テスト
├── ❓ validate-nested-3tier.sh  # エラー中
├── ✅ README.md                # ドキュメント作成済み
├── ❓ config/dev/*.yaml        # 3個の設定ファイル（S3問題）
├── ✅ templates/*.yaml         # 8個のテンプレート
└── ❓ templates-nested/*.yaml  # 3個のNested（S3問題）
```

## 🎯 最終目標の確認

**お客様の要望**: 
- ✅ configファイル数を減らしたい（8個→3個）
- ✅ 既存テンプレートを活用したい
- ❓ S3依存について判断が必要

**技術的制約**:
- CloudFormation Nested Stack = S3必須
- Sceptreはローカル参照Nested Stackをサポートしていない可能性
- 代替案の検討が必要

## 📞 決定が必要な事項

1. **S3バケット作成の可否**
   - 開発環境での作成許可
   - 運用時の管理責任
   - コスト負担

2. **優先順位**
   - 設定ファイル数削減 vs S3依存回避
   - 開発スピード vs 理想的なアーキテクチャ

3. **代替案の受容**
   - 従来の8スタック構成での妥協
   - 他のIaCツールへの移行検討

---

**明日の開始コマンド**:
```bash
cd "c:\Users\toshimitsu.tomonaga\OneDrive - NTT DOCOMO-OCX\dfs ドキュメント\Projects\idhubのAWS移行\idhub2aws\samples\test"
cat tomorrow.md
```
