#!/bin/bash

# 3層構造Sceptre検証スクリプト
# Usage: ./validate-3tier.sh [layer]
#   layer: foundation, application, container, all (default: all)

set -e

# 色付きログ出力
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ログ関数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 変数設定
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$SCRIPT_DIR"
LAYER=${1:-all}
VALIDATION_FAILED=0

# Sceptre環境チェック
check_sceptre() {
    log_info "Sceptre環境チェック中..."
    if ! command -v sceptre &> /dev/null; then
        log_error "Sceptreがインストールされていません"
        exit 1
    fi
    
    SCEPTRE_VERSION=$(sceptre --version 2>/dev/null | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' || echo "unknown")
    log_info "Sceptre バージョン: $SCEPTRE_VERSION"
}

# テンプレート存在チェック
check_templates() {
    log_info "テンプレートファイルチェック中..."
    local missing_templates=()
    
    local templates=(
        "templates/eip.yaml"
        "templates/vpc.yaml" 
        "templates/security.yaml"
        "templates/iam.yaml"
        "templates/efs.yaml"
        "templates/alb.yaml"
        "templates/ec2.yaml"
        "templates/ecs.yaml"
    )
    
    for template in "${templates[@]}"; do
        if [[ ! -f "$PROJECT_ROOT/$template" ]]; then
            missing_templates+=("$template")
        fi
    done
    
    if [[ ${#missing_templates[@]} -gt 0 ]]; then
        log_error "以下のテンプレートが見つかりません:"
        for template in "${missing_templates[@]}"; do
            echo "  - $template"
        done
        exit 1
    fi
    
    log_success "全テンプレートファイルが存在します"
}

# 単一スタック検証
validate_stack() {
    local stack_path="$1"
    local stack_name="$2"
    
    echo -n "  $stack_name: "
    
    if output=$(sceptre validate "$stack_path" 2>&1); then
        if echo "$output" | grep -q "is valid"; then
            echo -e "${GREEN}✅ VALID${NC}"
            return 0
        else
            echo -e "${RED}❌ ERROR${NC}"
            echo "$output" | head -3
            return 1
        fi
    else
        echo -e "${RED}❌ ERROR${NC}"
        echo "$output" | head -3
        return 1
    fi
}

# Foundation層検証
validate_foundation() {
    log_info "第1層: Foundation（基盤インフラ）検証中..."
    
    local stacks=(
        "dev/01-foundation/eip.yaml:EIP"
        "dev/01-foundation/vpc.yaml:VPC"
        "dev/01-foundation/security.yaml:Security"
    )
    
    local layer_failed=0
    for stack_info in "${stacks[@]}"; do
        IFS=':' read -r stack_path stack_name <<< "$stack_info"
        if ! validate_stack "$stack_path" "$stack_name"; then
            layer_failed=1
        fi
    done
    
    if [[ $layer_failed -eq 0 ]]; then
        log_success "Foundation層: 全て正常"
    else
        log_error "Foundation層: エラーあり"
        VALIDATION_FAILED=1
    fi
    
    return $layer_failed
}

# Application層検証
validate_application() {
    log_info "第2層: Application（共通インフラ）検証中..."
    
    local stacks=(
        "dev/02-application/iam.yaml:IAM"
        "dev/02-application/efs.yaml:EFS"
        "dev/02-application/alb.yaml:ALB"
    )
    
    local layer_failed=0
    for stack_info in "${stacks[@]}"; do
        IFS=':' read -r stack_path stack_name <<< "$stack_info"
        if ! validate_stack "$stack_path" "$stack_name"; then
            layer_failed=1
        fi
    done
    
    if [[ $layer_failed -eq 0 ]]; then
        log_success "Application層: 全て正常"
    else
        log_error "Application層: エラーあり"
        VALIDATION_FAILED=1
    fi
    
    return $layer_failed
}

# Container層検証
validate_container() {
    log_info "第3層: Container（アプリケーション）検証中..."
    
    local stacks=(
        "dev/03-container/ec2.yaml:EC2"
        "dev/03-container/ecs.yaml:ECS"
    )
    
    local layer_failed=0
    for stack_info in "${stacks[@]}"; do
        IFS=':' read -r stack_path stack_name <<< "$stack_info"
        if ! validate_stack "$stack_path" "$stack_name"; then
            layer_failed=1
        fi
    done
    
    if [[ $layer_failed -eq 0 ]]; then
        log_success "Container層: 全て正常"
    else
        log_error "Container層: エラーあり"
        VALIDATION_FAILED=1
    fi
    
    return $layer_failed
}

# 依存関係チェック
check_dependencies() {
    log_info "依存関係チェック中..."
    
    # Foundation層 → Application層
    local app_depends_on_foundation=true
    
    # Application層 → Container層  
    local container_depends_on_app=true
    
    if $app_depends_on_foundation && $container_depends_on_app; then
        log_success "依存関係: 正常"
    else
        log_warning "依存関係: 一部に問題の可能性"
    fi
}

# スタック名一覧表示
show_stack_names() {
    log_info "生成されるスタック名一覧:"
    if sceptre list stacks dev > /dev/null 2>&1; then
        sceptre list stacks dev 2>/dev/null | grep -E "^dev/" | while read -r line; do
            stack_path=$(echo "$line" | cut -d':' -f1)
            stack_name=$(echo "$line" | cut -d':' -f2 | sed 's/^ *//')
            printf "  %-35s → %s\n" "$stack_path" "$stack_name"
        done
    else
        log_warning "スタック名一覧を取得できませんでした"
    fi
}

# メイン処理
main() {
    echo "======================================"
    echo "  3層構造Sceptre検証スクリプト"
    echo "======================================"
    echo
    
    # 環境チェック
    check_sceptre
    check_templates
    echo
    
    # 層別検証
    case "$LAYER" in
        "foundation")
            validate_foundation
            ;;
        "application") 
            validate_application
            ;;
        "container")
            validate_container
            ;;
        "all")
            validate_foundation
            echo
            validate_application  
            echo
            validate_container
            echo
            check_dependencies
            echo
            show_stack_names
            ;;
        *)
            log_error "無効な層指定: $LAYER"
            echo "使用法: $0 [foundation|application|container|all]"
            exit 1
            ;;
    esac
    
    echo
    echo "======================================"
    if [[ $VALIDATION_FAILED -eq 0 ]]; then
        log_success "全ての検証が完了しました！"
        echo "デプロイメント準備完了 ✅"
    else
        log_error "検証中にエラーが発生しました"
        echo "エラーを修正してから再実行してください ❌"
        exit 1
    fi
    echo "======================================"
}

# スクリプト実行
main "$@"
