# AWS CloudFormationテンプレート集

本ディレクトリには、ドコモ社内で利用されている3つの主要なAWS CloudFormationテンプレートプロジェクトが含まれています。これらのテンプレートは、それぞれ異なる目的と用途で開発されており、ドコモグループ内のRクラウドからAWSへの移転支援やサービス固有のインフラ構築に活用されています。

## 1. aws-templates-bprtech

### 概要
オンラインCX部が開発・提供するAWS標準構成テンプレート。ドコモ社内の標準的なAWSベストプラクティスを実装した汎用的なテンプレート集です。

### 主な特徴
- **アーキテクチャ**: Web三層構造（CloudFront/ALB/ECS Fargate/Aurora）
- **セキュリティ**: ドコモシステムセキュリティ対策マニュアル準拠
- **対象環境**: ドコモCCoE Standard組織
- **IaC**: CloudFormation + Sceptre
- **アプリケーション**: PHP 8.4 + Laravel対応のDockerfile同梱
- **CI/CD**: AWS CodePipeline統合
- **移行支援**: Rクラウド-AWS VPN接続、AWS DMS対応

### 対象ユーザー
- AWSに精通していない開発者
- Rクラウドから AWS移転を検討している組織
- ドコモ社内の各組織（汎用利用可能）

### 利用申請
不要（技術理解の上で自由に改変・利用可能）

---

## 2. house-30-cfn

### 概要
goo住宅・不動産サービス専用のCloudFormationテンプレート集。不動産情報サービスに特化したインフラ構成を提供します。

### 主な特徴
- **サービス特化**: goo住宅・不動産の業務要件に最適化
- **環境分離**: dev/stg/prod環境の完全分離
- **豊富なコンポーネント**: 
  - Web/Batch/検索/DB/ログサーバー構成
  - 不動産データ処理用バッチシステム
  - 個人向けAPI、画像リサイズサービス
  - Aurora/ElastiCache/ECS Fargate対応
- **外部連携**: athome、recruit等の不動産パートナー連携設定
- **ネットワーク**: 内部ALB/NLB、VPCエンドポイント対応

### 主要コンポーネント
```
├── EC2ベースサービス
│   ├── Web/Batch/検索/DB/ログサーバー
│   ├── 賃貸バッチ/売買バッチ/事業バッチ
│   └── バックアップDB/ジョブ制御
├── ECSベースサービス  
│   ├── Webアプリケーション
│   ├── 個人向けAPI
│   └── 画像リサイズサービス
└── データベース
    ├── Aurora（オンデマンドDB/個人DB）
    └── ElastiCache
```

### 対象ユーザー
goo住宅・不動産サービス開発・運用チーム

---

## 3. ocn-catalog-aws-templates

### 概要
OCNカタログサイト用のAWSテンプレート。aws-templates-bprtechをベースとしつつ、OCNサービス固有の要件に対応したフォーク版です。

### 主な特徴
- **ベース**: aws-templates-bprtechのフォーク
- **OCN特化**: OCNカタログサイトの要件に最適化
- **複数WAF対応**: 
  - CloudFront用WAF（tool/pre/git/front環境別）
  - ELB用WAF
- **ログ分析強化**: 
  - Athena統合（WAF/VPCフローログ/S3アクセスログ/ALB/NWFW）
  - ログ解析テーブル自動構築
- **GitHub連携**: SSH鍵ベースのデプロイ対応
- **実行環境**: AWS CloudShell最適化

### 実行方法
```bash
# CloudShellでの実行例
git clone git@github.com:nttresonant/ocn-catalog-aws-templates.git
cd ocn-catalog-aws-templates/sceptre/
./sceptre.sh status dev/vpc
```

### 対象ユーザー
OCNカタログサイト開発・運用チーム

---

## 共通仕様

### 技術スタック
- **IaC**: CloudFormation + Sceptre
- **実行環境**: AWS CloudShell（Python環境）
- **アカウント**: ドコモCCoE Standard組織
- **リージョン**: ap-northeast-1（東京）

### セキュリティ要件
- ドコモシステムセキュリティ対策マニュアル準拠
- 社内専用（外部公開禁止）
- 秘密度S・A非対応
- サードパーティー統合（CrowdStrike/Datadog）

### 利用上の注意
1. **責任**: セキュリティ確保の責任は利用組織にあり
2. **カスタマイズ**: 組織要件に応じた修正が必要
3. **解釈**: OCX部解釈に基づく実装のため要検証
4. **MAP2.0**: AWS MAP2.0契約タグの適切な設定が必要

---

## CloudFormationテンプレートとSceptreの連携詳細解説

AWS環境をCloudFormationで構築するためのテンプレートとパラメータファイルの連携について、3つのサンプルを用いて詳しく解説します。

### Sceptreとは

[Sceptre](https://sceptre.cloudreach.com/)は、CloudFormationテンプレートをより効率的に管理するためのOSSツールです。主な機能：

- **テンプレートとパラメータの分離**: 同一テンプレートを異なる環境で再利用可能
- **スタック間依存関係の管理**: 他のスタックの出力値を自動参照
- **環境別設定管理**: dev/stg/prod環境の設定を個別管理
- **デプロイメント順序制御**: 依存関係に基づく自動デプロイ順序決定

---

## サンプル1: VPCネットワーク構成（aws-templates-bprtech）

### 1. CloudFormationテンプレート
**ファイル**: `sceptre/templates/vpc.yaml`

```yaml
AWSTemplateFormatVersion: "2010-09-09"
Description: Create secure network set. (VPC, Subnet, RouteTable, VPCEndpoints, NatGW, NetworkFirewall)

Parameters:
  # NAT Gateway用固定EIPのAllocation ID
  FixedNatGwAAllocationId:
    Type: String
    Description: Fixed EIP for Nat Gateway Subnet A AllocationId
  
  # VPCのCIDRブロック
  VPCCIDR:
    Type: String
    Default: 10.60.0.0/22
    Description: VPC CIDR
  
  # 各サブネットのCIDR設定
  FirewallSubnetACIDR:
    Type: String
    Default: 10.60.0.240/28
  PublicSubnetACIDR:
    Type: String  
    Default: 10.60.0.128/26
  # ... その他のサブネット設定

Resources:
  # VPC作成
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: !Ref VPCCIDR
      EnableDnsSupport: true
      EnableDnsHostnames: true
  
  # パブリックサブネット作成
  PublicSubnetA:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: !Ref PublicSubnetACIDR
      AvailabilityZone: !Select [0, !GetAZs '']
  # ... その他のリソース定義

# 他のスタックで参照するための出力値
Outputs:
  Vpc:
    Value: !Ref VPC
    Export:
      Name: !Sub ${AWS::StackName}-Vpc
  
  PublicSubnetA:
    Value: !Ref PublicSubnetA
    Export:
      Name: !Sub ${AWS::StackName}-PublicSubnetA
  
  PrivateSubnetA:
    Value: !Ref PrivateSubnetA
    Export:
      Name: !Sub ${AWS::StackName}-PrivateSubnetA
```

### 2. Sceptre設定ファイル
**ファイル**: `sceptre/config/tst/vpc.yaml`

```yaml
# テンプレートファイルの指定
template:
  path: vpc.yaml        # templates/配下のファイル名
  type: file

# CloudFormationテンプレートのParametersセクションに渡す値
parameters:
  # 他のスタックの出力値を参照（依存関係）
  FixedNatGwAAllocationId: !stack_output tst/fixed-natgw-eip.yaml::NatGatewayEIPA
  FixedNatGwCAllocationId: !stack_output tst/fixed-natgw-eip.yaml::NatGatewayEIPC
  
  # 直接値を指定
  VPCCIDR: 10.60.0.0/22
  FirewallSubnetACIDR: 10.60.0.240/28
  PublicSubnetACIDR: 10.60.0.128/26
  PrivateSubnetACIDR: 10.60.0.0/25
  Environment: tst
  
  # S3バケットの参照（VPCフローログ用）
  VPCFlowlogBucket: !stack_output tst/s3.yaml::VPCFlowLogBucketName
  VPCFlowLogBucketArn: !stack_output tst/s3.yaml::VPCFlowLogBucketArn
```

### 3. 全体設定ファイル
**ファイル**: `sceptre/config/config.yaml`

```yaml
# プロジェクト全体の設定
project_code: ocx-standard-template  # スタック名プレフィックス
region: ap-northeast-1                # デプロイ先リージョン

# 全スタックに適用されるタグ
stack_tags:
  system_name: ocx-standard-template
  map-migrated: EXAMPLE    # AWS MAP2.0契約タグ
```

### 4. 実行方法とスタック名生成

```bash
# スタック状態確認
sceptre status tst/vpc.yaml

# スタック作成
sceptre deploy tst/vpc.yaml

# 生成されるスタック名: ocx-standard-template-tst-vpc
# 形式: {project_code}-{環境名}-{テンプレート名}
```

---

## サンプル2: goo住宅専用VPC（house-30-cfn）

### 1. CloudFormationテンプレート
**ファイル**: `sceptre/templates/vpc-dev.yaml`

```yaml
AWSTemplateFormatVersion: "2010-09-09"
Description: Create secure network set for goo housing service

Parameters:
  VPCCIDR:
    Type: String
    Default: 172.16.0.0/16
    Description: VPC CIDR for housing service
  
  # goo住宅サービス特有のパラメータ
  Environment:
    Type: String
    AllowedValues: [dev, stg, prod]
  
  # VPC Peering用パラメータ
  StgCidr:
    Type: String
    Description: Staging environment CIDR for peering
  
  VPCPeeringConnectionStgToDevId:
    Type: String
    Description: Existing VPC Peering Connection ID

Resources:
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: !Ref VPCCIDR
      # goo住宅サービス固有のタグ
      Tags:
        - Key: Service
          Value: goo-housing
        - Key: Environment  
          Value: !Ref Environment

  # goo住宅専用のセキュリティグループ
  HousingWebSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: Security group for goo housing web servers
      VpcId: !Ref VPC
      SecurityGroupIngress:
        # 不動産パートナー(athome, recruit)からのアクセス許可
        - IpProtocol: tcp
          FromPort: 443
          ToPort: 443
          CidrIp: 10.0.0.0/8  # パートナーVPN CIDR
```

### 2. Sceptre設定ファイル
**ファイル**: `sceptre/config/dev/vpc.yaml`

```yaml
template:
  path: vpc-dev.yaml    # goo住宅専用テンプレート
  type: file

parameters:
  # goo住宅開発環境用の設定
  VPCCIDR: 172.16.0.0/16
  Environment: dev
  
  # 他環境との接続設定
  StgCidr: 10.60.52.0/22
  VPCPeeringConnectionStgToDevId: pcx-0507778b385e49203
  
  # 依存スタックからの値取得
  FixedNatGwAAllocationId: !stack_output dev/fixed-natgw-eip.yaml::NatGatewayEIPA
  VPCFlowlogBucket: !stack_output dev/s3.yaml::VPCFlowLogBucketName
```

### 3. 実行とスタック管理

```bash
# 依存関係を自動解決してデプロイ
sceptre deploy dev/vpc.yaml

# goo住宅サービス全体のデプロイ
sceptre deploy dev/

# スタック名: house-30-dev-vpc
```

---

## サンプル3: OCN特化CloudFront（ocn-catalog-aws-templates）

### 1. CloudFormationテンプレート
**ファイル**: `sceptre/templates/cloudfront.yaml`

```yaml
AWSTemplateFormatVersion: "2010-09-09"
Description: Create CloudFront for OCN catalog site

Parameters:
  # システム共通パラメータ
  EnvShort:
    Type: String
    AllowedValues: [p, t, d]  # prod, test, dev
  
  SystemName:
    Type: String
  
  # CloudFront固有設定
  Name:
    Type: String
    Description: CloudFront distribution name
  
  DomainName:
    Type: String
    Description: Custom domain name for CloudFront
  
  CertificateArn:
    Type: String
    Description: ACM certificate ARN (must be in us-east-1)
  
  # ELBオリジン設定
  ELBDomainName:
    Type: String
    Description: ELB domain name as origin
  
  # WAF設定
  WebACLArn:
    Type: String
    Description: WAF WebACL ARN for security

Resources:
  CloudFrontDistribution:
    Type: AWS::CloudFront::Distribution
    Properties:
      DistributionConfig:
        Aliases:
          - !Ref DomainName
        ViewerCertificate:
          AcmCertificateArn: !Ref CertificateArn
          SslSupportMethod: sni-only
        WebACLId: !Ref WebACLArn
        Origins:
          - Id: ELBOrigin
            DomainName: !Ref ELBDomainName
            CustomOriginConfig:
              HTTPPort: 80
              HTTPSPort: 443
              OriginProtocolPolicy: https-only

Outputs:
  CloudFrontDomainName:
    Value: !GetAtt CloudFrontDistribution.DomainName
    Export:
      Name: !Sub ${AWS::StackName}-CloudFrontDomainName
```

### 2. Sceptre設定ファイル（環境別）
**ファイル**: `sceptre/config/dev/cloudfront-front.yaml`

```yaml
template:
  path: cloudfront.yaml     # 共通テンプレート
  type: file

parameters:
  # 環境別変数（Sceptreの変数展開機能）
  EnvShort: "{{ ENV_SHORT_NAME }}"      # d (dev環境)
  SystemName: "{{ project_code }}"       # ocn-catalog
  
  # OCN front環境固有の設定
  Name: "{{ ENV_NAME }}-front"           # dev-front
  DomainName: 'dev-front.service-test.ocn.ne.jp'
  
  # バージニア北部のACM証明書（CloudFront要件）
  CertificateArn: arn:aws:acm:us-east-1:890742565976:certificate/52bb9623-8194-4344-a5c0-f2e0a1f8cec3
  
  # 依存スタックからの値参照
  WebACLArn: !stack_output {{ ENV_NAME }}/waf-for-cloudfront-front.yaml::WebACLArn
  ELBDomainName: !stack_output {{ ENV_NAME }}/elb.yaml::InternetALBDNSName
  
  # キャッシュポリシー設定
  ELBOriginCachePolicyId: 83da9c7e-98b4-4e11-a168-04f0df8e2c65    # UseOriginCacheControlHeaders
  ELBOriginOriginRequestPolicyId: 216adef6-5c7f-47e4-b989-5492eafa07d3  # AllViewer
```

### 3. 複数環境の管理

```yaml
# dev/cloudfront-tool.yaml (ツール環境)
parameters:
  Name: "{{ ENV_NAME }}-tool"
  DomainName: 'dev-tool.service-test.ocn.ne.jp'
  WebACLArn: !stack_output {{ ENV_NAME }}/waf-for-cloudfront-tool.yaml::WebACLArn

# dev/cloudfront-git.yaml (Git環境)  
parameters:
  Name: "{{ ENV_NAME }}-git"
  DomainName: 'dev-git.service-test.ocn.ne.jp'
  WebACLArn: !stack_output {{ ENV_NAME }}/waf-for-cloudfront-git.yaml::WebACLArn
```

---

## Sceptreの主要機能詳細

### 1. スタック間依存関係管理

```yaml
# 依存関係の記述方法
parameters:
  VpcId: !stack_output network/vpc.yaml::VpcId
  SubnetIds: !stack_output network/vpc.yaml::PrivateSubnetIds
  SecurityGroupId: !stack_output security/sg.yaml::WebSecurityGroupId

# Sceptreが自動的に以下を実行：
# 1. network/vpc.yaml → security/sg.yaml → 現在のスタック の順番でデプロイ
# 2. 出力値の取得とパラメータ注入
# 3. 依存スタックが存在しない場合のエラー検出
```

### 2. 環境別設定管理

```
sceptre/config/
├── config.yaml              # 全環境共通設定
├── dev/
│   ├── config.yaml          # dev環境設定
│   ├── vpc.yaml            # dev用VPC設定  
│   └── cloudfront.yaml     # dev用CloudFront設定
├── prod/
│   ├── config.yaml          # prod環境設定
│   ├── vpc.yaml            # prod用VPC設定
│   └── cloudfront.yaml     # prod用CloudFront設定
└── templates/
    ├── vpc.yaml            # 共通VPCテンプレート
    └── cloudfront.yaml     # 共通CloudFrontテンプレート
```

### 3. コマンド例と実行順序

```bash
# 単一スタックのデプロイ
sceptre deploy dev/vpc.yaml

# 環境全体のデプロイ（依存関係順に自動実行）
sceptre deploy dev/

# スタックの状態確認
sceptre status dev/

# スタック出力値の確認  
sceptre list outputs dev/vpc.yaml

# スタックの削除（依存関係逆順で実行）
sceptre delete dev/
```

### 4. エラーハンドリングと運用

```bash
# 失敗時のロールバック
sceptre deploy dev/vpc.yaml --ignore-dependencies

# 差分確認（ドリフト検出）
sceptre diff dev/vpc.yaml

# テンプレート検証
sceptre validate dev/vpc.yaml

# 依存関係グラフの可視化
sceptre graph dev/
```

---

## 初心者向けベストプラクティス

### 1. テンプレート設計
- **単一責任**: 1つのテンプレートは1つの機能領域（VPC、DB、アプリなど）
- **パラメータ化**: 環境固有の値はParametersで外出し
- **出力値定義**: 他のスタックで使用する値は必ずOutputsで出力

### 2. Sceptre設定
- **環境分離**: dev/stg/prod環境は完全に分離
- **依存関係明示**: !stack_outputで明確に依存関係を記述
- **命名規則統一**: スタック名、リソース名の規則を統一

### 3. デプロイ戦略
- **段階的デプロイ**: 基盤→セキュリティ→アプリの順序
- **依存関係確認**: sceptre graphで事前に依存関係を確認
- **環境一貫性**: 同一テンプレートを全環境で使用

これらのサンプルを参考に、CloudFormationテンプレートとSceptreの連携による効率的なAWSインフラ管理を実現できます。

---

## 問い合わせ先

- **aws-templates-bprtech**: オンラインCX部 マーケティングtech室 運用改革担当/CX開発担当
- **house-30-cfn**: goo住宅・不動産サービスチーム  
- **ocn-catalog-aws-templates**: OCNカタログサイトチーム
