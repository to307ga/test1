

## idhubのAWS移行

### 期限の確認

いつまでに完了している必要があるか  

### AWS標準構成テンプレートを使って環境構築を行う  

* VPCのアドレスレンジ取得などの事務手続きは先行してやっておく必要がある  
* cloudformation を使うならスタック設計を事前にやる必要がある  
  https://zenn.dev/trkdkjm/articles/728cac0bbb8119  
    * ライフサイクルが同じものをまとめる  
		  VPC・ELB等のネットワークスタック  
		  WEB関連のEC2若しくはECS等のwebスタック　hlpとかは分ける？  
		  RDSスタック  
	    といった辺りの設計  
		

### AWS標準構成テンプレートを使う場合EC2ではなくECS Fargateが前提となるけどどうする？

* 標準構成に従いFargateにする
    * コンテナ化
        * ベストプラクティスは「1コンテナ1プロセス」 だけど技術的には httpd tomcat (proxysql)などを1つのコンテナにまとめることも可能  
        手間は変わらないので「1コンテナ1プロセス」で行きたい

        * 既存のWEB関連の確認  
			    httpdで受けたHTTPリクエストをtomcatへ転送しているという認識で良い？  
			    例えばHTTPで受けてCGIで完結していたり、httpd無にtomcatだけで動いてるとかは無い？  
			    httpdでvirtual host 使って複数URLの運用ってしてましたっけ？  
			
    * バッチ処理部分  
		  ECS Fargate でやるか Lambda でやるか  
			簡単な処理で短時間で終わるならLambda  
			30分で終わらない処理であれば無条件でFargate  

		* DBをいじれれば良い？WEBに結果ファイルとか配置したり、メール送信とかある？  
			あるならFargate  

* EC2にで作成する  
  標準構成から外れるけど社内的に問題ある！？	コンテナ化しないとダメ？  
	CPUはgraviton？	検証必要だけど時間とれる？  
    * AWSリソースからGitHubへのpullは出来ないらしい  
		  経路的に問題が無ければ現在のGiteaを使う  
		  EC2で暫定的に作る  
		  GitHub Actionsとか使う  
		

### ECS Fargateで構成した場合のサービス構成イメージ (ECS 部分のみ)

```mermaid
flowchart TD
    subgraph ECS Task
        direction LR
        httpd["httpdコンテナ"] -- 標準出力/エラー --> firelens["FireLens (Fluent Bit) サイドカー"]
        tomcat["tomcatコンテナ"] -- 標準出力/エラー --> firelens
        batch["バッチ処理コンテナ"] -- DB抽出/ファイル出力 --> sharedvol["共有ボリューム"]
        sharedvol -- ファイル配置 --> httpd
    end
    httpd -- HTTP --> user["利用者"]
    httpd --> tomcat
    batch -- DB接続 --> rds["RDS"]
    tomcat -- DB接続 --> rds
    firelens -- ログ転送 --> cloudwatch["CloudWatch Logs"]
    firelens -- option --> es["Elasticsearch等"]
```
