# Fargate移行に関するやり取りまとめ

---

Q: オンプレミスのRocky8 Linuxサーバ（httpd, tomcat, proxysql, mariadb-client, td-agent）をAWS ECS Fargateへ移行するには？
A: 各サービスをコンテナ化し、ECS Fargate上で個別に動かすのが推奨。httpdやtomcatは個別コンテナ、ProxySQLはRDS ProxyやAuroraへの置き換えも検討。td-agentはFireLens（Fluent Bit/Fluentd）で代替可能。

Q: httpdとtomcatは1つのコンテナにまとめられる？
A: 技術的には可能だが、ベストプラクティスは「1コンテナ1プロセス」。まとめる場合はsupervisord等で複数プロセス管理が必要。

Q: 1つのコンテナにまとめるDockerfile例は？
A: CentOSベースでhttpdとtomcatをインストールし、supervisordで両方起動するDockerfileとsupervisord.conf例を提示。

```Dockerfile
FROM centos:8

# 必要なパッケージのインストール
RUN dnf -y install httpd java-11-openjdk wget unzip epel-release && \
    dnf -y install supervisor

# Tomcatのインストール
ENV TOMCAT_VERSION=9.0.85
RUN wget https://downloads.apache.org/tomcat/tomcat-9/v${TOMCAT_VERSION}/bin/apache-tomcat-${TOMCAT_VERSION}.tar.gz && \
    tar xzf apache-tomcat-${TOMCAT_VERSION}.tar.gz -C /opt && \
    mv /opt/apache-tomcat-${TOMCAT_VERSION} /opt/tomcat && \
    rm apache-tomcat-${TOMCAT_VERSION}.tar.gz

# supervisordの設定ファイル
COPY supervisord.conf /etc/supervisord.conf

# ポート開放
EXPOSE 80 8080

CMD ["/usr/bin/supervisord", "-c", "/etc/supervisord.conf"]
```

`supervisord.conf` の例:
```ini
[supervisord]
nodaemon=true

[program:httpd]
command=/usr/sbin/httpd -DFOREGROUND

[program:tomcat]
command=/opt/tomcat/bin/catalina.sh run
```

Q: Fargate移行時のログ管理は？
A: 標準出力にリダイレクトしCloudWatch Logsへ転送、またはFireLens（Fluent Bit/Fluentd）でElasticsearch等へ転送が推奨。

Q: FireLensを使ったECSタスク定義例と、httpd/tomcatのログを標準出力に出す設定例は？
A: ECSタスク定義JSON例、httpdのErrorLog/CustomLogを/dev/stderr,/dev/stdoutに、tomcatのlogging.propertiesやcatalina.sh run利用例を提示。

```json
{
  "family": "sample-firelens-task",
  "networkMode": "awsvpc",
  "containerDefinitions": [
    {
      "name": "firelens-log-router",
      "image": "amazon/aws-for-fluent-bit:latest",
      "essential": true,
      "firelensConfiguration": {
        "type": "fluentbit",
        "options": {
          "enable-ecs-log-metadata": "true"
        }
      },
      "mountPoints": [
        {
          "sourceVolume": "applogs",
          "containerPath": "/shared-logs"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/firelens",
          "awslogs-region": "ap-northeast-1",
          "awslogs-stream-prefix": "firelens"
        }
      }
    },
    {
      "name": "app",
      "image": "your-app-image:latest",
      "essential": true,
      "mountPoints": [
        {
          "sourceVolume": "applogs",
          "containerPath": "/var/log/httpd"
        }
      ],
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "Name": "file",
          "Path": "/shared-logs/access_log",
          "Tag": "app-access"
        }
      },
      "environment": [
        { "name": "ACCESS_LOG_PATH", "value": "/var/log/httpd/access_log" },
        { "name": "ERROR_LOG_PATH", "value": "/var/log/httpd/error_log" }
      ],
      "portMappings": [
        { "containerPort": 80 },
        { "containerPort": 8080 }
      ]
    },
    {
      "name": "app-error-log",
      "image": "your-app-image:latest",
      "essential": false,
      "mountPoints": [
        {
          "sourceVolume": "applogs",
          "containerPath": "/var/log/httpd"
        }
      ],
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "Name": "file",
          "Path": "/shared-logs/error_log",
          "Tag": "app-error"
        }
      }
    }
  ],
  "volumes": [
    {
      "name": "applogs",
      "host": {}
    }
  ],
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024"
}
```

httpdのログを標準出力に出す設定例:
```apache
# エラーログを標準エラー出力へ
ErrorLog /dev/stderr

# アクセスログを標準出力へ
CustomLog /dev/stdout combined
```

tomcatのログを標準出力に出す設定例:
```properties
# conf/logging.properties の編集例
1catalina.org.apache.juli.FileHandler.directory = /dev
1catalina.org.apache.juli.FileHandler.prefix = stdout
```

Q: FireLensはサイドカーとして使える？
A: はい。同じタスク内でサイドカーとして動作し、ネットワーク共有やボリューム共有も可能。

Q: /var/log/httpd/にログを出しFireLensで読む場合の注意点は？
A: 可能だが、Fargateのローカルストレージは永続化されないため、ログは外部サービスに転送する設計が必須。

---

