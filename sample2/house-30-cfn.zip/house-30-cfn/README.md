# house-30-cfn
goo住宅・不動産のCloudFormation
