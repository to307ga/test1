def main():
    """メイン実行関数"""
    from scripts.setup_ssl import main as setup_main
    return setup_main()

if __name__ == "__main__":
    main()
