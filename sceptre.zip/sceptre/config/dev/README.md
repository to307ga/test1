# Development環境 デプロイ手順書

## 📊 開発環境 デプロイ概要

### 🚀 開発環境の特徴
- **目的**: 本番環境設定のテスト・検証
- **リソース最適化**: コスト削減のためリソース制限
- **機能テスト**: 本番前の機能検証環境

### 📋 設定差異一覧

#### 基本設定差異
| 項目 | 本番(prod) | 開発(dev) | 理由 |
|-----|------------|----------|------|
| ProjectCode | aws-ses-migration | aws-ses-migration-dev | 環境分離 |
| DKIMSelector | gooid-21-prod | gooid-21-dev | DNS分離 |
| RetentionDays | 731日 | 30日 | コスト最適化 |
| LambdaMemorySize | 512MB | 256MB | リソース最適化 |

#### 監視・アラート設定
| 項目 | 本番(prod) | 開発(dev) | 理由 |
|-----|------------|----------|------|
| SendSuccessRateThreshold | 95% | 90% | 開発環境は寛容 |
| BounceRateThreshold | 5% | 10% | テスト許容範囲拡大 |
| ComplaintRateThreshold | 0.1% | 0.5% | テスト許容範囲拡大 |
| EnableDataMasking | true | false | デバッグ容易性 |

#### セキュリティ設定
| 項目 | 本番(prod) | 開発(dev) | 理由 |
|-----|------------|----------|------|
| AllowedIPRanges | 限定的 | 広範囲 | 開発アクセス性 |
| EnableIPRestriction | true | false | 開発利便性 |
| EnablePersonalInformationProtection | true | false | デバッグ容易性 |

### 🔧 開発環境デプロイファイル構成

```
sceptre/config/dev/
├── config.yaml                    # 開発環境基本設定
├── base.yaml                     # 基盤システム（SNS等）
├── phase-1-infrastructure-foundation.yaml  # インフラ基盤
├── phase-2-dkim-system.yaml      # DKIM管理システム
├── phase-3-ses-byodkim.yaml      # SES + BYODKIM設定
├── phase-4-dns-preparation.yaml  # DNS準備
├── phase-5-dns-team-collaboration.yaml  # DNS連携
├── phase-7-dns-validation-dkim-activation.yaml  # DNS検証
├── phase-8-monitoring.yaml       # 統合監視システム
├── enhanced-kinesis.yaml         # Kinesisデータ処理
├── monitoring.yaml              # 監視設定
├── security.yaml                # セキュリティ設定
├── ses-kinesis-bridge.yaml      # SES-Kinesis連携
├── ses-sandbox-testing.yaml     # サンドボックステスト
└── README.md                    # このファイル
```

### 🚀 デプロイ手順

#### 1. 前提条件確認
```bash
# プロジェクトルートに移動
cd /path/to/AWS_SES_BYODKIM

# Sceptreディレクトリに移動
cd sceptre

# 設定ファイル検証
uv run sceptre validate dev/config.yaml
```

#### 2. 基盤システムデプロイ
```bash
# SNS等基盤システム
uv run sceptre launch dev/base.yaml --yes

# インフラ基盤
uv run sceptre launch dev/phase-1-infrastructure-foundation.yaml --yes
```

#### 3. DKIM・SESシステムデプロイ
```bash
# DKIM管理システム
uv run sceptre launch dev/phase-2-dkim-system.yaml --yes

# SES + BYODKIM設定
uv run sceptre launch dev/phase-3-ses-byodkim.yaml --yes
```

#### 4. DNS関連システムデプロイ
```bash
# DNS準備
uv run sceptre launch dev/phase-4-dns-preparation.yaml --yes

# DNS連携システム
uv run sceptre launch dev/phase-5-dns-team-collaboration.yaml --yes
```

#### 5. データ処理システムデプロイ
```bash
# Kinesisデータ処理
uv run sceptre launch dev/enhanced-kinesis.yaml --yes

# SES-Kinesis連携
uv run sceptre launch dev/ses-kinesis-bridge.yaml --yes
```

#### 6. 監視・セキュリティシステムデプロイ
```bash
# 監視システム
uv run sceptre launch dev/monitoring.yaml --yes

# セキュリティ設定
uv run sceptre launch dev/security.yaml --yes

# 統合監視システム
uv run sceptre launch dev/phase-8-monitoring.yaml --yes
```

#### 7. 最終検証・テストシステム
```bash
# DNS検証・DKIM有効化
uv run sceptre launch dev/phase-7-dns-validation-dkim-activation.yaml --yes

# サンドボックステスト設定
uv run sceptre launch dev/ses-sandbox-testing.yaml --yes
```

### 🔍 開発環境での確認事項

#### デプロイ後確認
```bash
# 全スタック状態確認
uv run sceptre status dev

# 特定スタックの詳細確認
uv run sceptre describe dev/phase-3-ses-byodkim.yaml
```

#### テスト実行
```bash
# SESテストメール送信（開発環境向け）
cd ../  # プロジェクトルートに戻る
python send_test_email.py --environment dev

# ログ確認（開発環境S3バケット）
python check_ses_logs.py --environment dev
```

### 🚨 重要な注意事項

#### 1. 環境分離の確認
- **S3バケット名**: `-dev-` サフィックス確認
- **DKIMセレクタ**: `gooid-21-dev` 確認
- **SNS通知**: 開発環境専用通知確認

#### 2. DNS設定の注意
- 開発環境のDKIMレコードは本番と分離
- テスト用サブドメイン使用推奨

#### 3. コスト最適化
- 不要時はスタック削除でコスト削減
- ログ保持期間が30日間で自動削除

#### 4. セキュリティ
- IP制限が緩和されているため本番データ使用禁止
- データマスキング無効でログ内容注意

### 📝 開発環境固有の機能

#### テスト機能有効化
- `EnableTokyoRegionFeatures: true`
- `EnableJapaneseMonitoring: true`
- `EnableCustomMetrics: true`

#### デバッグ支援
- `EnableDataMasking: false` - ログ詳細表示
- `EnableIPRestriction: false` - アクセス制限緩和
- `EnablePersonalInformationProtection: false` - デバッグ情報表示
