import { test, expect } from '@playwright/test';

test('ログ出力動作確認テスト', async ({ page }) => {

  await page.goto('https://login.mail.goo.ne.jp/id/Top');

  await test.step("dアカウントでログイン 確認" , async () =>{
    await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウントでログイン');
  });

  await test.step("他の方法でログイン 押下" , async () =>{
    await page.getByRole('button', { name: '他の方法でログイン ' }).click();
  });

  await test.step("新規登録はこちら 押下" , async () =>{
    await page.getByRole('link', { name: '新規登録はこちら' }).click();
  });

  await test.step("dアカウントにログイン 確認" , async () =>{
    await expect(page.locator('#register_docomo')).toContainText('dアカウントにログイン');
  });

  await test.step("他の方法で登録 押下" , async () =>{
    await page.getByRole('button', { name: '他の方法で登録 ' }).click();
  });

  await test.step("メールアドレスで登録 押下" , async () =>{
    await page.getByRole('link', { name: 'メールアドレスで登録' }).click();
  });

  await test.step("goo 押下" , async () =>{
    await page.getByRole('link', { name: 'goo', exact: true }).click();
  });

});
