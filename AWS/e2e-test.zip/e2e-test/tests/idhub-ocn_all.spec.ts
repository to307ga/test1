import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * idhub(OCN用)  動作確認
 */
test('idhub(OCN用)  動作確認', async ({ page, context }) => {

    // 環境別設定
    let idhubURL;
    let ocnid;
    let ocnidPass;
    const projectName = test.info().project.name;
    if (projectName === 'idhub-ocn_st1') {
        // 検証環境用
        idhubURL  = testconfig.url.idhub.st1;
        ocnid     = testconfig.account.ocn.dev.id;
        ocnidPass = testconfig.account.ocn.dev.pass;
    } else if (projectName === 'idhub-ocn_pro') {
        // 商用環境用
        idhubURL  = testconfig.url.idhub.pro;
        ocnid     = testconfig.account.ocn.pro.id;
        ocnidPass = testconfig.account.ocn.pro.pass;
    } else {
        test.skip(true, '開発環境:st2、st3は、対象外の為、スキップします');
    }

    // 連絡先
    const MAIL_01 = "e2e.test.auto+test101@gmail.com";

    // ユーザ名取得
    const ocnName = ocnid.slice(0, ocnid.indexOf('@'));

    await page.goto('/');

    await test.step('新規d連携', async () => {
        await test.step('dアカウントとocn IDの連携', async () => {
            // 動作確認
            await page.getByRole('link', { name: "dアカウントログイン" }).first().click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカウントとocn IDの連携 … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            await page.locator('#AuthLoginDisplay_comid').fill(ocnid);
            await page.locator('#AuthLoginDisplay_password').fill(ocnidPass);
            await page.locator('#AuthLoginDisplay_AuthLoginLogin').click();
            await page.locator('div.form-group-layout').nth(0).locator('label:has-text("*********78")').click();
            await page.locator('div.form-group-layout').nth(1).locator('label[for="telMethod_sms"]').click();
            await page.locator('div.btn-group').locator('input.btn.btn-next').click();
            let ocnidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカウントとocn IDの連携 … OCN SMS認証番号[${ocnidSMS}]`});
            await page.locator('#code').fill(ocnidSMS);
            await page.locator('div.btn-group').locator('input.btn.btn-next').click();
            await page.locator('div.btn-group').locator('a.btn.btn-next').click();
            // ポップアップが表示されない場合がある為の策
            try {
                await page.waitForNavigation();
                await page.locator('#popupContainerWrapper').locator('#f_noview').click();
                await page.locator('#TB_window').locator('#TB_closeWindowButton').click();
            } catch (erroer) {
            }

            // 検証
            await page.waitForTimeout(10000);
            expect(await page.content()).toContain(ocnName);
        });
    });

    // ログアウト
    await page.getByRole('link', { name: "ログアウト" }).first().click();
    await page.locator('div.btn-wrap').locator('a.button.login-select.color-a').click();
    await context.clearCookies();

    await test.step('ログイン', async () => {
        await test.step('dアカウントログイン', async () => {
            // 動作確認
            await page.getByRole('link', { name: "dアカウントログイン" }).first().click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカウントログイン … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            // ポップアップが表示されない場合がある為の策
            try {
                await page.waitForNavigation();
                await page.locator('#popupContainerWrapper').locator('#f_noview').click();
                await page.locator('#TB_window').locator('#TB_closeWindowButton').click();
            } catch (erroer) {
            }

            // 検証
            await page.waitForTimeout(10000);
            expect(await page.content()).toContain(ocnName);
        });
    });

    // idhubURLで実施
    await test.step('会員情報の登録・確認・変更（OCN）', async () => {

        await test.step('基本情報の変更', async () => {
            // 動作確認
            await page.goto(`${idhubURL}/idhub/portal/profile`);
            await page.locator('section.prof-sec').locator('div.btn-wrap').nth(0).locator('a.btn-radius.btn-w').click();
            await page.locator('#name').fill('自動テスト太郎');
            await page.locator('#kana').fill('ジドウテストタロウ');
            await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
            await page.locator('div.btn-wrap.prof-btn-2col').locator('span.btn-radius.btn-w.prof-btn-input-wrap').locator('input.prof-btn-input').click();
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();

            // 検証
            await expect(page.locator('section.prof-sec').nth(0)).toContainText("自動テスト太郎");
            await expect(page.locator('section.prof-sec').nth(0)).toContainText("ジドウテストタロウ");
        });

        await test.step('登録メールアドレスの変更', async () => {
            // 動作確認
            await page.locator('section.prof-sec').locator('div.btn-wrap').nth(1).locator('a.btn-radius.btn-w').click();
            await page.locator('dd.prof-tbl-desc').locator('input.prof-input-text').fill(MAIL_01);
            await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
            let idhubMail = await otp_mail(context);
            await test.info().annotations.push({type:"message" , description:`登録メールアドレスの変更 … メール認証番号[${idhubMail}]`});
            await page.locator('#code').fill(idhubMail);
            await page.locator('div.btn-wrap').locator('input.prof-btn-input').click();
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();

            // 検証
            await expect(page.locator('section.prof-sec').nth(1)).toContainText(MAIL_01);
        });

        await test.step('プライバシー設定の変更', async () => {
            // 動作確認
            await page.locator('section.prof-sec').locator('div.btn-wrap').nth(2).locator('a.btn-radius.btn-w').click();
            await page.locator('div.prof-checkbox-wrap').locator('label[for="recommend"]').click();
            await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();

            // 検証
            await expect(page.locator('section.prof-sec').nth(2)).toContainText("利用しない");
        });

        await test.step('dアカウント連携済みのID一覧表示', async () => {
            // 動作確認
            await page.goto(`${idhubURL}/idhub/portal/ocn_link`);

            // 検証
            await expect(page.locator('div.prof-sec').nth(0)).toContainText(testconfig.account.daccount.id);
            await expect(page.locator('div.prof-sec').nth(0)).toContainText(ocnid);
        });

        await test.step('メール受信設定（おトクなポイント情報）', async () => {
            // 動作確認
            await page.goto(`${idhubURL}/idhub/portal/magazine`);
            await page.locator('div.prof-sec.prof-mb-large').locator('a.btn-radius.btn-w').click();
            await page.locator('dd.prof-tbl-desc').locator('label[for="reject"]').click();
            await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();

            // 検証
            await page.locator('div.prof-sec.prof-mb-large').locator('a.btn-radius.btn-w').click();
            await expect(page.locator('#reject')).toBeChecked();
        });

        await test.step('OCN連携解除', async () => {
            // 動作確認
            await page.goto(`${idhubURL}/idhub/portal/withdraw_start_account`);
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();
            await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();

            // 検証
            await page.goto(`${idhubURL}/idhub/portal/withdraw_start_account`);
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();
            await expect(page.locator('h2.error-ttl')).toContainText("ご利用のdアカウントは連携されていません。");
        });
        // ログアウト
        await page.goto('/');
        await page.getByRole('link', { name: "ログアウト" }).first().click();
        await page.locator('div.btn-wrap').locator('a.button.login-select.color-a').click();
        await context.clearCookies();
    });
});
