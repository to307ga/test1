import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * gooid 動作確認（重要度：HIGH, MIDDLE）
 */
test('gooid 動作確認（重要度：HIGH, MIDDLE）', async ({ page, context }) => {

    // 現在日時取得
    const now = new Date();

    // 検証対象項目
    const loginName = testconfig.account.gooid.new.id.substr( 0, 2 ) + "*****";

    await test.step("ログイン１" , async () =>{
        await test.step("メールログイン（2段階認証：なし）" , async () =>{
            // 動作確認
            await page.goto('/id/authn/LoginStart');
            await page.locator('#show-button').click();
            await page.locator('#uname').fill(testconfig.account.gooid.new.id);
            await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
            await page.locator('#gooid_login').click();
            await page.locator('#skip').click();

            // 検証
            await expect(page.locator('#loginname')).toContainText(loginName);

            // ログアウト
            await page.locator('#logout').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
        });

        // 商用環境で電話番号が登録されていない会員があるか不明の為、一旦、検証環境:ST1のみ動作確認を行う
        const projectName = test.info().project.name;
        if (projectName === 'gooid_st1') {
            await test.step("メールログイン（2段階認証：メール認証）" , async () =>{
                // 動作確認
                await page.goto('/id/authn/EnhancedLoginStart?El=2m', { waitUntil: 'domcontentloaded' });
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(testconfig.account.gooid.old.id);
                await page.locator('#pass').fill(testconfig.account.gooid.old.pass);
                await page.locator('#gooid_login').click();
                await page.locator('#mailauth').click();
                await page.locator('#next').click();
                let gooidMail = await otp_mail(context);
                await test.info().annotations.push({type:"message" , description:`メールログイン（2段階認証：メール認証） … メール認証番号[${gooidMail}]`});
                await page.locator('#code').fill(gooidMail);
                await page.locator('#next').click();
                await page.locator('#skip').click();

                // 検証
                await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.old.id);

                // ログアウト
                await page.locator('#logout').click();
                await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
            });
        }

        await test.step("メールログイン（2段階認証：SMS認証）" , async () =>{
            // 動作確認
            await page.goto('/id/authn/EnhancedLoginStart?El=2', { waitUntil: 'domcontentloaded' });
            await page.locator('#show-button').click();
            await page.locator('#uname').fill(testconfig.account.gooid.new.id);
            await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
            await page.locator('#gooid_login').click();
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`メールログイン（2段階認証：SMS認証）… gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
            await page.locator('#skip').click();

            // 検証
            await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.new.id);
        });
    });

    await test.step("外部ID連携１" , async () =>{
        await test.step("dアカ連携" , async () =>{
            // 動作確認
            await page.locator('#federate-list').click();
            await page.locator('#f_docomo').click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカ連携 … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            await page.locator('#next').click();
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカ連携 … gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウント連携の登録が完了しました。');
            await page.locator('#forward').click();

            // 検証
            let registDateText = await page.locator('.table-federate-list tr:nth-child(1) td:nth-child(3)').innerText();
            const registDate = new Date(registDateText.match(/\d{1,4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}/)[0]);
            await expect(registDate.getTime()).toBeGreaterThan(now.getTime());
            await expect(page.locator('#f_docomo')).toContainText('解除する');

            // ログアウト
            await page.locator('#back').click();
            await page.locator('#logout').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
            await page.locator('#back').click();
            await context.clearCookies();
        });
    });

    await test.step("ログイン２" , async () =>{
        await test.step("dアカログイン" , async () =>{
            // 動作確認
            await page.locator('div.login-lead-btn').locator('a:has-text("dアカウントでログイン")').click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカログイン … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();

            // 検証
            await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.new.id);
        });
    });

    await test.step("外部ID連携２" , async () =>{
        await test.step("dアカ連携解除" , async () =>{
            // 動作確認
            await page.locator('#federate-list').click();
            await page.locator('#f_docomo').click();
            await page.locator('#next').click();
            await page.locator('#next').click();
            await expect(page.locator('h1')).toContainText('dアカウント連携を解除 完了');
            await page.locator('#back').click();

            // 検証
            let registDateText = await page.locator('.table-federate-list tr:nth-child(1) td:nth-child(3)').innerText();
            await expect(registDateText).toBe("");
            await expect(page.locator('#f_docomo')).toContainText('連携する');

            // TOP画面に戻る
            await page.locator('#back').click();
        });
    });

    await test.step("ログアウト" , async () =>{
        // 動作確認
        await page.locator('#logout').click();
        await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
        await page.locator('#back').click();

        // 検証
        await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウントでログイン');
        await context.clearCookies();
    });

    await test.step("新規登録" , async () =>{
        await test.step("dアカで新規登録" , async () =>{
            // 動作確認
            await page.goto('/id/Top');
            await page.locator('#newid').click();
            await page.locator('#register_docomo').click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカで新規登録 … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            await page.locator('#Telephone1').fill('08077185178');
            await page.locator('#FamilyName').fill('山田');
            await page.locator('#FirstName').fill('太郎');
            await page.locator('#FamilyKana').fill('やまだ');
            await page.locator('#FirstKana').fill('たろう');
            await page.locator('#next').click();
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカで新規登録 … gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウント連携の登録が完了しました。');

            // TOP画面へ遷移
            await page.locator('#forward').click();

            // 検証
            await expect(page.locator('#loginname')).toContainText(testconfig.account.daccount.id);
        });
    });

    await test.step("dポイント" , async () =>{
        await test.step("dカウント・dポイント確認" , async () =>{
            // 動作確認
            await page.locator('#daccount').click();

            // 検証
            await expect(page.locator('#NR-wrapper-in')).toContainText(testconfig.account.daccount.id);

            // TOP画面へ遷移
            await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
        });
    });

    await test.step("gooID削除" , async () =>{
        await test.step("gooID削除" , async () =>{
            // 動作確認
            await page.locator('#withdrawal').click();
            await page.locator('#next').click();

            // 検証
            await expect(page.locator('#NR-wrapper-in')).toContainText('gooIDの削除が完了しました。');

            // gooトップ画面へ遷移
            await page.locator('#forward').click();
            await context.clearCookies();
        });
    });
});
