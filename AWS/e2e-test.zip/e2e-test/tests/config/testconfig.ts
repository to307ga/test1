export const testconfig = (() => {
    const config = {

        // アカウント情報
        // ※ローカルPCでテストする場合、各パスワード、変更電話番号を設定する必要があります
        account : {
            daccount : {
                id : "e2e.test.auto@gmail.com",
                pass : "",
            },
            gooid : {
                new : {
                    id : "e2e.test.auto+test001@gmail.com",
                    pass : "",
                    tel : "08077185178",
                },
                old : {
                    id : "e2e-test-auto_test901",
                    pass : "",
                    mail : "e2e.test.auto+test901@gmail.com",
                },
            },
            ocn : {
                dev : {
                    id : "qqzz6nz9k@music.ocn.ne.jp",
                    pass : "",
                    tel : "08077185178",
                },
                pro : {
                    id : "qqkd8wh9k@vesta.ocn.ne.jp",
                    pass : "",
                    tel : "08077185178",
                },
            },
            chocom : {
                no1 : {
                    id : "846147012456312393922C00",
                    mail : "id.test.1002@gmail.com",
                    pass : "",
                    tel : "0300000000",
                },
                no2 : {
                    id : "846147012416512793922C02",
                    mail : "id.test.1003@gmail.com",
                    pass : "",
                    tel : "0300000000",
                },
            },
        },

        // URL情報
        url : {
            gooid : {
                st1 : "https://lin101.mail.goo.ne.jp",
                st2 : "https://lin201.mail.goo.ne.jp",
                st3 : "https://lin301.mail.goo.ne.jp",
                pro : "https://login.mail.goo.ne.jp",
            },
            idhub : {
                st1 : "https://dev101.auth.d.goo.ne.jp",
                st2 : "https://dev201.auth.d.goo.ne.jp",
                st3 : "https://dev301.auth.d.goo.ne.jp",
                pro : "https://auth.d.goo.ne.jp",
            },
        },

        // API情報
        api : {
            smscheck_url : "https://script.google.com/macros/s/AKfycbwzwjXBrj0kPQ-qSIWVHZdGeAgUPAsH5lh3j2GUyhMJxxLI7s3fSS1n1c-ndfvLbauI/exec",
            mailcheck_url : "https://script.google.com/macros/s/AKfycby-W1zjT5ED9cC18lEKNoXEYVry84Ad0ZbEE0VofdxnhKrvdOMELYB5GhTmFZPV5X276A/exec",
        },

        // 変更電話番号
        change_tel : "",

        // SMS取得設定情報
        sms_config : {
            wait_time : 5000,
            repeat_count : 12,
        },
    };

    // jenkinsからの実行で値が変わる
    // dアカウント
    if(process.env.daccount_id){
        config.account.daccount.id = process.env.daccount_id;
    }
    if(process.env.daccount_pass){
        config.account.daccount.pass = process.env.daccount_pass;
    }

    // gooid新会員
    if(process.env.gooid_new_id){
        config.account.gooid.new.id = process.env.gooid_new_id;
    }
    if(process.env.gooid_new_pass){
        config.account.gooid.new.pass = process.env.gooid_new_pass;
    }
    if(process.env.gooid_new_tel){
        config.account.gooid.new.tel = process.env.gooid_new_tel;
    }

    // gooid旧会員
    if(process.env.gooid_old_id){
        config.account.gooid.old.id = process.env.gooid_old_id;
    }
    if(process.env.gooid_old_pass){
        config.account.gooid.old.pass = process.env.gooid_old_pass;
    }
    if(process.env.gooid_old_tel){
        config.account.gooid.old.tel = process.env.gooid_old_tel;
    }

    // ocn
    if(process.env.ocn_dev_id){
        config.account.ocn.dev.id = process.env.ocn_dev_id;
    }
    if(process.env.ocn_dev_pass){
        config.account.ocn.dev.pass = process.env.ocn_dev_pass;
    }
    if(process.env.ocn_dev_tel){
        config.account.ocn.dev.tel = process.env.ocn_dev_tel;
    }
    if(process.env.ocn_pro_id){
        config.account.ocn.pro.id = process.env.ocn_pro_id;
    }
    if(process.env.ocn_pro_pass){
        config.account.ocn.pro.pass = process.env.ocn_pro_pass;
    }
    if(process.env.ocn_pro_tel){
        config.account.ocn.pro.tel = process.env.ocn_pro_tel;
    }

    // chocom
    if(process.env.chocom_no1_id){
        config.account.chocom.no1.id = process.env.chocom_no1_id;
    }
    if(process.env.chocom_no1_mai){
        config.account.chocom.no1.mail = process.env.chocom_no1_mai;
    }
    if(process.env.chocom_no1_pass){
        config.account.chocom.no1.pass = process.env.chocom_no1_pass;
    }
    if(process.env.chocom_no1_tel){
        config.account.chocom.no1.tel = process.env.chocom_no1_tel;
    }
    if(process.env.chocom_no2_id){
        config.account.chocom.no2.id = process.env.chocom_no2_id;
    }
    if(process.env.chocom_no2_mai){
        config.account.chocom.no2.mail = process.env.chocom_no2_mai;
    }
    if(process.env.chocom_no2_pass){
        config.account.chocom.no2.pass = process.env.chocom_no2_pass;
    }
    if(process.env.chocom_no2_tel){
        config.account.chocom.no2.tel = process.env.chocom_no2_tel;
    }

    // 変更電話番号
    if(process.env.change_tel){
        config.change_tel = process.env.change_tel;
    }
    return config;
})();
