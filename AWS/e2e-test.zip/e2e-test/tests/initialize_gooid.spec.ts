import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * 初期化処理
 * 内容：エラーが発生したときにテスト実施前に状態を戻す
 */
test('初期化処理', async ({ page, context }) => {

    // 連絡先
    const MAIL_01 = "e2e.test.auto+test101@gmail.com";
    const MAIL_02 = "e2e.test.auto+test201@gmail.com";

    // パスワード
    const GOOID_PASS = "e2etest4321";

    // フラグ管理
    let login_flg = true;    // true: ログイン済、false: 未ログイン
    let pass_flg  = true;    // pass  true: デフォルト、false: 変更後
    let sync_flg  = true;    // d連携 true: 連携済    、false: 未連携

    // 接続先
    let gooidURL;
    const projectName = test.info().project.name;
    switch (projectName) {
        case 'initialize_st1':
            gooidURL = testconfig.url.gooid.st1;
            break;
        case 'initialize_st2':
            gooidURL = testconfig.url.gooid.st2;
            break;
        case 'initialize_st3':
            gooidURL = testconfig.url.gooid.st3;
            break;
        case 'initialize_pro':
            gooidURL  = testconfig.url.gooid.pro;
            break;
        default:
            throw new Error('project指定ミス');
    }

    await test.step('gooidを初期状態にします。', async () => {
        try {
            // gooid(初期値),pass(初期値)でのログイン
            await page.goto(`${gooidURL}/id/authn/LoginStart`);
            await page.locator('#show-button').click();
            await page.locator('#uname').fill(testconfig.account.gooid.new.id);
            await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
            await page.locator('#gooid_login').click();
            if (page.url().includes('/id/authn/')) {
                sync_flg = false;
                await page.locator('#skip').click();
            }
            login_flg = true;
            pass_flg  = true;
        } catch (e) {
            login_flg = false;
        }
        if (!login_flg){
            try {
                // gooid(初期値),pass(変更後)でのログイン
                await page.goto(`${gooidURL}/id/authn/LoginStart`);
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(testconfig.account.gooid.new.id);
                await page.locator('#pass').fill(GOOID_PASS);
                await page.locator('#gooid_login').click();
                if (page.url().includes('/id/authn/')) {
                    sync_flg = false;
                    await page.locator('#skip').click();
                }
                login_flg = true;
                pass_flg  = false;
            } catch (e) {
                login_flg = false;
            }
        }
        if (!login_flg){
            try {
                // gooid(変更後),pass(初期値)でのログイン
                await page.goto(`${gooidURL}/id/authn/LoginStart`);
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(MAIL_01);
                await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
                await page.locator('#gooid_login').click();
                if (page.url().includes('/id/authn/')) {
                    sync_flg = false;
                    await page.locator('#skip').click();
                }
                pass_flg = true;
            } catch (e) {
                throw new Error('※※※ 状態の確認が必要です。 ※※※');
            }
        }
        // SMS認証→会員情報画面表示
        await page.locator('#profile').click();
        await page.locator('#next').click();
        let gooidSMS = await otp_sms(context);
        await page.locator('#code').fill(gooidSMS);
        await page.locator('#next').click();

        await test.step('電話番号①をチェックします。', async () => {
            console.log("電話番号①をチェックします。");
            try {
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(1) td').textContent();
                await expect(telText).toMatch(testconfig.account.gooid.new.tel);
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                await page.locator('div.form-group').nth(2).locator('tr:nth-child(1) td').locator('a:has-text("変更する")').click();
                await page.locator('#tel').fill(testconfig.account.gooid.new.tel);
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await page.locator('#otp').fill(gooidSMS);
                await page.locator('#next').click();
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(1) td').textContent();
                await expect(telText).toMatch(testconfig.account.gooid.new.tel);
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });

        await test.step('電話番号②をチェックします。', async () => {
            console.log("電話番号②をチェックします。");
            try {
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(2) td').textContent();
                await expect(telText).toMatch('未登録');
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                page.once('dialog', dialog => {
                    dialog.accept();
                });
                await page.locator('div.form-group').nth(2).locator('tr:nth-child(2) td').locator('a:has-text("削除する")').click();
                await page.waitForTimeout(5000);
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(2) td').textContent();
                await expect(telText).toMatch('未登録');
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });

        await test.step('gooIDをチェックします。', async () => {
            console.log("gooIDをチェックします。");
            try {
                await expect(page.locator('#GooID')).toContainText(testconfig.account.gooid.new.id);
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(1) td').locator('a:has-text("gooIDを変更する")').click();
                await page.locator('#MailAddress1').fill(testconfig.account.gooid.new.id);
                await page.locator('#next').click();
                let gooidMail = await otp_mail(context);
                await page.goto(gooidMail, { waitUntil: 'domcontentloaded' });
                await page.locator('#forward').click();
                await expect(page.locator('#GooID')).toContainText(testconfig.account.gooid.new.id);
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });

        await test.step('予備メールアドレスをチェックします。', async () => {
            console.log("予備メールアドレスをチェックします。");
            try {
                let mailText = await page.locator('div.form-group').nth(3).locator('tbody tr:nth-child(2) td').textContent();
                await expect(mailText).toMatch('未登録');
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                page.once('dialog', dialog => {
                    dialog.accept();
                });
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(2) td').locator('a:has-text("削除する")').click();
                await page.waitForTimeout(5000);
                let mailText = await page.locator('div.form-group').nth(3).locator('tbody tr:nth-child(2) td').textContent();
                await expect(mailText).toMatch('未登録');
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });

        await test.step('gooIDログインのパスワードをチェックします。', async () => {
            console.log("gooIDログインのパスワードをチェックします。");
            if (pass_flg) {
                console.log("　　　　　 … 初期状態でした。");
            } else {
                try {
                    await page.locator('div.form-group').nth(3).locator('tr:nth-child(3) td').locator('a:has-text("変更する")').click();
                    await page.locator('#OldPassword').fill(GOOID_PASS);
                    await page.locator('#NewPassword').fill(testconfig.account.gooid.new.pass);
                    await page.locator('#next').click();
                    await page.locator('#back').click();
                    console.log("　　　　　 … 初期状態に戻しました。");
                } catch (e) {
                    console.log("　　　　　 … 初期状態でした。");
                }
            }
        });

        // TOPにもどる
        await page.locator('#back').click();

        await test.step('支払い方法登録をチェックします。', async () => {
            console.log("支払い方法登録をチェックします。");
            await page.locator('#settlement-info').click();
            try {
                const creditBtnText = await page.locator('div.payment:has(div.payment-heading:has-text("クレジットカード")) a.btn').innerText();
                await expect(creditBtnText).toBe("登録する");
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                await page.locator('div.text-align-right').locator('a:has-text("すべてのお支払い方法を削除する")').click();
                page.once('dialog', dialog => {
                    dialog.accept();
                });
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();
                await expect(page.locator('#NR-wrapper-in')).toContainText('支払い方法の削除完了');
                await expect(page.locator('#NR-wrapper-in')).toContainText('お支払い方法の削除が完了しました。');
                await page.locator('div.btn-group').nth(0).locator('a:has-text("戻る")').click();
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });

        // TOP画面に戻る
        await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();

        await test.step('dアカウント連携をチェックします。', async () => {
            console.log("dアカウント連携をチェックします。");
            await page.locator('#federate-list').click();
            try {
                await expect(page.locator('#f_docomo')).toContainText('連携する');
                console.log("　　　　　 … 初期状態でした。");
            } catch (e) {
                await page.locator('#f_docomo').click();
                await page.locator('#next').click();
                await page.locator('#next').click();
                await expect(page.locator('h1')).toContainText('dアカウント連携を解除 完了');
                await page.locator('#back').click();
                let registDateText = await page.locator('.table-federate-list tr:nth-child(1) td:nth-child(3)').innerText();
                await expect(registDateText).toBe("");
                await expect(page.locator('#f_docomo')).toContainText('連携する');
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });
        // 新規ユーザを削除するためログアウト
        await page.locator('#back').click();
        await page.locator('#logout').click();
        await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
        await page.locator('#back').click();

        await test.step("追加した新規ユーザ削除をチェックします。" , async () =>{
            console.log("追加した新規ユーザ削除をチェックします。");
            await page.goto(`${gooidURL}/id/Top`);
            await page.locator('#newid').click();
            await page.locator('#register_docomo').click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカで新規登録 … dアカウントログインSMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            await page.waitForNavigation({ waitUntil: 'networkidle' });
            if (page.url().includes('/id/api/auth/')) {
                await page.locator('div.btn-group').nth(0).locator('#back').click();
            } else {
                await page.locator('#Telephone1').fill('08077185178');
                await page.locator('#FamilyName').fill('山田');
                await page.locator('#FirstName').fill('太郎');
                await page.locator('#FamilyKana').fill('やまだ');
                await page.locator('#FirstKana').fill('たろう');
                await page.locator('#next').click();
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await page.locator('#code').fill(gooidSMS);
                await page.locator('#next').click();
                await page.locator('#forward').click();
            }
            await expect(page.locator('#loginname')).toContainText(testconfig.account.daccount.id);
            await page.locator('#withdrawal').click();
            await page.locator('#next').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('gooIDの削除が完了しました。');
            console.log("　　　　　 … 初期状態に戻しました。");
        });
        await test.step('gooidを初期状態にしました。', async () => {
            await context.clearCookies();
        });
    });
});
