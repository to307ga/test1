import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * 初期化処理
 * 内容：エラーが発生したときにテスト実施前に状態を戻す
 */
test('初期化処理', async ({ page, context }) => {

    // 接続先
    let idhubURL;
    const projectName = test.info().project.name;
    switch (projectName) {
        case 'initialize_st1':
            idhubURL  = testconfig.url.idhub.st1;
            break;
        case 'initialize_st2':
            idhubURL  = testconfig.url.idhub.st2;
            break;
        case 'initialize_st3':
            idhubURL  = testconfig.url.idhub.st3;
            break;
        case 'initialize_pro':
            idhubURL  = testconfig.url.idhub.pro;
            break;
        default:
            throw new Error('project指定ミス');
    }

    await test.step('idhubを初期状態にします。', async () => {
        await test.step('OCN連携をチェックします。', async () => {
            console.log("OCN連携をチェックします。");
            await page.goto(`${idhubURL}/idhub/portal/withdraw_start_account`);
            await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();
            if (page.url().includes('/authx/cgi/baseauth')) {
                // 未ログインなのでログインさせる
                await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
                await page.getByTestId('onClickIdConfirmBtn').click();
                await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
                await page.getByTestId('onClickPwdConfirmBtn').click();
                await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
                let daccountSMS = await otp_sms(context);
                await page.getByTestId('submitLoginInput_0').click();
                await page.keyboard.type(daccountSMS , { delay: 100 });
                await page.getByTestId('submitLoginButton').click();
            }
            try {
                await expect(page.locator('h2.error-ttl')).toContainText("ご利用のdアカウントは連携されていません。");
                console.log("　　　　　 … 初期状態でした。");
            } catch {
                await page.locator('div.btn-wrap.prof-btn-2col').locator('input.prof-btn-input').click();
                await page.locator('div.prof-sec').locator('div.btn-wrap').locator('a.btn-radius.btn-w').click();
                console.log("　　　　　 … 初期状態に戻しました。");
            }
        });
    });
    await test.step('idhubを初期状態にしました。', async () => {
        await context.clearCookies();
    });
});
