import { test, expect } from '@playwright/test';
import { otp_sms, getElParam } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * gooID-OIDC 動作確認
 */
test('gooID-OIDC 動作確認', async ({ page, context }) => {

    // 環境別設定
    let gooidURL;
    const projectName = test.info().project.name;
    if (projectName === 'gooid-oidc_st1') {
        gooidURL = testconfig.url.gooid.st1;
    } else if (projectName === 'gooid-oidc_pro') {
        gooidURL = testconfig.url.gooid.pro; 
    } else {
        test.skip(true, '開発環境:st2、st3は、対象外の為、スキップします');
    }

    await page.goto('/');

    await test.step('メールログイン（gooID・パスワード認証）', async () => {

        // 動作確認  (ログインボタンの遷移先が検証環境と商用環境で異なる為
        await page.getByRole('link', { name: "ログイン" }).first().click();
        await page.waitForNavigation();
        const el = getElParam(await page.url());     // 認証レベルを取得
        const button = page.locator('#show-button');
        if (await button.count() > 0 && await button.isVisible()){
            await button.click();
        }
        await page.locator('#uname').fill(testconfig.account.gooid.new.id);
        await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
        await page.locator('#gooid_login').click();

        // ログインURLでルートがかわります。
        if ( el === '2' || el === '2m' ) {
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`メールログイン（2段階認証：SMS認証）… gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
        }
        await page.locator('#skip').click();

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain('会員ページ');

        // ログアウト
        await page.getByRole('link', { name: "会員ページ" }).first().click();
        await page.getByRole('link', { name: "会員ログアウト" }).first().click();
        await page.locator('#forward').click();
        await context.clearCookies();
    });

    await test.step('dアカウント新規登録', async () => {
        // 動作確認
        await page.getByRole('link', { name: "ログイン" }).first().click();
        await page.waitForNavigation();
        const el = getElParam(await page.url());     // 認証レベルを取得
        await page.locator('div.login-lead-btn').locator('a:has-text("dアカウントでログイン")').click();
        await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
        await page.getByTestId('onClickIdConfirmBtn').click();
        await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
        await page.getByTestId('onClickPwdConfirmBtn').click();
        await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
        let daccountSMS = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウント新規登録 … dアカウントログインSMS番号[${daccountSMS}]`});
        await page.getByTestId('submitLoginInput_0').click();
        await page.keyboard.type(daccountSMS , { delay: 100 });
        await page.getByTestId('submitLoginButton').click();
        await page.locator('div.linkage-btns').locator('a:has-text("すでにgooID登録済みの")').click();
        await page.locator('#uname').fill(testconfig.account.gooid.new.id);
        await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
        await page.locator('#gooid_login').click();
        await page.locator('#next').click();

        // ログインURLでルートがかわります。
        let gooidSMS;
        if ( el === '2' || el === '2m' ) {
            gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカウント新規登録 … (1回目) gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
        } else {
            await page.locator('#next').click();
            gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`dアカウント新規登録 … (1回目) gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
        }

        await page.locator('#next').click();
        await page.locator('#next').click();
        await page.locator('#next').click();
        gooidSMS = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウント新規登録 … (2回目) gooID SMS認証番号[${gooidSMS}]`});
        await page.locator('#code').fill(gooidSMS);
        await page.locator('#next').click();
        await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウント連携の登録が完了しました。');
        await page.locator('#forward').click();

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain('会員ページ');

        // ログアウト
        await page.getByRole('link', { name: "会員ページ" }).first().click();
        await page.getByRole('link', { name: "会員ログアウト" }).first().click();
        await page.locator('#forward').click();
        await context.clearCookies();
    });

    await test.step('dアカウントログイン', async () => {
        // 動作確認
        await page.getByRole('link', { name: "ログイン" }).first().click();
        await page.waitForNavigation();
        const el = getElParam(await page.url());     // 認証レベルを取得
        await page.locator('div.login-lead-btn').locator('a:has-text("dアカウントでログイン")').click();
        await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
        await page.getByTestId('onClickIdConfirmBtn').click();
        await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
        await page.getByTestId('onClickPwdConfirmBtn').click();
        await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
        let daccountSMS = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウントログイン … dアカウントログインSMS番号[${daccountSMS}]`});
        await page.getByTestId('submitLoginInput_0').click();
        await page.keyboard.type(daccountSMS , { delay: 100 });
        await page.getByTestId('submitLoginButton').click();

        // ログインURLでルートがかわります。
        if (el === '2') {
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`メールログイン（2段階認証：SMS認証）… gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
        }

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain('会員ページ');
    });

    // イニシャライズ　※d連携解除状態に戻す
    await page.goto(`${gooidURL}/id/sso/portal/WithdrawStartActionForOpenid`);
    await page.locator('#f_docomo').click();
    await page.locator('#next').click();
    await page.locator('#next').click();
    await expect(page.locator('h1')).toContainText('dアカウント連携を解除 完了');
    await page.locator('#back').click();
    await page.locator('#back').click();

    await page.locator('#logout').click();
    await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
    await context.clearCookies();
});
