import { BrowserContext } from "@playwright/test";
import { testconfig } from "../config/testconfig";

/**
 * SMS認証コードを返却
 * @param context BrowserContext
 * @returns SMS認証コード
 */
export const otp_sms = async (context : BrowserContext) =>  {

    // 設定
    const waitTime = testconfig.sms_config.wait_time;
    const repeatCount = testconfig.sms_config.repeat_count;

    // 初回読み込み
    let initialContent = await sms_read(context);

    // 5秒待機する関数
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // 処理内容:5秒間隔でSMS表示画面を表示し取得する。
    // ※初回の値との差異があればそこで繰返しを終了させる。
    let newContent = initialContent;
    for (let i = 0; i < repeatCount; i++) {
        await sleep(waitTime);
        newContent = await sms_read(context);
        if (newContent !== initialContent) {
            break;
        }
    }
    // SMSコードの切り取り
    // ※複数該当することがあった場合、すべて返してしまうので1番目を指定（現状、１番目がSMSコードの為）
    return newContent?.match(/\d{4,10}/)?.[0] || "";
}

/**
 * ブラウザのタブを開き、SMS受信結果を確認しメッセージ内容を返却する
 * @param context BrowserContext
 * @returns メッセージ
 */
export const sms_read = async (context : BrowserContext) =>  {
    const page1 = await context.newPage();
    await page1.goto(testconfig.api.smscheck_url);
    const message = await page1.frameLocator('#sandboxFrame').frameLocator('#userHtmlFrame').locator('#message').textContent();
    await page1.close();
    return message;
}

/**
 * Gmailに届いたメール内容を返却 ※対象：gooid, idhub, gbs-springからのOTPを返す
 * @param context BrowserContext
 * @returns 認証コード
 */
export const otp_mail = async (context : BrowserContext) =>  {

    // 設定
    const waitTime = testconfig.sms_config.wait_time;
    const repeatCount = testconfig.sms_config.repeat_count;

    // 初回読み込み
    let initialContent = await mail_read(context);

    // 5秒待機する関数
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // 処理内容:5秒間隔でSMS表示画面を表示し取得する。
    // ※初回の値との差異があればそこで繰返しを終了させる。
    let newContent = initialContent;
    for (let i = 0; i < repeatCount; i++) {
        await sleep(waitTime);
        newContent = await mail_read(context);
        if (newContent !== initialContent) {
            break;
        }
    }
    return newContent ?? "";
}

/**
 * ブラウザのタブを開き、Gmailの受信結果を確認しメッセージ内容を返却する
 * @param context BrowserContext
 * @returns メッセージ
 */
export const mail_read = async (context : BrowserContext) =>  {
    const page1 = await context.newPage();
    await page1.goto(testconfig.api.mailcheck_url);
    const message = await page1.frameLocator('#sandboxFrame').frameLocator('#userHtmlFrame').locator('#message').textContent();
    await page1.close();
    return message;
}

/**
 * URLから必要認証レベルを取得　※ログインURL専用
 * @param url 
 * @returns 認証レベル
 */
export const getElParam = (url, paramName) => {
    // URLオブジェクトを作成
    const urlObj = new URL(url);
    // クエリパラメータを取得
    const queryParams = new URLSearchParams(urlObj.search);
    // 指定したパラメータの値を取得、存在しない場合はデフォルト値を返す
    return queryParams.get('El') || "1";
}
