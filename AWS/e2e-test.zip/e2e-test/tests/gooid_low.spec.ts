import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * gooid 動作確認（重要度：LOW）
 */
test('gooid 動作確認（重要度：LOW）', async ({ page, context }) => {

    // 現在日時取得
    const now = new Date();

    // 会員登録情報
    // 名前
    const NAME_01 = "テスト";
    const NAME_02 = "テスト太郎";
    const KANA_01 = "てすと";
    const KANA_02 = "てすとたろう";
    // 住所
    const ADDRESS_01 = "";
    const ADDRESS_02 = "千代田区";
    // 連絡先
    const MAIL_01 = "e2e.test.auto+test101@gmail.com";
    const MAIL_02 = "e2e.test.auto+test201@gmail.com";
    // パスワード
    const GOOID_PASS = "e2etest4321";

    // セットアップ　※テストユーザをログイン済みのd連携を状態にする
    // メールログイン（2段階認証：SMS認証）
    await test.step("ログイン" , async () =>{
        await test.step("メールログイン（2段階認証：なし）" , async () =>{
            await page.goto('/id/authn/EnhancedLoginStart?El=2', { waitUntil: 'domcontentloaded' });
            await page.locator('#show-button').click();
            await page.locator('#uname').fill(testconfig.account.gooid.new.id);
            await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
            await page.locator('#gooid_login').click();
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`メールログイン（2段階認証：SMS認証）… gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
            await page.locator('#skip').click();
            await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.new.id);
        });

        await test.step("d連携" , async () =>{
            await page.locator('#federate-list').click();
            await page.locator('#f_docomo').click();
            await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
            await page.getByTestId('onClickIdConfirmBtn').click();
            await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
            await page.getByTestId('onClickPwdConfirmBtn').click();
            await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
            let daccountSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`d連携 … dアカウント SMS番号[${daccountSMS}]`});
            await page.getByTestId('submitLoginInput_0').click();
            await page.keyboard.type(daccountSMS , { delay: 100 });
            await page.getByTestId('submitLoginButton').click();
            await page.locator('#next').click();
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`d連携 … (2回目) gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#code').fill(gooidSMS);
            await page.locator('#next').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウント連携の登録が完了しました。');
            await page.locator('#forward').click();
            await page.locator('#back').click();
        });
    });

    await test.step("ログイン履歴" , async () =>{
        await test.step("ログイン履歴" , async () =>{
            // 動作確認
            await page.locator('#login-history').click();

            // 検証
            const loginDateText = await page.textContent('#NR-wrapper-in tbody tr:nth-child(1) td:nth-child(1)');
            const loginDate = new Date(loginDateText);
            await expect(loginDate.getTime()).toBeGreaterThan(now.getTime());

            // TOP画面へ遷移
            await page.locator('#back').click();
        });
    });

    await test.step("登録情報１" , async () =>{
        await test.step("お名前・性別、住所、ログイン通知メール、DM配信の変更" , async () =>{
            await test.step("動作確認" , async () =>{
                // 動作確認
                await page.locator('#profile').click();
                await page.locator('#FirstName').fill(NAME_02);
                await page.locator('#FirstNameKana').fill(KANA_02);
                await page.locator('label[for="Sex3"]').click();
                await page.locator('#Address1').fill(ADDRESS_02);
                await page.locator('label[for="AlertLogin1"]').click();
                await page.locator('label[for="DMFlg"]').click();
                await page.locator('#next').click();
                await page.locator('#next').click();

                // 検証
                await expect(page.locator('#FirstName')).toHaveValue(NAME_02);
                await expect(page.locator('#FirstNameKana')).toHaveValue(KANA_02);
                await expect(page.locator('#Sex3')).toBeChecked();
                await expect(page.locator('#Address1')).toHaveValue(ADDRESS_02);
                await expect(page.locator('#AlertLogin1')).toBeChecked();
                await expect(page.locator('#DMFlg')).toBeChecked();
            });

            await test.step("イニシャライズ" , async () =>{
                // イニシャライズ
                await page.locator('#FirstName').fill(NAME_01);
                await page.locator('#FirstNameKana').fill(KANA_01);
                await page.locator('label[for="Sex1"]').click();
                await page.locator('#Address1').fill(ADDRESS_01);
                await page.locator('label[for="AlertLogin2"]').click();
                await page.locator('label[for="DMFlg"]').click();
                await page.locator('#next').click();
                await page.locator('#next').click();

                // 検証
                await expect(page.locator('#FirstName')).toHaveValue(NAME_01);
                await expect(page.locator('#FirstNameKana')).toHaveValue(KANA_01);
                await expect(page.locator('#Sex1')).toBeChecked();
                await expect(page.locator('#Address1')).toHaveValue(ADDRESS_01);
                await expect(page.locator('#AlertLogin2')).toBeChecked();
                await expect(page.locator('#DMFlg')).not.toBeChecked();
            });
        });

        await test.step("電話番号の変更" , async () =>{
            await test.step("動作確認" , async () =>{
                // 動作確認
                await page.locator('div.form-group').nth(2).locator('tr:nth-child(1) td').locator('a:has-text("変更する")').click();
                await page.locator('#tel').fill(testconfig.change_tel);
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await test.info().annotations.push({type:"message" , description:`電話番号の変更 … (1回目) gooID SMS認証番号[${gooidSMS}]`});
                await page.locator('#otp').fill(gooidSMS);
                await page.locator('#next').click();

                // 検証
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(1) td').textContent();
                await expect(telText).toMatch(testconfig.change_tel);
            });

            await test.step("イニシャライズ" , async () =>{
                // イニシャライズ
                await page.locator('div.form-group').nth(2).locator('tr:nth-child(1) td').locator('a:has-text("変更する")').click();
                await page.locator('#tel').fill(testconfig.account.gooid.new.tel);
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await test.info().annotations.push({type:"message" , description:`電話番号の変更 … (2回目) gooID SMS認証番号[${gooidSMS}]`});
                await page.locator('#otp').fill(gooidSMS);
                await page.locator('#next').click();
                let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(1) td').textContent();
                await expect(telText).toMatch(testconfig.account.gooid.new.tel);
            });
        });

        await test.step("電話番号の登録" , async () =>{
            // 動作確認
            await page.locator('div.form-group').nth(2).locator('tr:nth-child(2) td').locator('a:has-text("登録する")').click();
            await page.locator('#tel').fill(testconfig.change_tel);
            await page.locator('#next').click();
            let gooidSMS = await otp_sms(context);
            await test.info().annotations.push({type:"message" , description:`電話番号の登録 … gooID SMS認証番号[${gooidSMS}]`});
            await page.locator('#otp').fill(gooidSMS);
            await page.locator('#next').click();

            // 検証
            let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(2) td').textContent();
            await expect(telText).toMatch(testconfig.change_tel);
        });

        await test.step("電話番号の削除" , async () =>{
            // 動作確認
            page.once('dialog', dialog => {
                dialog.accept();
            });
            await page.locator('div.form-group').nth(2).locator('tr:nth-child(2) td').locator('a:has-text("削除する")').click();

            // 検証
            await page.waitForTimeout(5000);
            let telText = await page.locator('div.form-group').nth(2).locator('tbody tr:nth-child(2) td').textContent();
            await expect(telText).toMatch('未登録');
        });

        await test.step("gooIDの変更" , async () =>{
            await test.step("動作確認" , async () =>{
                // 動作確認
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(1) td').locator('a:has-text("gooIDを変更する")').click();
                await page.locator('#MailAddress1').fill(MAIL_01);
                await page.locator('#next').click();
                let gooidMail = await otp_mail(context);
                await test.info().annotations.push({type:"message" , description:`gooIDの変更 … (1回目) メール認証番号[${gooidMail}]`});
                await page.goto(gooidMail, { waitUntil: 'domcontentloaded' });
                await page.locator('#forward').click();

                // 検証
                await expect(page.locator('#GooID')).toContainText(MAIL_01);
            });

            await test.step("イニシャライズ" , async () =>{
                // イニシャライズ
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(1) td').locator('a:has-text("gooIDを変更する")').click();
                await page.locator('#MailAddress1').fill(testconfig.account.gooid.new.id);
                await page.locator('#next').click();
                let gooidMail = await otp_mail(context);
                await test.info().annotations.push({type:"message" , description:`gooIDの変更 … (2回目) メール認証番号[${gooidMail}]`});
                await page.goto(gooidMail, { waitUntil: 'domcontentloaded' });
                await page.locator('#forward').click();

                // 検証
                await expect(page.locator('#GooID')).toContainText(testconfig.account.gooid.new.id);
            });
        });

        await test.step("予備のメールアドレス追加" , async () =>{
            // 動作確認
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(2) td').locator('a:has-text("登録する")').click();
            await page.locator('#MailAddress1').fill(MAIL_01);
            await page.locator('#next').click();
            let gooidMail = await otp_mail(context);
            await test.info().annotations.push({type:"message" , description:`予備のメールアドレス追加 … URL情報[${gooidMail}]`});
            await page.goto(gooidMail, { waitUntil: 'domcontentloaded' });
            await page.locator('#forward').click();

            // 検証
            let mailText = await page.locator('div.form-group').nth(3).locator('tbody tr:nth-child(2) td').textContent();
            await expect(mailText).toMatch(MAIL_01);
        });

        await test.step("予備のメールアドレス変更" , async () =>{
            // 動作確認
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(2) td').locator('a:has-text("変更する")').click();
            await page.locator('#MailAddress1').fill(MAIL_02);
            await page.locator('#next').click();
            let gooidMail = await otp_mail(context);
            await test.info().annotations.push({type:"message" , description:`予備のメールアドレス変更 … URL情報[${gooidMail}]`});
            await page.goto(gooidMail, { waitUntil: 'domcontentloaded' });
            await page.locator('#forward').click();

            // 検証
            let mailText = await page.locator('div.form-group').nth(3).locator('tbody tr:nth-child(2) td').textContent();
            await expect(mailText).toMatch(MAIL_02);
        });

        await test.step("予備のメールアドレス削除" , async () =>{
            // 動作確認
            page.once('dialog', dialog => {
                dialog.accept();
            });
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(2) td').locator('a:has-text("削除する")').click();

            // 検証
            await page.waitForTimeout(5000);
            let mailText = await page.locator('div.form-group').nth(3).locator('tbody tr:nth-child(2) td').textContent();
            await expect(mailText).toMatch('未登録');
        });

        await test.step("gooIDログインのパスワードの変更" , async () =>{
            await test.step("動作確認" , async () =>{
                // 動作確認
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(3) td').locator('a:has-text("変更する")').click();
                await page.locator('#OldPassword').fill(testconfig.account.gooid.new.pass);
                await page.locator('#NewPassword').fill(GOOID_PASS);
                await page.locator('#next').click();
                await page.locator('#back').click();

                // 検証
                await page.locator('#logout').click();
                await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
                await context.clearCookies();
                await page.goto('/id/authn/EnhancedLoginStart?El=2', { waitUntil: 'domcontentloaded' });
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(testconfig.account.gooid.new.id);
                await page.locator('#pass').fill(GOOID_PASS);
                await page.locator('#gooid_login').click();
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await test.info().annotations.push({type:"message" , description:`gooIDログインのパスワードの変更 … (1回目) gooID SMS認証番号[${gooidSMS}]`});
                await page.locator('#code').fill(gooidSMS);
                await page.locator('#next').click();
                await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.new.id);
            });

            await test.step("イニシャライズ" , async () =>{
                // イニシャライズ
                await page.locator('#profile').click();
                await page.locator('div.form-group').nth(3).locator('tr:nth-child(3) td').locator('a:has-text("変更する")').click();
                await page.locator('#OldPassword').fill(GOOID_PASS);
                await page.locator('#NewPassword').fill(testconfig.account.gooid.new.pass);
                await page.locator('#next').click();
                await page.locator('#back').click();

                // 検証
                await page.locator('#logout').click();
                await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
                await page.goto('/id/authn/EnhancedLoginStart?El=2', { waitUntil: 'domcontentloaded' });
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(testconfig.account.gooid.new.id);
                await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
                await page.locator('#gooid_login').click();
                await page.locator('#next').click();
                let gooidSMS = await otp_sms(context);
                await test.info().annotations.push({type:"message" , description:`gooIDログインのパスワードの変更 … (2回目) gooID SMS認証番号[${gooidSMS}]`});
                await page.locator('#code').fill(gooidSMS);
                await page.locator('#next').click();
                await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.new.id);
            });
        });

        await test.step("dアカウント メルマガ配信の変更）" , async () =>{
            // 動作確認
            await page.locator('#profile').click();
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(5) td').locator('a:has-text("dアカウント メルマガ配信設定を変更する")').click();
            await page.locator('label[for="point-no"]').click();
            await page.locator('label[for="guidance-no"]').click();
            await page.locator('#next').click();
            await page.locator('#next').click();
            await page.locator('#forward').click();

            // 検証
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(5) td').locator('a:has-text("dアカウント メルマガ配信設定を変更する")').click();
            await expect(page.locator('#point-no')).toBeChecked();
            await expect(page.locator('#guidance-no')).toBeChecked();

            // 会員情報画面へ遷移
            await page.locator('#back').click();
        });

        await test.step("プライバシー設定の変更" , async () =>{
            // 動作確認
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(6) td').locator('a:has-text("プライバシー設定を変更する")').click();
            await page.locator('label[for="recommendPermission2"]').click();
            await page.locator('div.btn-group').locator('input.btn.btn-submit').click();
            await page.locator('div.btn-group').locator('input.btn.btn-submit').click();
            await page.locator('div.btn-group').locator('a.btn.btn-back').click();

            // 検証
            await page.locator('div.form-group').nth(3).locator('tr:nth-child(6) td').locator('a:has-text("プライバシー設定を変更する")').click();
            await expect(page.locator('#recommendPermission2')).toBeChecked();

            // 会員情報画面へ遷移
            await page.locator('div.btn-group').locator('a.btn.btn-back').click();
            await page.locator('#back').click();
        });
    });
    // 外部ID連携解除
    await page.locator('#federate-list').click();
    await page.locator('#f_docomo').click();
    await page.locator('#next').click();
    await page.locator('#next').click();
    await expect(page.locator('h1')).toContainText('dアカウント連携を解除 完了');
    await page.locator('#back').click();
    await page.locator('#back').click();

    // ログアウト
    await page.locator('#logout').click();
    await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
    await context.clearCookies();

    // 検証環境:ST1のみの確認　※旧会員と新会員で連絡先メールアドレス、予備のメールアドレスは異なり、旧会員は検証環境のみの為
    const projectName = test.info().project.name;
    if (projectName === 'gooid_st1') {
        await test.step("登録情報２" , async () =>{
            await test.step("ログイン（旧会員）" , async () =>{
                // ログイン
                await page.goto('/id/authn/EnhancedLoginStart?El=2m', { waitUntil: 'domcontentloaded' });
                await page.locator('#show-button').click();
                await page.locator('#uname').fill(testconfig.account.gooid.old.id);
                await page.locator('#pass').fill(testconfig.account.gooid.old.pass);
                await page.locator('#gooid_login').click();
                await page.locator('#mailauth').click();
                await page.locator('#next').click();
                let gooidMail = await otp_mail(context);
                await test.info().annotations.push({type:"message" , description:`連絡先メールアドレス変更、予備のメールアドレス変更 … メール認証番号[${gooidMail}]`});
                await page.locator('#code').fill(gooidMail);
                await page.locator('#next').click();
                await page.locator('#skip').click();
                await expect(page.locator('#loginname')).toContainText(testconfig.account.gooid.old.id);
            });

            await test.step("連絡先メールアドレス変更、予備のメールアドレス変更" , async () =>{
                await test.step("動作確認" , async () =>{
                    // 動作確認
                    await page.locator('#profile').click();
                    await page.locator('#MailAddress1').fill(MAIL_01);
                    await page.locator('#MailAddress2').fill(MAIL_02);
                    await page.locator('#next').click();
                    await page.locator('#next').click();

                    // 検証
                    await expect(page.locator('#MailAddress1')).toHaveValue(MAIL_01);
                    await expect(page.locator('#MailAddress2')).toHaveValue(MAIL_02);
                });

                await test.step("動作確認" , async () =>{
                    // イニシャライズ
                    await page.locator('#MailAddress1').fill(testconfig.account.gooid.old.mail);
                    await page.locator('#MailAddress2').fill("");
                    await page.locator('#next').click();
                    await page.locator('#next').click();

                    // 検証
                    await expect(page.locator('#MailAddress1')).toHaveValue(testconfig.account.gooid.old.mail);
                    await expect(page.locator('#MailAddress2')).toHaveValue("");
                });
            });

            // TOP画面へ遷移
            await page.locator('#back').click();

            // ログアウト
            await page.locator('#logout').click();
            await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
            await context.clearCookies();
        });
    }
});
