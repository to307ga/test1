import { test, expect } from '@playwright/test';
import { otp_sms } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * idhub(ラウンジ用) 動作確認
 */
test('idhub(ラウンジ用) 動作確認', async ({ page, context }) => {

    // 検証情報
    const LOGIN_ID = "e2***********@gmail.com";

    // URLの取得
    let gooidURL;
    const projectName = test.info().project.name;
    if (projectName === 'idhub-lounge_st1') {
        gooidURL = testconfig.url.gooid.st1; 
    } else if (projectName === 'idhub-lounge_pro') {
        gooidURL = testconfig.url.gooid.pro; 
    } else {
        test.skip(true, '開発環境:st2、st3は、対象外の為、スキップします');
    }

    await page.goto('/content');

    await test.step('dアカウントとのgooIDを連携', async () => {
        // 動作確認
        await page.getByRole('link', { name: 'ログイン' }).first().click();
        await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
        await page.getByTestId('onClickIdConfirmBtn').click();
        await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
        await page.getByTestId('onClickPwdConfirmBtn').click();
        await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
        let daccountSMS = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウントとのgooIDを連携 … dアカウントログインSMS番号[${daccountSMS}]`});
        await page.getByTestId('submitLoginInput_0').click();
        await page.keyboard.type(daccountSMS , { delay: 100 });
        await page.getByTestId('submitLoginButton').click();
        await page.locator('div.btn-wrap.prof-mt-zero').locator('a:has-text("dアカウントとgooIDを連携する")').click();
        await page.locator('#uname').fill(testconfig.account.gooid.new.id);
        await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
        await page.locator('#gooid_login').click();
        await page.locator('#next').click();
        await page.locator('#next').click();
        let gooidSMS1 = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウントとのgooIDを連携 … (1回目)gooID SMS認証番号[${gooidSMS1}]`});
        await page.locator('#code').fill(gooidSMS1);
        await page.locator('#next').click();
        await page.locator('#next').click();
        await page.locator('#next').click();
        let gooidSMS2 = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウントとのgooIDを連携 … (2回目)gooID SMS認証番号[${gooidSMS2}]`});
        await page.locator('#code').fill(gooidSMS2);
        await page.locator('#next').click();
        await expect(page.locator('#NR-wrapper-in')).toContainText('dアカウント連携の登録が完了しました。');
        await page.locator('#forward').click();

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain(LOGIN_ID);
    });

    await test.step('ログアウト', async () => {
        // 動作確認
        await page.getByRole('link', { name: 'ログアウト' }).click();
        await page.locator('#forward').click();

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain('ログイン');
        await context.clearCookies();
    });

    await test.step('dアカウントログイン', async () => {
        // 動作確認
        await page.getByRole('link', { name: 'ログイン' }).first().click();
        await page.getByTestId('changeDAccountIdInput').fill(testconfig.account.daccount.id);
        await page.getByTestId('onClickIdConfirmBtn').click();
        await page.getByTestId('changePasswordInput').fill(testconfig.account.daccount.pass);
        await page.getByTestId('onClickPwdConfirmBtn').click();
        await expect(page.getByTestId('dispMessage')).toContainText('2段階認証用のセキュリティコードを送信しました。ご確認の上、セキュリティコードを入力してください。');  
        let daccountSMS = await otp_sms(context);
        await test.info().annotations.push({type:"message" , description:`dアカウントログイン … dアカウントログインSMS番号[${daccountSMS}]`});
        await page.getByTestId('submitLoginInput_0').click();
        await page.keyboard.type(daccountSMS , { delay: 100 });
        await page.getByTestId('submitLoginButton').click();

        // 検証
        await page.waitForTimeout(10000);
        expect(await page.content()).toContain(LOGIN_ID);
    });

    // イニシャライズ　※d連携解除状態に戻す
    // ログイン（SMS認証）
    await page.goto(`${gooidURL}/id/sso/portal/WithdrawStartActionForOpenid`);
    await page.locator('#show-button').click();
    await page.locator('#uname').fill(testconfig.account.gooid.new.id);
    await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
    await page.locator('#gooid_login').click();
    await page.locator('#next').click();
    let gooidSMS = await otp_sms(context);
    await test.info().annotations.push({type:"message" , description:`イニシャライズ … gooID SMS認証番号[${gooidSMS}]`});
    await page.locator('#code').fill(gooidSMS);
    await page.locator('#next').click();

    // d連携解除
    await page.locator('#f_docomo').click();
    await page.locator('#next').click();
    await page.locator('#next').click();
    await expect(page.locator('h1')).toContainText('dアカウント連携を解除 完了');
    await page.locator('#back').click();
    await page.locator('#back').click();

    // ログアウト
    await page.locator('#logout').click();
    await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
    await context.clearCookies();
});
