import { test, expect } from '@playwright/test';
import { otp_sms, otp_mail } from './util/util';
import { testconfig } from './config/testconfig';

/**
 * 有料系  動作確認
 */
test('有料系  動作確認', async ({ page, context }) => {

    // 払込番号
    let orderNum;

    // 現在日時取得（ご利用中の有料サービスの検証時は、年月日時分までの為、秒、ミリ秒は0とする）
    const now = new Date();
    now.setSeconds(0, 0);

    // カード登録情報
    const CORD_NAME = "TEST AUTO";
    const CORD_NO = "4111111111111111";
    const MASK_CORD_NO = "4111-11**-****-**11";
    const EXPIRY_01_M = "12";
    const EXPIRY_01_Y = "50";
    const EXPIRY_01_MY = "12/50";
    const EXPIRY_02_M = "1";
    const EXPIRY_02_Y = "51";
    const EXPIRY_02_MY ="01/51";
    const PAYMENT_PASSWORD_01 = "test1234";
    const PAYMENT_PASSWORD_02 = "4321tset";

    // ちょコムチェックフラグ
    // ※ 1系以外の場合、エラーになる可能性があるため、登録できない場合、ちょコムのテストはスルーする。
    let chocom_chk_flg = true;    // true: チェックする、false: チェックしない

    // 初めのページ
    await page.goto('/gbs/settlementInf/index');

    // セットアップ　※テストユーザをgooidでログイン済みを状態にする
    // ログイン
    await page.locator('#show-button').click();
    await page.locator('#uname').fill(testconfig.account.gooid.new.id);
    await page.locator('#pass').fill(testconfig.account.gooid.new.pass);
    await page.locator('#gooid_login').click();
    await page.locator('#next').click();
    let gooidSMS = await otp_sms(context);
    await test.info().annotations.push({type:"message" , description:`セットアップ … SMS認証番号[${gooidSMS}]`});
    await page.locator('#code').fill(gooidSMS);
    await page.locator('#next').click();
    await page.locator('#skip').click();

    // テスト環境で実行ケースを変更
    const projectName = test.info().project.name;
    if (projectName === 'gbs-spring_pro') {
        // 商用環境用
        await test.step('支払い方法の確認・変更１', async () => {
            await test.step('支払い方法の確認', async () => {
                // 検証
                await expect(page.locator('h1')).toHaveText(/支払い方法の確認・変更/);

                // TOP画面に戻る
                await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
            });
        });
    } else {
        // 検証環境用
        await test.step('支払い方法の確認・変更１', async () => {
            await test.step('クレジットカード登録・支払い方法の確認', async () => {
                // 動作確認
                await page.locator('div.payment').nth(0).locator('a:has-text("登録する")').click();
                await page.locator('#card_number').fill(CORD_NO);
                await page.locator('#card_limit_month').selectOption(EXPIRY_01_M);
                await page.locator('#card_limit_year').fill(EXPIRY_01_Y);
                await page.locator('#securityCode').fill('1234');
                await page.locator('#card_user_name').fill(CORD_NAME);
                await page.locator('#Password').fill(PAYMENT_PASSWORD_01);
                await page.locator('label[for="agreement_checkbox"]').click();
                await page.locator('#btn_submit').click();

                // 検証
                let cordNo   = await page.locator('div.payment').nth(0).locator('tr:nth-child(1) td').textContent();
                let expiry   = await page.locator('div.payment').nth(0).locator('tr:nth-child(2) td').textContent();
                let cordName = await page.locator('div.payment').nth(0).locator('tr:nth-child(3) td').textContent();
                await expect(page.locator('h1')).toContainText('支払い方法の確認・変更');
                await expect(cordNo).toBe(MASK_CORD_NO);
                await expect(expiry).toBe(EXPIRY_01_MY);
                await expect(cordName).toBe(CORD_NAME);
            });

            await test.step('クレジットカード変更', async () => {
                // 動作確認
                await page.locator('div.payment').nth(0).locator('a:has-text("変更する")').click();
                await page.locator('#card_number').fill(CORD_NO);
                await page.locator('#card_limit_month').selectOption(EXPIRY_02_M);
                await page.locator('#card_limit_year').fill(EXPIRY_02_Y);
                await page.locator('#securityCode').fill('1234');
                await page.locator('#card_user_name').fill(CORD_NAME);
                await page.locator('label[for="agreement_checkbox"]').click();
                await page.locator('#btn_submit').click();

                // 検証
                let expiry = await page.locator('div.payment').nth(0).locator('tr:nth-child(2) td').textContent();
                await expect(expiry).toBe(EXPIRY_02_MY);
            });

            await test.step('ちょコム登録', async () => {
                let chocomId;
                try {
                    // 動作確認
                    await page.locator('div.payment').nth(1).locator('a:has-text("ちょコムを登録済みの方")').click();
                    await page.getByRole('button', { name: 'ちょコムにログイン' }).click();
                    await page.locator('input[name="mailAddress"]').fill(testconfig.account.chocom.no1.mail);
                    await page.locator('input[name="telNumber"]').fill(testconfig.account.chocom.no1.tel);
                    await page.locator('input[name="password"]').fill(testconfig.account.chocom.no1.pass);
                    await page.getByRole('button', { name: 'ログイン' }).click();
                    await page.locator('#send_button').click();

                    // 検証
                    chocomId = await page.locator('div.payment').nth(1).locator('tr:nth-child(1) td').textContent();
                } catch (e) {
                    chocom_chk_flg = false;
                    await page.goto('/gbs/settlementInf/index');
                }
                if (chocom_chk_flg){
                    // 正常に検証項目が取得できた場合、検証を実施
                    await expect(chocomId).toBe(testconfig.account.chocom.no1.id);
                }
            });

             // ちょコム登録が正常の場合、実施
            if (chocom_chk_flg){
                await test.step('ちょコム変更', async () => {
                    // 動作確認
                    await page.locator('div.payment').nth(1).locator('a:has-text("変更する")').click();
                    await page.locator('input[name="mailAddress"]').fill(testconfig.account.chocom.no2.mail);
                    await page.locator('input[name="telNumber"]').fill(testconfig.account.chocom.no2.tel);
                    await page.locator('input[name="password"]').fill(testconfig.account.chocom.no2.pass);
                    await page.getByRole('button', { name: 'ログイン' }).click();
                    await page.locator('#send_button').click();

                    // 検証
                    let chocomId = await page.locator('div.payment').nth(1).locator('tr:nth-child(1) td').textContent();
                    await expect(chocomId).toBe(testconfig.account.chocom.no2.id);
                });

                await test.step('ちょコム削除', async () => {
                    // 動作確認
                    await page.locator('div.payment').nth(1).locator('a:has-text("削除")').click();
                    page.once('dialog', dialog => {
                        dialog.accept();
                    });
                    await page.locator('div.btn-group').locator('input.btn.btn-next').click();

                    // 検証
                    await expect(await page.locator('div.payment').nth(1)).toContainText('ちょコムを登録済みの方');
                });
            }
        });

        // TOP画面に戻る
        await page.getByRole('link', { name: 'トップ', exact: true }).click();

        await test.step('購入導線１', async () => {
            await test.step('商品購入', async () => {
                // 動作確認
                const page1 = await context.newPage();
                await page1.goto('/gbs/sttlServiceSelect/sttlPreRegist?svcid=01&str_cd=20001051&gds_id=00101');
                await page1.locator('div.payment-form').locator('input[name="pin_code"]').fill(PAYMENT_PASSWORD_01);
                await page1.locator('div.payment-form').locator('button.btn.btn-submit').click();

                // 検証
                await expect(page1.locator('#NR-wrapper-in')).toContainText('購入完了');
                await expect(page1.locator('#NR-wrapper-in')).toContainText('ご購入ありがとうございました');

                // 払込番号を取得（購入履歴の検証で使用）
                orderNum = await page1.locator('table.payment-list >> tr:has(th:has-text("払込番号")) >> td').textContent();

                // 購入ページを閉じる
                await page1.close();
            });
        });

        await test.step('購入履歴', async () => {
            await test.step('購入履歴', async () => {
                // 動作確認
                await page.locator('#buy-history').click();
                await page.locator('div.btn-group').locator('button.btn.btn-next').click();

                // 検証
                const cellOrderNum = await page.locator('div.table-list-inner table tbody tr:last-child td:nth-child(2)').textContent();
                await expect(cellOrderNum).toBe(orderNum);

                // TOP画面に戻る
                await page.locator('div.btn-group').locator('a.btn.btn-back').click();
                await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
            });
        });

        await test.step('決済', async () => {
            await test.step('秘密の質問設定', async () => {
                // 動作確認
                await page.locator('#secret-question').click();
                await page.locator('#answer').fill('テスト病院');
                await page.locator('#code').fill(PAYMENT_PASSWORD_01);
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('秘密の質問と回答の設定');
                await expect(page.locator('#NR-wrapper-in')).toContainText('設定が完了しました。');

                // TOP画面に戻る
                await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
            });

            await test.step('決済パスワード変更', async () => {
                // 動作確認
                await page.locator('#update-pincode').click();
                await page.locator('#oldCode').fill(PAYMENT_PASSWORD_01);
                await page.locator('#newCode').fill(PAYMENT_PASSWORD_02);
                await page.locator('div.btn-group').locator('input.btn.btn-submit').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('決済パスワードの変更完了');
                await expect(page.locator('#NR-wrapper-in')).toContainText('決済パスワードの変更が完了しました。');

                // TOP画面に戻る
                await page.locator('div.btn-group').locator('a.btn.btn-back').click();
            });

            await test.step('決済パスワード再設定', async () => {
                // 動作確認
                await page.locator('#reset-pincode').click();
                await page.locator('#birthdayYear').fill('2000');
                await page.locator('#birthdayMonth').selectOption('1');
                await page.locator('#birthdayDate').selectOption('1');
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();
                await page.locator('#answer').fill('テスト病院');
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();
                let otpMail = await otp_mail(context);
                await test.info().annotations.push({type:"message" , description:`決済パスワード再設定 … メール認証番号[${otpMail}]`});
                await page.locator('#temporaryPassword').fill(otpMail);
                await page.locator('#newCode').fill(PAYMENT_PASSWORD_01);
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('決済パスワードの再設定が完了しました。');

                // TOP画面に戻る
                await page.locator('div.btn-group').locator('a.btn.btn-back').click();
            });
        });

        await test.step('購入導線２', async () => {
            await test.step('ご利用中の有料サービス', async () => {
                // 動作確認
                await page.locator('#service-usage-condition').click();

                // 検証
                const startDate = extractStartDate(await page.locator('table.service-term >> tr:has(th:has-text("ご利用可能期間")) >> td').textContent());
                await expect(startDate.getTime()).toBeGreaterThanOrEqual(now.getTime());
                await expect(page.locator('#NR-wrapper-in')).toContainText('ご利用中の有料サービス');
            });
        });

        await test.step('購入導線２', async () => {
            await test.step('商品解約', async () => {
                // 動作確認
                await page.locator('ul.service-btn-group').locator('button.btn.btn-cancel.btn-small').click();
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('有料サービスの解約');
                await expect(page.locator('#NR-wrapper-in')).toContainText('有料サービスの解約を受け付けました。');

                // ご利用中の有料サービス画面に戻る
                await page.locator('div.btn-group').locator('a.btn.btn-back').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('ご利用中の有料サービス');
                await expect(page.locator('#NR-wrapper-in')).toContainText('ご利用可能な有料サービスはありません。');

                // TOP画面に戻る
                await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
            });
        });

        await test.step('支払い方法の確認・変更２', async () => {
            await test.step('支払い方法の削除', async () => {
                // 動作確認
                await page.locator('#settlement-info').click();
                await page.locator('div.text-align-right').locator('a:has-text("すべてのお支払い方法を削除する")').click();
                page.once('dialog', dialog => {
                    dialog.accept();
                });
                await page.locator('div.btn-group').locator('input.btn.btn-next').click();

                // 検証
                await expect(page.locator('#NR-wrapper-in')).toContainText('支払い方法の削除完了');
                await expect(page.locator('#NR-wrapper-in')).toContainText('お支払い方法の削除が完了しました。');

                // TOP画面→支払い方法確認・変更画面に遷移
                await page.locator('div.btn-group').nth(0).locator('a:has-text("戻る")').click();
                await page.locator('#settlement-info').click();

                // 検証
                const creditBtnText = await page.locator('div.payment:has(div.payment-heading:has-text("クレジットカード")) a.btn').innerText();
                const chocomBtnText = await page.locator('div.payment:has(div.payment-heading:has-text("ちょコム")) a.btn').innerText();
                await expect(creditBtnText).toBe("登録する");
                await expect(chocomBtnText).toBe("登録する");

                // TOP画面に戻る
                await page.locator('#NR-nav-main-in').locator('a:has-text("トップ")').click();
            });
        });
    }

    // イニシャライズ　※ログアウトのみ
    await page.locator('#logout').click();
    await expect(page.locator('#NR-wrapper-in')).toContainText('ログアウトしました。');
    await context.clearCookies();
});

/**
 * ご利用可能期間から開始日時を抽出しDate型に変換
 */
function extractStartDate(dateText){

    const regex = /^(\d{4})年(\d{1,2})月(\d{1,2})日\s+(\d{1,2})時(\d{1,2})分/;
    const match = dateText.match(regex);
    if (match) {
        const[,year, month, day, hour, minute] = match.map(Number);
        return new Date(year, month - 1 , day, hour, minute);
    } else {
        throw new Error("変換エラー");
    }
}
