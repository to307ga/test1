import { defineConfig, devices } from '@playwright/test';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: 0,
  /* Opt out of parallel tests on CI. */
  workers: 1,
  /* Reporter to use  参照：https://playwright.dev/docs/test-reporters */
  reporter: [['list', { printSteps: true }],['html']],

  /* タイムアウト設定（テスト全体） */
  timeout: 10 * 60 * 1000,

  /* タイムアウト設定（アサーションのタイムアウト） */
  expect: {
      timeout: 30 * 1000,
  },

  /* プロジェクトの共有設定  参照：https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* デバイス指定（指定したもので実行されます） */
    ...devices['Desktop Chrome'],

    /* 失敗したテストを再試行するときのトレース設定  参照：https://playwright.dev/docs/trace-viewer */
    trace: 'on',                                     // 各テストのトレースを記録します。(注：パフォーマンスが重いため推奨されませんとのこと)
    // trace: 'retain-on-failure',                   // 各テストのトレースを記録しますが、成功したテスト実行からはトレースを削除します。（パフォーマンスを考えるとこの設定がよいと思われる）
    headless : process.env.CI ? true : false,
    actionTimeout: 30 * 1000,
    locatorTimeout: 30 * 1000,
    navigationTimeout: 30 * 1000,

    // プロキシ設定
    launchOptions: {
      args: ['--proxy-server=10.23.113.64:3128'],
    },
  },

/**
 * プロジェクト別設定 
 * baseURL       : 初めにアクセスするURL(initializeは除く)
 * launchOptions : 個別にプロキシ設定が必要な時に使用する
 */
  projects: [

    /* 無料系 */
    {
      name: 'gooid_st1',
      use: { 
        baseURL: 'https://lin101.mail.goo.ne.jp/',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid_st2',
      use: { 
        baseURL: 'https://lin201.mail.goo.ne.jp/',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid_st3',
      use: { 
        baseURL: 'https://lin301.mail.goo.ne.jp/',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid_pro',
      use: {
        baseURL: 'https://login.mail.goo.ne.jp/',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },

    /* 有料系 */
    {
      name: 'gbs-spring_st1',
      use: { 
        baseURL: 'https://svc101.goo.ne.jp', 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
     {
      name: 'gbs-spring_st2',
      use: { 
        baseURL: 'https://svc201.goo.ne.jp', 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gbs-spring_st3',
      use: { 
        baseURL: 'https://svc301.goo.ne.jp', 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gbs-spring_pro',
      use: { 
        baseURL: 'https://srvc.goo.ne.jp', 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },

    /* gooid-oidc */
    {
      name: 'gooid-oidc_st1',
      use: { 
        baseURL: 'https://dev.onlineshop.ocn.ne.jp',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid-oidc_st2',
      use: { 
        baseURL: '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid-oidc_st3',
      use: { 
        baseURL: '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'gooid-oidc_pro',
      use: {
        baseURL: 'https://onlineshop.ocn.ne.jp',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },

    /* idhub-ocn */
    {
      name: 'idhub-ocn_st1',
      use: { 
        baseURL: 'https://stg.mypage.ocn.ne.jp',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-ocn_st2',
      use: { 
        baseURL: '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-ocn_st3',
      use: { 
        baseURL: '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-ocn_pro',
      use: { 
        baseURL: 'https://mypage.ocn.ne.jp',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },

    /* idhub-lounge */
    {
      name: 'idhub-lounge_st1',
      use: { 
        baseURL:  'https://stg001.lounge.d.goo.ne.jp',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-lounge_st2',
      use: { 
        baseURL:  '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-lounge_st3',
      use: { 
        baseURL:  '',
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'idhub-lounge_pro',
      use: {
        baseURL:  'https://lounge.d.goo.ne.jp', 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },

    /* initialize */
    {
      name: 'initialize_st1',
      use: { 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'initialize_st2',
      use: { 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'initialize_st3',
      use: { 
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
    {
      name: 'initialize_pro',
      use: {
        //launchOptions: {
        //  args: ['--proxy-server=10.23.113.64:3128'],
        //},
      },
    },
  ],
});
