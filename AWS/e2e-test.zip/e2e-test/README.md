# Playwright 自動 E2E テスト

Playwright を使用して Web アプリケーションの自動テストを実施します。

## 前提条件

- Node.js (バージョン 14 以上)
- ローカルで実施する場合は、VSCode と「Playwright Test for VSCode」プラグインの使用を推奨します。

## インストール

以下のコマンドを実行して、依存関係をインストールします。

```sh
npm install
```

## プロジェクト構成

- tests/: テストファイルを格納するディレクトリ
- tests/config/testconfig.ts: テスト内容の設定ファイル
- playwright.config.js: Playwright の設定ファイル
- package.json: プロジェクトの依存関係およびスクリプト
- dockerfile: Jenkins にてテスト実行する場合の仮想環境設定

## テストの実行
検証環境(st1)
--テストケース
npx playwright test gooid_high-middle.spec.ts --project=gooid_st1
npx playwright test gooid_low.spec.ts --project=gooid_st1
npx playwright test gbs-spring_all.spec.ts --project=gbs-spring_st1
npx playwright test gooid-oidc_all.spec.ts --project=gooid-oidc_st1
npx playwright test idhub-ocn_all.spec.ts --project=idhub-ocn_st1
npx playwright test idhub-lounge_all.spec.ts --project=idhub-lounge_st1
-- イニシャライズ
npx playwright test initialize_gooid --project=initialize_st1
npx playwright test initialize_idhub --project=initialize_st1

検証環境(st2) ※oidc,ocn,loungeは実行は可能ですが、外部から呼ばれるためskipされます。
--テストケース
npx playwright test gooid_high-middle.spec.ts --project=gooid_st2
npx playwright test gooid_low.spec.ts --project=gooid_st2
npx playwright test gbs-spring_all.spec.ts --project=gbs-spring_st2
npx playwright test gooid-oidc_all.spec.ts --project=gooid-oidc_st2
npx playwright test idhub-ocn_all.spec.ts --project=idhub-ocn_st2
npx playwright test idhub-lounge_all.spec.ts --project=idhub-lounge_st2
-- イニシャライズ
npx playwright test initialize_gooid --project=initialize_st2
npx playwright test initialize_idhub --project=initialize_st2

検証環境(st3) ※oidc,ocn,loungeは実行は可能ですが、外部から呼ばれるためskipされます。
--テストケース
npx playwright test gooid_high-middle.spec.ts --project=gooid_st3
npx playwright test gooid_low.spec.ts --project=gooid_st3
npx playwright test gbs-spring_all.spec.ts --project=gbs-spring_st3
npx playwright test gooid-oidc_all.spec.ts --project=gooid-oidc_st3
npx playwright test idhub-ocn_all.spec.ts --project=idhub-ocn_st3
npx playwright test idhub-lounge_all.spec.ts --project=idhub-lounge_st3
-- イニシャライズ
npx playwright test initialize_gooid --project=initialize_st3
npx playwright test initialize_idhub --project=initialize_st3

商用環境
--テストケース
npx playwright test gooid_high-middle.spec.ts --project=gooid_pro
npx playwright test gooid_low.spec.ts --project=gooid_pro
npx playwright test gbs-spring_all.spec.ts --project=gbs-spring_pro
npx playwright test gooid-oidc_all.spec.ts --project=gooid-oidc_pro
npx playwright test idhub-ocn_all.spec.ts --project=idhub-ocn_pro
npx playwright test idhub-lounge_all.spec.ts --project=idhub-lounge_pro
-- イニシャライズ
npx playwright test initialize_gooid --project=initialize_pro
npx playwright test initialize_idhub --project=initialize_pro


※テストスクリプトが相対パスで作成されているためオプション：--project をつけること
  ただし、テストスクリプトが絶対パスで作成した場合、オプションが不要のため下記のような実行が可能になります。
  以下のコマンドを実行して、全てのテストを実行します。
  ```sh
      npx playwright test
  ```
  特定のテストを実施する場合は、そのテストファイル/フォルダに含まれる文字列を追加してください。
  ```sh
      # gooIdTestをファイル名に含むテストを全て実施
      npx playwright test gooIdTest
  ```

## その他

### 使用アカウントの変更

tests/config/testconfig.ts に記載されている内容を変更してください。
