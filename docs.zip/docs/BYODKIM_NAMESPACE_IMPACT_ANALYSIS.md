# 🚨 **マルチテナント対応：BYODKIM名前空間変更の影響分析**

## ⚠️ **重大な問題発見**

ご指摘の通り、BYODKIM名前空間の変更により**他のテンプレートやスクリプトに重大な影響**があります。

### ❌ **影響のあるシステム**

#### 1. **メトリクス送信側と受信側の不整合**

**Phase 8 監視テンプレート (phase-8-monitoring.yaml)**:
```python
# メトリクス送信コード（Lambda内）
cloudwatch.put_metric_data(
    Namespace=f'{project_name}/{environment}',  # 例: "aws-ses-migration-prod/prod"
    MetricData=[{
        'MetricName': 'DKIMStatus',
        'Value': dkim_status_value
    }]
)
```

**監視テンプレート (monitoring.yaml)**:
```yaml
# メトリクス受信側（現在の修正後）
BYODKIMVerificationAlarm:
  MetricName: BYODKIMVerificationStatus
  Namespace: !Ref BYODKIMMetricNamespace  # "ses-migration/prod/007773581311/BYODKIM"
```

**❌ 問題**: 送信先と受信先の名前空間が**完全に異なる**ため、メトリクスが受信されない

#### 2. **他のメトリクス送信システム**

**Enhanced Kinesis テンプレート (enhanced-kinesis.yaml)**:
```python
# Lambda内でのメトリクス送信
cloudwatch.put_metric_data(
    Namespace="aws-ses-migration/prod/kinesis",  # ハードコーディングの可能性
    MetricData=[{
        'MetricName': 'ProcessingErrors',
        'Value': error_count
    }]
)
```

### 📋 **影響を受けるファイル一覧**

#### **テンプレートファイル**
1. ✅ `templates/monitoring.yaml` - **修正済み**（しかし不整合発生）
2. 🔍 `templates/phase-8-monitoring.yaml` - **要確認**（メトリクス送信コード）
3. 🔍 `templates/enhanced-kinesis.yaml` - **要確認**（メトリクス送信コード）
4. 🔍 `templates/dkim-manager-lambda.yaml` - **要確認**（メトリクス送信の可能性）

#### **Python スクリプト**
- ✅ 一般的なスクリプト（check_*.py）- **影響なし**（直接参照なし）
- ✅ BYODKIM登録スクリプト（fix_byodkim*.py）- **影響なし**（CloudWatchメトリクス使用なし）

### 🎯 **修正が必要な箇所**

#### **Option 1: 統一的な名前空間設計**
```yaml
# 推奨: 環境とアカウントIDを含む統一フォーマット
prod環境: "ses-migration/prod/007773581311"
dev環境:  "ses-migration/dev/222222222222"

# サブ名前空間
Monitoring: "ses-migration/prod/007773581311/Monitoring"
BYODKIM:    "ses-migration/prod/007773581311/BYODKIM"
Kinesis:    "ses-migration/prod/007773581311/Kinesis"
```

#### **Option 2: 設定ファイルでの統一管理**
```yaml
# config/prod/config.yaml
template_defaults:
  BaseMetricNamespace: "ses-migration/prod/007773581311"
  
# config/dev/config.yaml  
template_defaults:
  BaseMetricNamespace: "ses-migration/dev/222222222222"
```

### ⚡ **緊急修正アクション**

#### **Phase 1: 名前空間設計の統一**
1. ✅ `BaseMetricNamespace` パラメータをconfig.yamlに追加
2. ✅ 全テンプレートで統一的な名前空間参照
3. ✅ Lambda内のメトリクス送信コードを環境変数ベースに修正

#### **Phase 2: 整合性確保**
1. ✅ メトリクス送信側と受信側の名前空間を完全一致させる
2. ✅ 環境変数による動的名前空間設定
3. ✅ テスト環境での動作確認

### 📊 **推奨解決案**

```yaml
# 1. config/prod/config.yaml
template_defaults:
  AccountId: "007773581311"
  Environment: "prod" 
  BaseMetricNamespace: "ses-migration/prod/007773581311"

# 2. templates/monitoring.yaml
Parameters:
  BaseMetricNamespace:
    Type: String
    Description: Base metric namespace for all monitoring
    
Resources:
  BYODKIMVerificationAlarm:
    Properties:
      Namespace: !Sub "${BaseMetricNamespace}/BYODKIM"

# 3. templates/phase-8-monitoring.yaml (Lambda環境変数)
Environment:
  Variables:
    BASE_METRIC_NAMESPACE: !Ref BaseMetricNamespace

# 4. Lambda内Python コード
namespace = f"{os.environ['BASE_METRIC_NAMESPACE']}/DKIM"
cloudwatch.put_metric_data(Namespace=namespace, ...)
```

### 🚨 **現在の状態**

- ❌ **メトリクス不整合**: 送信先と受信先が一致しない
- ❌ **アラーム無効**: BYODKIMアラームが機能しない可能性
- ❌ **監視盲点**: 重要なBYODKIM監視が動作しない

### ✅ **次のステップ**

この不整合を解決するために：
1. **即座に統一設計を実装**
2. **全テンプレートの整合性確保**
3. **テスト環境での動作確認**
4. **prod環境への慎重な適用**

**結論**: マルチテナント対応において、このような名前空間の不整合は**システム全体の監視機能を無効化**する重大な問題です。統一的な設計により修正が必要です。
