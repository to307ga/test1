#!/bin/bash

# AWS認証状態確認スクリプト
# 現在の認証情報、プロファイル、権限などを詳細表示

echo "🔍 AWS認証状態チェック"
echo "=========================="
echo ""

# 1. 環境変数チェック
echo "📋 環境変数状態:"
echo "   AWS_PROFILE: ${AWS_PROFILE:-'(未設定)'}"
echo "   AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID:+設定済み}${AWS_ACCESS_KEY_ID:-'(未設定)'}"
echo "   AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY:+設定済み}${AWS_SECRET_ACCESS_KEY:-'(未設定)'}"
echo "   AWS_SESSION_TOKEN: ${AWS_SESSION_TOKEN:+設定済み(一時認証)}${AWS_SESSION_TOKEN:-'(未設定 - 永続認証)'}"
echo ""

# 2. 現在の認証情報確認
echo "🔐 現在のAWS認証情報:"
CALLER_IDENTITY=$(aws sts get-caller-identity --no-verify-ssl 2>/dev/null)
if [ $? -eq 0 ]; then
    echo "   ✅ 認証成功"

    # JSONパース（Python使用）
    USER_ID=$(echo "$CALLER_IDENTITY" | python3 -c "import json,sys; print(json.load(sys.stdin)['UserId'])" 2>/dev/null)
    ACCOUNT=$(echo "$CALLER_IDENTITY" | python3 -c "import json,sys; print(json.load(sys.stdin)['Account'])" 2>/dev/null)
    ARN=$(echo "$CALLER_IDENTITY" | python3 -c "import json,sys; print(json.load(sys.stdin)['Arn'])" 2>/dev/null)

    echo "   User ID: $USER_ID"
    echo "   Account: $ACCOUNT"
    echo "   ARN: $ARN"

    # 認証タイプ判定
    if [[ "$ARN" == *":assumed-role/"* ]]; then
        echo "   📝 認証タイプ: AssumeRole (一時認証)"
    elif [[ "$USER_ID" == AKIA* ]]; then
        echo "   📝 認証タイプ: 永続 Access Key"
    elif [[ "$USER_ID" == ASIA* ]]; then
        echo "   📝 認証タイプ: 一時認証 (STS)"
    else
        echo "   📝 認証タイプ: 不明"
    fi
else
    echo "   ❌ 認証失敗 - AWS設定を確認してください"
    exit 1
fi

echo ""

# 3. プロファイル設定確認
echo "⚙️  AWS CLI設定:"
if [ -f ~/.aws/config ]; then
    echo "   Config file: ~/.aws/config 存在"
    PROFILES=$(grep '^\[profile' ~/.aws/config | sed 's/\[profile \(.*\)\]/\1/' | tr '\n' ' ')
    echo "   利用可能プロファイル: $PROFILES"
else
    echo "   Config file: ~/.aws/config 不存在"
fi

if [ -f ~/.aws/credentials ]; then
    echo "   Credentials file: ~/.aws/credentials 存在"
    CRED_PROFILES=$(grep '^\[' ~/.aws/credentials | sed 's/\[\(.*\)\]/\1/' | tr '\n' ' ')
    echo "   認証情報プロファイル: $CRED_PROFILES"
else
    echo "   Credentials file: ~/.aws/credentials 不存在"
fi

echo ""

# 4. 権限確認（基本的なCloudWatch権限をテスト）
echo "🛡️  権限チェック:"
echo "   CloudWatch読み取り権限をテスト中..."
aws cloudwatch list-dashboards --no-verify-ssl >/dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "   ✅ CloudWatch権限: OK"
else
    echo "   ❌ CloudWatch権限: NG"
fi

echo ""

# 5. Sceptre使用可能性チェック
echo "🏗️  Sceptre環境チェック:"
if [ -d "sceptre" ]; then
    echo "   ✅ Sceptreディレクトリ: 存在"
    cd sceptre
    export PYTHONHTTPSVERIFY=0
    uv run sceptre --version >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ Sceptre実行: OK"
    else
        echo "   ❌ Sceptre実行: NG"
    fi
    cd ..
else
    echo "   ❌ Sceptreディレクトリ: 不存在"
fi

echo ""
echo "🎯 認証状態サマリー:"
if [ -n "$AWS_SESSION_TOKEN" ]; then
    echo "   📱 一時認証使用中（GetSessionToken方式）"
    echo "   ⏰ 有効期限あり（通常12時間）"
    echo "   🔄 期限切れ時は ./mfa_quick.sh [MFAコード] で再認証"
elif [ -n "$AWS_ACCESS_KEY_ID" ] && [ -z "$AWS_PROFILE" ]; then
    echo "   🔑 環境変数による永続認証使用中"
    echo "   ⏰ 有効期限なし"
elif [ -n "$AWS_PROFILE" ]; then
    echo "   👤 プロファイル認証使用中: $AWS_PROFILE"
    echo "   ⏰ プロファイル設定により決定"
else
    echo "   ❓ 認証方式不明"
fi
